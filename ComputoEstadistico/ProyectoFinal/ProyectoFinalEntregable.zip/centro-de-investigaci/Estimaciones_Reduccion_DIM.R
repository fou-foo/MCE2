###################### Packages necesarios
library(ggplot2) #graficos
library(xtable)
library(easyGgplot2)
library(nortest)
library(parallel)
library(pls)
#######################
# colores
######################
morado <- rgb(t(col2rgb('purple')/255), alpha= 0.5)
naranja <- rgb(t(col2rgb('orange')/255), alpha= 0.5)
chido <- rgb(t(col2rgb('#0089E0')/255), alpha=0.5)
color1 <- rgb(t(col2rgb('#FA00A4')/255), alpha=0.5)
color2 <- rgb(t(col2rgb('#27D6C2')/255), alpha=0.5)
color3 <- rgb(t(col2rgb('#442CBC')/255), alpha=0.5)
rojo <- rgb(t(col2rgb('#A40C1D')/255), alpha=.5)
azul <- rgb(t(col2rgb('#0B68C2')/255), alpha=.5) 
verde <- rgb(t(col2rgb('#4C8946')/255), alpha=.5)

###################### Funciones
MSE <- function(y.hat, y)
{
  # Calculo de error cuadratico medio
  return(mean((y-y.hat)**2))
}
##########################
# PlS
#########################
setwd("~/Desktop/ProyectoFinal/YearPredictionMSD.txt")#fijamos el directorio de trabajo
load(file ='TrainTest_net.Rdata')
#######################
# carga de y en escala original
load(file ='y.test.escala.original.Rdata')
mu <-  1998.397 
sd <- 10.93105
###################### Modelos OLS
######################
pls.options(parallel = 1) # Use mclapply with 4 CPUs
p <- 40
pls.options(plsralg = "simpls")
set.seed(0)
time.pls.1 <- Sys.time()
modelo.pls <- plsr(y ~ ., ncomp = p , data = train, validation = "CV", segments = 120) # 20.34 mins
time.pls.2 <- Sys.time()
(time.pls.2 -time.pls.1)
modelo.pls <- plsr(y ~ ., ncomp = 16 , data = train)
gc()
summary(modelo.pls)
plot(RMSEP(modelo.pls), legendpos = "topright", main=as.character(p))
plot(RMSEP(modelo.pls), legendpos = "topright", main=as.character(p), xlim=c(0,10), ylim=c(0,1))
plot(RMSEP(modelo.pls), legendpos = "topright", main=as.character(p), xlim=c(0,5), ylim=c(0,1))
# 10p10f: 52 seg, 15p10f: 1.0 mins (14comp), 20p10f: 1.22mins, 20p20f: 2.3 mins, 20p40f: 4.7 mins
# 20p250f: 25mins, 40p250f: 44.4mins | 
summary(modelo.pls)
y.hat <- predict(modelo.pls, ncomp=16 , newdata = test)
y.train <- predict(modelo.pls, ncomp=16, newdata = train)
a <- predplot(modelo.pls, ncomp = 16, newdata = test, asp = 1, line = TRUE)
b <- predplot(modelo.pls, ncomp = 16, newdata = train, asp = 1, line = TRUE)
(errores.train.pls <- MSE(b[, 'predicted'], train$y)) # 0.7637633 
(errores.test.pls <- MSE(a[, 'predicted'], test$y)) # 0.7568457 
train.PLS <- predict(modelo.pls, ncomp = 1:16, newdata = train)
dim(train.PLS) <- c(dim(train)[1], 16)
train.PLS <- cbind(train.PLS, train$y)
colnames(train.PLS) <- c(paste0('PLS', 1:16), 'y')
MSE(y.test.escala.original, y.hat*sd+mu)**.5 # error con la misma escala que el paper
# 9.509669
#
test.PLS <- predict(modelo.pls, ncomp = 1:16, newdata = test)
dim(test.PLS) <- c(dim(test)[1], 16)
test.PLS <- cbind(test.PLS, test$y)
colnames(test.PLS) <- c(paste0('PLS', 1:16), 'y')
save(train.PLS, file='trainPLS.rdata')
save(test.PLS, file='testPLS.rdata')
######## como luce el modelo 
#
plot(modelo.pls , plottype = "scores", comps = 1:3)
plot(modelo.pls, "loadings", comps = 1:4, legendpos = "bottomright", xlab = "Variable", ylab='loadings',
     main='Componentes de PLS', lw=2, col=c(verde, naranja, azul, morado))
plot(modelo.pls, "loadings", comps = 1:4, legendpos = "bottomright", xlab = "Variable", ylab='loadings',
     main='Componentes de PLS', lw=2, col=c(verde, naranja, azul, morado))
plot(modelo.pls , plottype = "correlation", comps = 1:3)
################################################################################
# PCR 
setwd("~/Desktop/ProyectoFinal/YearPredictionMSD.txt")#fijamos el directorio de trabajo
load(file ='TrainTest_net.Rdata')
pls.options(parallel = 1) # Use mclapply with 4 CPUs
p <- 90
set.seed(0)
time.pcr.1 <- Sys.time()
modelo.pcr <- pcr(y ~ ., ncomp = p , data = train, validation = "CV", segments = 50) #
time.pcr.2 <- Sys.time()
(time.pcr.2 -time.pcr.1)
#modelo.pcr <- plsr(y ~ ., ncomp = p , data = train)
gc()
summary(modelo.pcr)
plot(RMSEP(modelo.pcr), legendpos = "bottomright", ylim=c(.85,1), main='PCR (90 componentes, 60 folds)',
     xlab='Número de componentes', ylab='RMSEP', col= c(morado, naranja), lwd=1:2, lty=2:3)
# 90p10f: 5.32 mins, 90p20f :10.60  29.76769 mins
summary(modelo.pcr)
y.hat <- predict(modelo.pcr, ncomp=40 , newdata = test)
y.train <- predict(modelo.pcr, ncomp=40, newdata = train)
(errores.train.pcr <- MSE(y.train, train$y)) # 0.8710691
(errores.test.pcr <- MSE(y.hat, test$y)) # 0.8627718

validationplot(modelo.pcr,val.type="MSEP")
train.PCR <- predict(modelo.pcr, ncomp = 1:40, newdata = train)
dim(train.PCR) <- c(dim(train)[1], 40)
train.PCR <- cbind(train.PCR, train$y)
colnames(train.PCR) <- c(paste0('PCR', 1:40), 'y')
#
test.PCR <- predict(modelo.pcr, ncomp = 1:60, newdata = test)
dim(test.PCR) <- c(dim(test)[1], 60)
test.PCR <- cbind(test.PCR, test$y)
colnames(test.PCR) <- c(paste0('PCR', 1:60), 'y')
save(train.PCR, file='trainPCR.rdata')
save(test.PCR, file='testPCR.rdata')
######## como luce el modelo 
#
plot(modelo.pls , plottype = "scores", comps = 1:3)
plot(modelo.pls, "loadings", comps = 1:4, legendpos = "bottomright", xlab = "Variable", ylab='loadings',
     main='Componentes de PLS', lw=2, col=c(verde, naranja, azul, morado))
plot(modelo.pls, "loadings", comps = 1:4, legendpos = "bottomright", xlab = "Variable", ylab='loadings',
     main='Componentes de PLS', lw=2, col=c(verde, naranja, azul, morado))
plot(modelo.pls , plottype = "correlation", comps = 1:3)

######################
base <- data.frame(y =a[, 'measured']  , y.hat=a[, 'predicted'], residuos= a[,'measured']- a[, 'predicted'])
base$index <- 1:dim(base)[1]
names(base)
p1 <- ggplot(base, aes(x=y, y=y.hat)) +geom_point(colour=I(chido)) + theme_minimal() +
  ggtitle('Predicción con OLS, resultado base') + stat_function(fun=function(x)x, colour='purple')
p1
p2 <- ggplot(base, aes(x=y.hat, y=residuos)) +geom_point(colour=I(chido)) + theme_minimal() +
  ggtitle('Residuales, resultado base') 
p2
p3 <- ggplot(base, aes(x=index, y = residuos)) +geom_point(colour=I(chido), size=.1) + theme_minimal() +
  ggtitle('Residuales, resultado base') +xlab('') 
p3
p4 <- ggplot(base, aes(x=residuos)) +geom_density(colour=I(chido), size=1) + theme_minimal() +
  ggtitle('Residuales, resultado base') +xlab('') + ylab('')
p4
ggplot2.multiplot(p1, p2, p3, p4, col=2)
ad.test(a[,'predicted'])
rm(modelo.pls)
gc()
