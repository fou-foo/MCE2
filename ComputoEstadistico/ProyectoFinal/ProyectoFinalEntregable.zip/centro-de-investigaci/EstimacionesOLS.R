###################### Packages necesarios
library(ggplot2) #graficos
library(xtable)
library(leaps)
library(glmnet)
library(easyGgplot2)
library(nortest)
#######################
# colores
######################
morado <- rgb(t(col2rgb('purple')/255), alpha= 0.5)
naranja <- rgb(t(col2rgb('orange')/255), alpha= 0.5)
chido <- rgb(t(col2rgb('#0089E0')/255), alpha=0.5)
color1 <- rgb(t(col2rgb('#FA00A4')/255), alpha=0.5)
color2 <- rgb(t(col2rgb('#27D6C2')/255), alpha=0.5)
color3 <- rgb(t(col2rgb('#442CBC')/255), alpha=0.5)
###################### Funciones
MSE <- function(y.hat, y)
{
  # Calculo de error cuadratico medio
  return(mean((y-y.hat)**2))
}

###########################
setwd("~/Desktop/ProyectoFinal/YearPredictionMSD.txt")
t1 <- Sys.time()
songs <- read.csv('YearPredictionMSD.txt', stringsAsFactors = FALSE, header = FALSE)
t1 <- Sys.time() - t1
t1 # lectura 1.21231 mins
names(songs) <- c('y', paste0('X', 1:90))
mu <- mean(songs$y)
sd <- sd(songs$y) 
########################### estandarizacion de los datos
datos <- scale(songs)
dim(datos)
datos <- as.data.frame(datos)
names(datos)
datos <- as.data.frame(datos)
train <- datos[1:463715,]
test <- datos[463716:dim(datos)[1], ]
remove(datos, songs)
setwd("~/Desktop/ProyectoFinal/YearPredictionMSD.txt")
save.image(file ='TrainTest_net.Rdata')
###################### Modelos OLS
load(file ='TrainTest_net.Rdata')
modelo.lm <- lm(y~ ., train) #dos segundos
(error.ols.train <- MSE(predict(modelo.lm, train), train$y)) # 0.7637302
(error.ols.test <- MSE(predict(modelo.lm, test), test$y)) # 0.7569239
fit <- predict(modelo.lm, test)
base <- data.frame(y.hat =fit  , y=test$y, residuos=fit- test$y )
base$index <- 1:dim(base)[1]
p1 <- ggplot(base, aes(x=y, y=y.hat)) +geom_point(colour=I(chido)) + theme_minimal() +
  ggtitle('Predicción con OLS, resultado base') + stat_function(fun=function(x)x, colour='purple')
p1
p2 <- ggplot(base, aes(x=y.hat, y=residuos)) +geom_point(colour=I(chido)) + theme_minimal() +
  ggtitle('Residuales, resultado base') 
p2
p3 <- ggplot(base, aes(x=index, y = residuos)) +geom_point(colour=I(chido), size=.1) + theme_minimal() +
  ggtitle('Residuales, resultado base') +xlab('') 
p3
p4 <- ggplot(base, aes(x=residuos)) +geom_density(colour=I(chido), size=1) + theme_minimal() +
  ggtitle('Residuales, resultado base') +xlab('') + ylab('')
p4
ggplot2.multiplot(p1, p2, p3, p4, col=2)
ad.test(base$residuos) # se rechaza con el test de kolmogorov y anderson
summary(modelo.lm) # estimacion pobre R^2 ajustado de 0.2373
# seleccion del mejor subconjunto de variables
tiempo.step1 <- Sys.time()
modelo.lm.step <- step(modelo.lm)
tiempo.lm.step2 <- Sys.time()
(tiempo.lm.step2 - tiempo.step1) #1.11152 hrs
modelo.lm.step <- lm(y~ X1 +X2 +X3 +X4 +X5 +X6 +X7 +X8 +X9 +X10 +X11 +X13 +X14 +X15 +X16 +X17 +X18 +X19 +X20 +
                       X21 +X22 +X23 +X24 +X25 +X26 +X27 +X28 +X29 +X30 +X31 +X32 +X33 +X34 +X35 +X36 +X37 +X38 +X39 +X40 +
                       X41 +X42 +X43 +X44 +X45 +X46 +X47 +X48 +X49 +X50  +X52 +X53 +X56 +X57 +X58 +X59 +X60 +
                       X61 +X62 +X63 +X64 +X65 +X66 +X68 +X69 +X70 +X71 +X72 +X73 +X74 +X75 +X76 +X77 +X78 +
                       X82 +X83 +X84 +X85  +X87 +X88 +X89 +X90, train )
summary(modelo.lm.step)
# elimino 12, 51,54,55,67,79,80,81,86
# pero el modelo sigue siendo pobre R^2 ajustado de 0.2373
error.lm.step.train <- MSE(predict(modelo.lm.step, train), train$y) #  0.7637379
error.lm.step.test <- MSE(predict(modelo.lm.step, test), test$y) # 0.7569413
remove(modelo.lm.step)
gc()
###################
# Ridge
#####################################
setwd("~/Desktop/ProyectoFinal/YearPredictionMSD.txt")#fijamos el directorio de trabajo
load(file ='TrainTest_net.Rdata')
tiempo.ridge1 <- Sys.time()
y <- train$y
gc()
grid <- 10**seq(100,-5,length =10)
grid
plot(grid)
plot(grid[1:50])
plot(grid[51:100])
set.seed(100)
modelo.Ridge <- cv.glmnet(as.matrix(train[, -91]), y, alpha =0,
                          lambda =grid, nfolds = 500)
plot(modelo.Ridge)
(l <- modelo.Ridge$lambda.min)
y.test <- test$y
gc()
y.hat.ridge <- predict(modelo.Ridge, as.matrix(test[, -91]), s='lambda.min')
tiempo.ridge2 <- Sys.time()
(tiempo.ridge2 - tiempo.ridge1) # 10f-10 pts: 36.17 seg, 100f-10p: 5.42 mins , 500f-10p:26.26 mins
summary(modelo.Ridge)
plot(modelo.Ridge) # se tardo con 10-folds
(error.ridge.train <- MSE(predict(modelo.Ridge, as.matrix(train[, -91]), s='lambda.min'), y)) #1.001594
(error.ridge.test <- MSE(y.hat.ridge, y.test)) # 0.9856738
coefficients(modelo.Ridge)
m <- glmnet(as.matrix(train[, -91]), y, lambda=l, alpha=0)
coefficients(m)
m <- glmnet(as.matrix(train[, -91]), y, lower=0, upper=1e-85)
plot(m)
vnat <- coef(m)
vnat <- vnat[-1,ncol(vnat)] # remove the intercept, and get the coefficients at the end of the path
axis(4, at=vnat, line=-.5, label= names(vnat), las=1, tick=FALSE, cex.axis=0.5)
A <- apply(train[, -91], 2, mean)
A
remove(modelo.Ridge)
gc()
#####################
#Lasso
###############
setwd("~/Desktop/ProyectoFinal/YearPredictionMSD.txt")#fijamos el directorio de trabajo
load(file ='TrainTest_net.Rdata')
tiempo.lasso1 <- Sys.time()
y <- train$y
gc()
grid <- 10**seq(100,-5,length =10)
grid
plot(grid)
plot(grid[1:50])
plot(grid[51:100])
set.seed(100)
modelo.lasso <- cv.glmnet(as.matrix(train[, -91]), y, alpha =1,
                          lambda =grid, nfolds = 2500) 
plot(modelo.lasso)
(l <- modelo.lasso$lambda.min)
y.test <- test$y
gc()
y.hat.lasso <- predict(modelo.lasso, as.matrix(test[, -91]), s='lambda.min')
tiempo.lasso <- Sys.time()
(tiempo.lasso - tiempo.lasso1) # 10f-10 pts: 16 seg, 100f-10p: 1.33 mins, 500f-10p:5.86 mins, 2500f-10p:30.49 mins 5000f-10p:54.7mins
summary(modelo.lasso)
plot(modelo.lasso) # se tardo con 10-folds
(error.lasso.train <- MSE(predict(modelo.lasso, as.matrix(train[, -91]), s='lambda.min'), y))#1.001594
(error.lasso.test <- MSE(y.hat.lasso, test$y))#  0.9856738
coefficients(modelo.lasso)
m <- glmnet(as.matrix(train[, -91]), y, lambda=l, alpha=1)
coefficients(m)
m <- glmnet(as.matrix(train[, -91]), y, lower=0, upper=1e-85)
plot(m)
vnat <- coef(m)
vnat <- vnat[-1,ncol(vnat)] # remove the intercept, and get the coefficients at the end of the path
axis(4, at=vnat, line=-.5, label= names(vnat), las=1, tick=FALSE, cex.axis=0.5)
A <- apply(train[, -91], 2, mean)
A