###############################
# parametros de la simulacion
repeticiones <- 2
n <- 463715 #tamanio de muestra
p <- 90 #numero de covariables
r <- p/n
a.fija <- (1-r**.5)**2 #coeficientes de la distro de Marchenko
b.fija <- (1+r**.5)**2
hilos <- 1
###############################
# colores
morado <- rgb(t(col2rgb('purple')/255), alpha= 0.5)
naranja <- rgb(t(col2rgb('orange')/255), alpha= 0.5)
chido <- rgb(t(col2rgb('#0089E0')/255), alpha=0.5)
color1 <- rgb(t(col2rgb('#FA00A4')/255), alpha=0.5)
color2 <- rgb(t(col2rgb('#27D6C2')/255), alpha=0.5)
color3 <- rgb(t(col2rgb('#442CBC')/255), alpha=0.5)
rojo <- rgb(t(col2rgb('#A40C1D')/255), alpha=.5)
azul <- rgb(t(col2rgb('#0B68C2')/255), alpha=.5)
verde <- rgb(t(col2rgb('#4C8946')/255), alpha=.5)
################################
# Funciones
library(ggplot2)
library(reshape2)
library(pls)
library(parallel) #paralelizacion
pls.options(parallel = 4)
pls.options(plsralg = "simpls")
library(RMTstat)
#############################################
remove(list=ls())
setwd("~/Desktop/ProyectoFinalRMT")
load('parametros.Rdata')
load(file ='Practico.Rdata')
apply(train, 2, mean)
apply(train, 2, sd)
y.test <- test$y
test$y <- NULL
y.train <- train$y
train$y <- NULL
######## Simulacion con uniformes caso datos reales
rangos <- apply(train, 2, range)
row.names(rangos) <- c('min', 'max')
tiempo1 <- Sys.time()
f.aux <- simulacion.unif.singleton.init(train, rangos )
val.prac.unif <- simulacion.unif(f.aux , repeticiones )
tiempo2 <- Sys.time()
tiempo2 -tiempo1 # 17.10 mins
a <- melt(val.prac.unif, id='id.val')
eigen.prac <- eigen.muestra(train)
eigen.prac <- eigen.muestra(train)
ggplot(a, aes(x=id.val, y=value, fill=variable)) +
  geom_line(color=I(chido)) + theme_minimal() +
  xlab('Valor propio ordenado') + ylab('Estimacion del valor propio') +
  ggtitle('Parallel analysis datos reales, método uniforme') +
  geom_line(data=eigen.prac, aes(x=id.val, y=value, color=I('red')), size=1.3)+
  stat_function(fun= function(x) 1, col='purple') + xlim(c(0,91))
gc()
# simulacion boostrap, datos reales
tiempo3 <- Sys.time()
val.prac.boost <- simulacion.boostrap(data=train, repeticiones)
tiempo4 <- Sys.time() # 43.97078 mins
tiempo4 - tiempo3
a <- melt(val.prac.boost, id='id.val')
ggplot(a, aes(x=id.val, y=value, fill=variable )) + geom_line(color=I(chido), size=1.3) +
  theme_minimal() + xlab('Valor propio ordenado') +
  ylab('Estimacion del valor propio')+
  ggtitle('Parallel analysis datos reales, método Bootstrap') +
  geom_line(data=eigen.prac, aes(x=id.val, y=value, color=I('red')))+
  stat_function(fun= function(x) 1, col='purple') + xlim(c(0, 91))
gc()

# con 500000, 90, y 1000 repeticiones se tarda 2.01 hrs
###################################
media.prac.unif <- data.frame(value = apply(val.prac.unif[,-(repeticiones+1)], 1, mean),
                              id.val=1:p)
media.prac.unif$variable <- 'Unif'
media.prac.boots <- data.frame(value = apply(val.prac.boost[,-(repeticiones+1)], 1, mean),
                               id.val=1:p)
media.prac.boots$variable <- 'Boostrap'
curvas.prac <- rbind(media.prac.unif, media.prac.boots, eigen.prac)
names(curvas.prac) <- c('value', 'id.val', 'variable')


ggplot(curvas.prac, aes(x=id.val, y=value, color=(variable))) +
  geom_line( size=1.5, alpha=0.4, aes(linetype=variable)) + theme_minimal() +
  xlab('Valor propio ordenado') + ylab('Estimacion del valor propio') +
  ggtitle('Parallel analysis ~Songs') +
  stat_function(fun= function(x) 1, col='purple') +
  theme(legend.title = element_blank())
names(curvas.norm) <- c('value', 'id.val', 'Metodo')




names(curvas.prac) <- c('value', 'id.val', 'Metodo')
ggplot(curvas.prac, aes(x=value, color=(Metodo))) +
  geom_density(size=1.3) + theme_minimal() +
  xlab('Parallel Analysis') + ylab('Densidad') +
  ggtitle('Distribución de los valores propios ~Songs') +
  geom_rug(data=subset(curvas.prac, Metodo == 'Muestral'), sides="b",
           color='#00B937', size=1)+
  stat_function(fun=dmp, args=list(ndf=n, pdim=p, var=1, log = FALSE ),
                col='purple', size=1.2)+
  geom_vline(xintercept = 1, color=I('#440154'), size=1.3)+
  xlim(c(.9, 5))
save(curvas.prac, file='SimulacionDensidadesPractica500.Rdata')
load(file='SimulacionDensidadesPractica500.Rdata')
ggplot(eigen.prac, aes(x=value, color=I(value))) +
  geom_density(size=1.3) + theme_minimal() + xlim(c(0, 6))+
  xlab('Parallel Analysis') + ylab('Densidad') +
  ggtitle('Distribución de los valores propios ~Songs') +
  stat_function(fun=dmp, args=list(ndf=n, pdim=p, var=1, log = FALSE ),
                col='purple', size=1.2)+
  geom_vline(xintercept = 1, color=I('#440154'), size=1.3)+
   geom_vline(xintercept = mean(eigen.prac$value), color=I('red'), size=1.3)+
  geom_vline(xintercept =.25, color=I('red'), size=1.3)
sum(eigen.prac$value > .25) #73
sum(eigen.prac$value > 1) #73

#cota de Kaiser
#regresion pcr con unif
remove(list=ls())
gc()
setwd("~/Desktop/ProyectoFinalRMT") #FIJAMOS EL DIIRECTORIO DE TRABAJo
load('parametros.Rdata')
load("Practico.Rdata")
eigen.prac <- eigen.muestra(train) #descompisicon muestral
(media <- mean(eigen.prac$value))
componentes <- round( sum(eigen.prac$value > media))
modelo.ray.pcr.unif <- pcr(y~., data=train, ncomp=25)
summary(modelo.ray.pcr.unif)
y.hat.ray.test.unif <- predict(modelo.ray.pcr.unif, ncomp=25 , newdata = test)
(RMSE(test$y, y.hat.ray.test.unif)) #10.24302
#regresion pcr con bootstrap
remove(list=ls())
gc()
setwd("~/Desktop/ProyectoFinalRMT") #FIJAMOS EL DIIRECTORIO DE TRABAJo
load('parametros.Rdata')
load("Practico.Rdata")
modelo.ray.pcr.boot <- pcr(y~., data=train, ncomp=31)
y.hat.ray.test.boot <- predict(modelo.ray.pcr.boot, ncomp=31 , newdata = test)
(RMSE(test$y, y.hat.ray.test.boot))#10.21018
#regresion pcr con RMT
remove(list=ls())
gc()
setwd("~/Desktop/ProyectoFinalRMT") #FIJAMOS EL DIIRECTORIO DE TRABAJo
load('parametros.Rdata')
load("Practico.Rdata")
modelo.ray.pcr.rmt <- pcr(y~., data=train, ncomp=27)
y.hat.ray.test.rmt <- predict(modelo.ray.pcr.rmt, ncomp=27 , newdata = test)
(RMSE(test$y, y.hat.ray.test.rmt))# 10.2187
############################################################
# pls
#regresion pcr con unif
remove(list=ls())
gc()
setwd("~/Desktop/ProyectoFinalRMT") #FIJAMOS EL DIIRECTORIO DE TRABAJo
load('parametros.Rdata')
load("Practico.Rdata")
modelo.ray.pcr.unif <- plsr(y~., data=train, ncomp=37)
summary(modelo.ray.pcr.unif)
y.hat.ray.test.unif <- predict(modelo.ray.pcr.unif, ncomp=37 , newdata = test)
(RMSE(test$y, y.hat.ray.test.unif)) #9.509669
#regresion pcr con bootstrap
remove(list=ls())
setwd("~/Desktop/ProyectoFinalRMT") #FIJAMOS EL DIIRECTORIO DE TRABAJo
load('parametros.Rdata')
load("Practico.Rdata")
modelo.ray.pcr.boot <- plsr(y~., data=train, ncomp=45)
y.hat.ray.test.boot <- predict(modelo.ray.pcr.boot, ncomp=45 , newdata = test)
(RMSE(test$y, y.hat.ray.test.boot))#11.49241
#regresion pls con RMT
remove(list=ls())
gc()
setwd("~/Desktop/ProyectoFinalRMT") #FIJAMOS EL DIIRECTORIO DE TRABAJo
load('parametros.Rdata')
load("Practico.Rdata")
modelo.ray.pcr.rmt <- plsr(y~., data=train, ncomp=50)
y.hat.ray.test.rmt <- predict(modelo.ray.pcr.rmt, ncomp=50 , newdata = test)
(RMSE(test$y, y.hat.ray.test.rmt))#10.596499