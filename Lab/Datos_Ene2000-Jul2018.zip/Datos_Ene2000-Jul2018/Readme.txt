Última actualización: 30 de Agosto de 2018; excepto INPC regional (Julio de 2018).
