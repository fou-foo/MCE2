## Ejercicio 1
set.seed(27)
muestra<-rnorm(10^5,pi,sqrt(sqrt(2)))
y_m<-cumsum(muestra)/(1:length(muestra))
plot(y_m,type='b',xlab = 'n',main="Normal, n=10^5",log = "x")
abline(h=pi,col="red")

muestras<-matrix(0,10^5,100)
promedio_ergodico<-matrix(0,10^5,100)
for(i in 1:100){
muestras[,i]<-rnorm(10^5,pi,sqrt(sqrt(2)))
}
for(i in 1:100){
  promedio_ergodico[,i]<-cumsum(muestras[,i])/(1:length(muestras[,i]))
}

matplot(x=1:10^5,y=promedio_ergodico,xlab = "n",ylab = "promedio ergodico",log="x",col=1:100,type="l")

gc()
muestras<-matrix(0,10^5,100)
promedio_ergodico<-matrix(0,10^5,100)

par(mfrow=c(1,2))
muestra<-rcauchy(10^5,pi,sqrt(2))
y_m<-cumsum(muestra)/(1:length(muestra))
plot(y_m,type='b',xlab = 'n',main="Cauchy, n=10^5",log = "x")
for(i in 1:100){
  muestras[,i]<-rcauchy(10^5,pi,sqrt(2))
}
for(i in 1:100){
  promedio_ergodico[,i]<-cumsum(muestras[,i])/(1:length(muestras[,i]))
}
gc()
matplot(x=1:10^5,y=promedio_ergodico,xlab = "n",ylab = "promedio ergodico",log="x",col=1:100,type="l")
gc()

par(mfrow=c(1,1))

#ej2
e_k<-function(x){
  return(exp(-x-1))
}
k2 <- function(variables) {
  return(1/(variables*variables))
}
x=seq(.5,100,.01)
curve(e_k(x),.5,20,ylab = '',col='red')
curve(k2(x),.5,20,ylab = '',add = T,col='darkblue')
legend(10, 0.2, c("e^-x-1","x^-2"), lty = 1, col = c("red","darkblue"),  adj = c(0, 0.6))


#ej3

epsilon<-function(n){
  return(sqrt(log(2/.05)/(2*n)))
}

N<-as.matrix(c(10, 50, 100, 250, 500, 1000, 2500, 5000, 10000))
blli<-function(n){
  rbinom(1,n,.4)/n
}
epsilons<-apply(N,MARGIN = 1,FUN = epsilon)
media_muestral<-apply(N,1,blli)
lim_inf<-media_muestral-epsilons
lim_sup<-media_muestral+epsilons
plot(x=N,y=lim_inf,type ='b',col="blue",ylim=c(0,1),log = 'x',xlab = 'n',ylab = 'p')
par(new=T)
plot(x=N,y=lim_sup,type ='b',col="blue",ylim=c(0,1),log='x',xlab = 'n',ylab = 'p')

abline(h=.4,col="red")
legend(200, 1, c("intervalo","p=.4"), lty = c(2,1), col = c("darkblue","red"),  adj = c(0, 0.6))

blli<-function(m,n){
  rbinom(m,n,.4)/n
}
n<-10000
simulaciones<-matrix(0,n,length(N))
INF<-matrix(0,n,length(N))
SUP<-matrix(0,n,length(N))
for(i in 1:length(N)){
  simulaciones[,i]<-blli(n,N[i])
  INF[,i]<-simulaciones[,i]-epsilons[i]
  SUP[,i]<-simulaciones[,i]+epsilons[i]
}
histog<-rep(0,9)
for(i in 1:9){
  histog[i]<-sum((INF[,i]<.4)*(SUP[,i]>.4))/n
}

barplot(histog,names.arg = N,ylim = c(0,1),col="lightblue",width = rep(1,9))
text(x=seq(.5,10.1,1.2),y=rep(.85,9),label=histog,col="red")
plot(x=N,y=lim_sup-lim_inf,xlab = 'n',ylab = 'longitud del intervalo',type='b')




# ejercicio 5
datos<-c(23.37, 21.87, 24.41, 21.27, 23.33, 15.20, 24.21, 27.52, 15.48, 27.19,
         25.05, 20.40, 21.05, 28.83, 22.90, 18.00, 17.55, 25.92, 23.64, 28.96,
         23.02, 17.32, 30.74, 26.73, 17.22, 22.81, 20.78, 23.17, 21.60, 22.37)

emprica<-function(x,datos){
  long<-length(datos)
  apply(as.matrix(x),1,function(y){return(sum(datos<=y)/long)})
}

plot(stepfun(seq(12,30,.01),emprica(seq(12,30.01,.01),datos),right = T),
     verticals=F,ylim=c(0,1),xlab="(x)",ylab="F(x)",main='')


qq<-function(datos){
  long<-length(datos)
  orden<-sort(datos)
  rango<-1:long
  normal<-qnorm(rango/(long+1))
  pendiente=(orden[long]-orden[1])/4
  print(pendiente)
  plot(normal,orden,xlab = "cuantil teorico (zp)",ylab = "Observaciones",xlim =c(-2,2),ylim=c(15,31))
  abline(a=orden[1]+(2*pendiente),b=pendiente,col="red")
  grid(nx = 5, ny = 4, col = "gray", lty = "dotted")
}

qq(datos)

epsilon<-function(n,alfa){
  return(sqrt(log(2/alfa)/(2*n)))
}
epsilon(length(datos),.05)
epsilon(length(datos),.01)

lower<-function(alfa,datos){
  datos<-sort(datos)
  n<-length(datos)
  low<-rep(0,n)
  F_x<-emprica(datos,datos)
  epsilons<-epsilon(30,alfa)
  low<-F_x-epsilons
  lower<-(low>=0)*low
  return(lower)
}

upper<-function(alfa,datos){
  datos<-sort(datos)
  n<-length(datos)
  up<-rep(0,n)
  F_x<-emprica(datos,datos)
  epsilons<-epsilon(30,alfa)
  up<-F_x+epsilons
  upper<-(up<=1)*up
  return(upper)
}

cuantiles_u<-qnorm(lower(.05,datos))
cuantiles_l<-qnorm(upper(.05,datos))
qq(datos)
par(new=T)
plot(cuantiles_u,sort(datos),xlim =c(-2,2),ylim=c(15,31),type='l',col="darkblue",xlab="",ylab = "",main="bandas al .95 de confianza")
par(new=T)
plot(cuantiles_l,sort(datos),xlim =c(-2,2),ylim=c(15,31),type='l',col="darkblue",xlab="",ylab = "")

cuantiles_u<-qnorm(lower(.01,datos))
cuantiles_l<-qnorm(upper(.01,datos))
qq(datos)
par(new=T)
plot(cuantiles_u,sort(datos),xlim =c(-2,2),ylim=c(15,31),type='l',col="darkblue",xlab="",ylab = "",main="bandas al .99 de confianza")
par(new=T)
plot(cuantiles_l,sort(datos),xlim =c(-2,2),ylim=c(15,31),type='l',col="darkblue",xlab="",ylab = "")

ppplot<-function(datos){
n<-length(datos)
props<-(1:n/(n+1))
x<-sort(rnorm(n))
nprops<-pnorm(x,mean(x),sd(x))
plot(nprops,props,xlab="percentiles N(0,1)",ylab = "Percentiles datos")
abline(a = 0,b=1,col="red")
}

ppplot(datos)


##EJ 6+
Tratamiento <- read.table("Tratamiento.csv",header = FALSE)

kernels<- function(x,h,datos) {
  datos<-as.vector(datos)
  n<-length(datos)
  aux<-(x-datos)/h
  kernel<-dnorm(aux)
  f_x<-sum(kernel)/(n*h)
  return(f_x)
}

i=1
orden<-sort(Tratamiento[,1])
bins<-rep(0,length(orden))
for(i in 1:length(orden)){
  bins[i]<-kernels(orden[i],30,t(Tratamiento))
}
kernel30<-bins
for(i in 1:length(orden)){
  bins[i]<-kernels(orden[i],20,t(Tratamiento))
}
kernel20<-bins
for(i in 1:length(orden)){
  bins[i]<-kernels(orden[i],60,t(Tratamiento))
}
kernel60<-bins

plot(orden,kernel30,type='l', col="red",ylim=c(0,.007),xlab = "x",ylab = "f(x)")
par(new=T)
plot(orden,kernel20,type='l', col="blue", lty=2,ylim=c(0,.007),xlab = "x",ylab = "f(x)")
par(new=T)
plot(orden,kernel60,type='l', col="black",lty=8,ylim=c(0,.007),xlab = "x",ylab = "f(x)")

legend(400, 0.006, c("h=20","h=30","h=60"), lty = c(2,1,8), col = c("blue","red","black"),  adj = c(0, 0.6))

sigma<-sqrt(var(orden))
h_optimo<-1.06*sigma*(length(orden)^-.2)
h_optimo


##ej 7
maiz_bd <- read.csv("Maiz.csv")
maiz<-maiz_bd[,1]
tortilla<-maiz_bd[,2]

x<-maiz
y<-tortilla

x_x<-x-mean(x)
y_y<-y-mean(y)
x_x2<-x_x*x_x
B1<-sum(x_x*y_y)/sum(x_x2)
B0<-mean(y)-(B1*mean(x))

plot(x,y)
abline(a=B0,b=B1,col="red")
legend(120, 762, c("y=684.95+.46x"), lty =1, col = c("red"),  adj = c(0, 0.6))



KERNEL_REGRESSION<-function(x,X,Y){
  n<-length(datos)
  aux1<-(x-X)
  kernel1<-dnorm(aux1)*Y
  kernel2<-dnorm(aux1)
  num<-sum(kernel1)
  den<-sum(kernel2)
  mx<-num/den
  return(mx)
}

reg<-rep(0,length(x))
orden<-sort(x)
for(i in  1:length(x)){
  reg[i]<-KERNEL_REGRESSION(orden[i],x,y)
}

plot(x,y,ylim=c(730,765),xlim = c(115,165),col="darkblue",xlab="x",ylab="y")
par(new=T)
plot(orden,reg,ylim=c(730,765),xlim = c(115,165),col="red",type = 'l',xlab="x",ylab="y")
