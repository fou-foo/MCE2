#Tarea 3  Inferencia estadistica
#aAlumna: Ram�rez Islas Cynthia Mariangel

#######################################################################################################
#1) En este ejercicio corroborar� mediante simulaciones la Ley de Grandes N�meros (LGN)

#Inciso a) Consulte su libro favorito de probabilidad y escriba la Ley Fuerte de Grandes Numeros (LFGN).
#Explique con sus palabras:
#La Ley de los Grandes n�meros dice que si repetimos muchas veces un mismo experimento,
#(un n�mero de veces considerablemente grande)la frecuencia de que suceda un cierto evento tiende a ser una constante.
#La Ley Fuerte de los Grandes n�meros dice que si tenemos una sucesi�n infinita de variables aleatorias independientes
#y con la misma distribuci�n(adem�s con media y varianza conocidas) entonces el promedio de �stas variables
#converger� a dicha media con una probabilidad muy grande.
 DE HECHO LA LEY FUERTE PUEDE RELAJAR LA CONDICION DE LA CONDICION DEL SEGUNDO MOMENTO

#Inciso b) Simule una muestra {x1, . . . xn} de una v.a. Normal(pi, raiz(2)) de tamano n = 10^5.
#Defina ym = suma desde i=1 hasta i=m de xi/m y grafique esta cantidad.

#Funcion ym.
#Entrada: tama�o n, media, , desviacion est�ndar d
#Salida: Promedios
ym<-function(n,m,d){
  x<-rnorm(n,mean = m,sd = d)  #Simulacion de una muestra normal de tama�o n
  y<-cumsum(x)/seq_along(x) #Calcula el promedio de dicha muestra
  return(y)
}

#Gr�fica de ym
plot(ym(n=10^5, m=pi,d=sqrt(sqrt(2)) ), type="l", main = "Gr�fica de Frecuencias", xlab = "Promedios", ylab = "Frecuencia", col = "red")
abline( pi,0)  #L�nea de referencia de la media= pi

#Qu� observa? �C�mo est� esto relacionado con la LGN?
#Podemos notar que teniendo una sucesion muy grande de variables aleatorias con la misma distribucion y par�metros,
#los promedios de dichas v.a. convergen a su media que es igual a pi, con lo cual estamos probando emp�ricamente la LGN

#Inciso c) Repita el procedimiento anterior 100 veces y grafique las ym de cada iteracion sobre una misma grafica.
repetir<-replicate(n = 100,ym(n=10^5, m=pi,d=sqrt(sqrt(2))))
hist(repetir, main = "Histograma de Frecuencias", xlab = "Valor del Promedio", ylab = "Frecuencia")

#�Qu� observa? que repetiendo el proceso 100 veces, los promedios de las v.a. covergen a su media

#Inciso d)Repita los dos incisos anteriores para una distribucion Cauchy(pi,raiz(2)).

#Funcion ym2
#Entrada: tama�o n, media m y escala d
#Salida: Promedios
ym2<-function(n,m,d)
  {
  x<-rcauchy(n,location = m,scale = d) #Muestra de una Cauchy de tama�o n, con media pi y varianza d
  y<-cumsum(x)/seq_along(x)
  return(y)
}

#Gr�fica de ym2
plot(ym2(n=10^5,m=pi,d=sqrt(sqrt(2)) ), type="l", main = "Gr�fica de Frecuencias", xlab = "Promedio", ylab = "Frecuencia", col = "red")
abline(pi, 0)  #L�nea de referencia de la media= pi

#�Que observa? �Como esta esto relacionado con la LGN?
# observamos que no hay convergencia ya que no se cumplen las hip�tesis de la LGN, ya que la Cauchy no  tiene momentos definidos
#por lo cual al realizar las simulaciones los promedios no convergen

#Repita el procedimiento anterior 100 veces y grafique las ym2 de cada iteracion sobre una misma grafica.
repetir2<-replicate(n = 100,ym2(pi,2**0.25,10**5))
hist(repetir2, main = "Histograma de Frecuencias", xlab = "Espacio Muestral", ylab = "Frecuencia", col = "blue")

#Que observa? Obervamos que las frecuencias de los promedios no convergen hacia la media a diferencia del caso anterior

#######################################################################################################
#Pregunta 3
#Sea alpha = 0.05 y p = 0.4. Mediante simulaciones, realice un estudio para ver
#que tan a menudo el intervalo de confianza contiene a p (la cobertura).
#Haga esto para n =10; 50; 100; 250; 500; 1000; 2500; 5000; 10000. Grafique la cobertura contra n.

Num_sim <- 1000 #Numero de simulaciones
alpha <- 0.05 # alpha

set.seed(100) # fijando semilla
# Almacenamos en un vector los tama�os de la muestra (9 tama�os)
n <- c(10, 50, 100, 250, 500, 1000, 2500, 5000, 10000)

#Funcion  cae_int .Calcula el # de veces que el intervalo de confianza contiene a p
#Entrada: n num de binomiales
#Salida: # de veces que el la p estimada est� en el intervalo de confianza.
Cae_int <- function(n){
  exitos <- 0
  epsilon <- sqrt((1/(2*n))*(log(2/alpha)))
  p_est <- mean(rbinom(n, 1, 0.4))
  if(abs(p_est-0.4) < epsilon  )
  {
    exitos <- exitos + 1
  }
  return(exitos)
}

#Creamos una matriz donde se guardar�n los resultados de la simulacion,
# Es de tama�o 9 ya que son 9 tama�os de muestra.
#En la primera columna se guardan las veces que no est� en el intervalo y en la segunda las veces que si
Simulacion <- matrix(0, 9, 2)


# LLenaremos la matriz anterior utlizando la funcion cae_int, para cada  tama�o de muestra
for(i in 1:9){
  Simulacion[i, ]<-table(replicate(Num_sim, Cae_int(n[i])))
}

#Impresi�n de los resultados de la simulacion
Simulacion



Intervalo <- matrix(0, 9,2)
epsilon<-0
p_est<-0

for(i in 1:9)
{
  epsilon[i] <- sqrt((1/(2*n[i]))*(log(2/alpha)))
  set.seed(100) # fijando semilla
  p_est[i] <- mean(rbinom(n[i], 1, 0.4)) #Calcula la media
  Intervalo[i, ] <- c(p_est[i] - epsilon[i], p_est[i] + epsilon[i]); #Hace la diferencia entre la media y epsilon

  if(Intervalo[i, 1] < 0)
  {
    Intervalo[i, 1] <- 0
  }

  if(Intervalo[i, 2] > 1)
  {
    Intervalo[i, 2] <- 1
  }

}

IntSup <-Intervalo[, 1] # intervalo superior
IntInf <-Intervalo[,2] # intervalo inferior

#Grafica la cobertura contra n.
plot(n, rep(.4, 9), type="l", ylim=c(0.2,.6),
     xlab = "Tama�o de  muestra", main = "Intervalo de confianza", ylab="p = 0.4")

lines(n, IntSup,  type="l", col="blue")
lines(n, IntInf,  type="l", col="blue")


########################################################################################################
#Ejercicio 5
#Inciso a)Escriba una funcion en R que calcule la funcion de distribuci�n emp�rica para un conjunto de datos
#La funcion debe tomar como parametros al punto x donde se evalua y al conjunto de datos D.

#Guardamos en un vector los datos que ocuparemos
D<-c(23.37, 21.87, 24.41, 21.27, 23.33, 15.20, 24.21, 27.52, 15.48, 27.19, 25.05, 20.40, 21.05, 28.83, 22.90, 18.00, 17.55, 25.92, 23.64, 28.96, 23.02,17.32, 30.74, 26.73, 17.22, 22.81, 20.78, 23.17, 21.60,22.37)

#Funcion DistEmpirica
#Entrada: x punto donde se eval�a la func de distribucion, datos conjunto de datos
#Salida: probabilidad de X=x
DistEmpirica<-function(x,datos){
  proba<-(sum(datos<x))/(length(datos))
  return(proba)
}

#acomodamos los datos
y<-sort(D)
dif<-vector()
for(i in 1:length(D)-1){  #recorremos los datos
  dif[i]<-abs(y[i]-y[i+1])  #Calcula  diferencias
}
m<-min(dif)  #Menor rango entre las variables

#Generamos el espacio muestral
datosord<-seq(from = min(D),to = max(D)+m,by = m)  #vector que guarda los datos acomodados
f<-vector()
for(i in 1:length(datosord)){  #Recomerremos los datos ya acomodados
  f[i]<-DistEmpirica(datosord[i],D)   #Calculamos la distribucion empirica para cada dato

}

#Grafica de la Distribucion de Probabilidad Empirica
plot(datosord,f,type = "b",main = "Funci�n de Distribuci�n Empirica",xlab  = "Diametros de agave",ylab  = "Probabilidad")

#Ponga atencion a los puntos de discontinuidad? �Qu� observa?
#Podemos notar que existen discontinuidades

# Distribucion de Probabilidad Empirica acumulada
d<-vector()
for(i in 1:length(datosord)){
  d[i]<-DistEmpirica(datosord[i],D)  #Vector que guarda la probabilidad empirica acumulada
}

plot(stepfun(datosord,c(d,1), right=F), verticals = F,main = "Funcion de Distribucion Empirica Acum",xlab  = "Diametros de agave",ylab  = "Probabilidad", col="black")
lines(datosord,f,type = "l", col="blue")    #Incluimos Gr�fica de la distribuci�n empirica para compararlas

#5 b) Escriba una funcion en R que determine la grafica Q-Q normal de un conjunto de datos.
#La funcion debe tomar como parametro al conjunto de datos. Usando esta funcion, determine la grafica Q-Q normal.

#Funcion Cuantiles
#Entrada: datos conjunto de datos
#Salida: Cuantiles
Cuantiles<-function(datos){
  cuanorm<-vector()  #Vector que guarda los cuantiles normales correspondientes a la "probabilidad empirica" de los datos
  estand<-vector()  #Vector que guarda los datos ordenados estandarizados
  #y<-sort(D)
  for(i in 1:length(datosord)){ #Genera los cuantiles normales
    cuanorm[i]<-qnorm(DistEmpirica(datosord[i],D))
  }


  return(results<-list(cuanorm=cuanorm))  #Genera como resultado una lista con el vector de los cuantiles normales
}

#Genera los Q-Q plots accediendo al vector de la lista
plot(Cuantiles(D)[[1]],datosord,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue")
Cuantiles(D)[[1]]

#Que observa? Podemos notar que la gr�fica

#c) A�ada a la funcion anterior la opcion de que grafique la banda de confianza, de cobertura 1,
#basada en el estadistico de Kolmogorov-Smirnov. La funcion debe tomar como parametros al conjunto de datos
#y el nivel de confianza 1 . Aplique esta funcion al conjunto de datos para un nivel de confianza 1 -alpha = 0.95, 0.99.
#Que observa?

#Para calcular las Bandas de confianza se consider� el estadistico de Kolmogorov con n=30
upper<-vector()
lower<-vector()
BandaC<-function(D,alpha){
  if (alpha == 0.05) {
    K <- 0.24170 }  #Estadistico de Kolmogorov
  if (alpha == 0.01){
    K <- 0.28987 }  #Estadistico de kolmogorov

  #Calculamos los intervalos de confianza
  for(i in 1:length(datosord)){ lower[i]<-qnorm(DistEmpirica(y[i],D)+K)}
  for(i in 1:length(datosord)){ upper[i]<-qnorm(DistEmpirica(y[i],D)-K)}

  return(resultados<-list(lower=lower,upper=upper))
}

#Graficamos la banda de Confianza

#alpha=0.05
plot(Cuantiles(D)[[1]],datosord,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue")
lines(BandaC(D,0.05)[[1]],datosord, col="blue")
lines(BandaC(D,0.05)[[2]],datosord, col="blue")

#alpha=0.01
plot(Cuantiles(D)[[1]],datosord,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue")
lines(BandaC(D,0.01)[[1]],datosord, col="blue")
lines(BandaC(D,0.01)[[2]],datosord, col="blue")


#Inciso d) Escriba una funci�n en R que determine el grafico de probabilidad normal. La funci�n
#debe tomar como par�metro al conjunto de datos. �Qu� observa?

#Definimos vectores
ProN<-vector()
Proest<-vector()

#Funcion PP
#Entrada: D conjunto de datos
#Salida: lista
PP<-function(D){

  for(i in 1:length(datosord)){ Proest[i]<-DistEmpirica(datosord[i],D)}
  for(i in 1:length(datosord)){ ProN[i]<-pnorm(datosord[i],mean=mean(D), sd=sd(D))}

  return(resultados<-list(ProN=ProN, Proest=Proest))
}

PP(D)[[1]]

#Gr�fica de P-P plot
plot(PP(D)[[1]], PP(D)[[2]], type="p", xlab="Probabilidad normal", ylab="Proba empirica", main="P-P normal", col="black", pch=20)

#e) >Los datos anteriores se distribuyen normalmente? Argumente.
#Para pode afirmar que los datos se distribuyen normalmente, la gr�fica deber�a ajustarse a una recta

#######################################################################################################
#Pregunta 6
#Inciso a) Escriba una funci�n en R que calcule el estimador de la densidad por el m�todo de
#kerneles. La funci�n deber� recibir al punto x donde se evalua al estimador, al par�metro
#de suavidad h, al kernel que se utilizar� en la estimaci�n y al conjunto de datos

#Funcion kernelnormal
#Entrada: valor x (donde se evaluar� el estimador), D conjunto de datos , h par�metro de suavidad
#Salida: estimacion de la funci�n de densidad en el punto x mediante por el m�todo del kernel
kernelnormal<-function(x,D,h){

  kerneln<- (1/(sqrt(2*pi)*h))*exp(-(x-D)^2/(2*h^2))
  fxh<-(1/85)*c(sum(kerneln))

  return(fxh)

}

#Cargue en R al archivo \Tratamiento.csv", el cual contiene la duracion de los perioodos
#de 3tratamiento (en diass) de los pacientes de control en un estudio de suicidio. Utilice
#la funcion del inciso anterior para estimar la densidad del conjunto de datos para h =
#20; 30; 60. Grafique las densidades estimadas

#Como utlizaremos el arhico .csv, se necesita fijar el espacio de trabajo en donde se encuentra el archivo
#setwd("C:/Users/cynth/Documents/Tarea3_estadistica")

#Leemos archivo .csv
datos<-as.vector(read.csv(file="Tratamiento.csv"))


#Estimacion de densidad con h=20
f<-c(kernelnormal(0,datos,20),kernelnormal(10,datos,20),kernelnormal(20,datos,20), kernelnormal(30,datos,20 ), kernelnormal(40,datos,20), kernelnormal(50,datos,20 ), kernelnormal(60,datos,20 ),  kernelnormal(70,datos,20 ),kernelnormal(90,datos,20 ),kernelnormal(100,datos,20),kernelnormal(110,datos,20 ))

#Estimacion de densidad con h=30
g<-c(kernelnormal(10,datos,30),kernelnormal(20,datos,30), kernelnormal(30,datos,30 ), kernelnormal(40,datos,30), kernelnormal(50,datos,30 ), kernelnormal(60,datos,30 ),  kernelnormal(70,datos,30 ), kernelnormal(80,datos,30 ),kernelnormal(90,datos,30 ))

#Estimacion de densidad con h=60
h<-c(kernelnormal(-10,datos,60), kernelnormal(0,datos,60),kernelnormal(20,datos,60),kernelnormal(40,datos,60), kernelnormal(60,datos,60 ), kernelnormal(80,datos,60), kernelnormal(100,datos,60 ), kernelnormal(120,datos,60 ),kernelnormal(140,datos,60 ))

#Gr�fica de densidad con h=20
plot(c(0,10,20,30,40,50,60,70,90,100,110),f, type="b", main="Estimaci�n densidad con h=20", xlab = "x", ylab = "densidad")

#G  r�fica de densidad con h=30
plot(c(10,20,30,40,50,60,70,80,90), g, type="b",main="Estimaci�n densidad con h=30", xlab = "x", ylab = "densidad")

#Gr�fica de densidad con h=60
plot(c(-10,0,20,40,60,80,100,120,140 ), h, type="b",main="Estimaci�n densidad con h=80", xlab = "x", ylab = "densidad")

#�Cual es el mejor valor para h?
#De acuerdo a las gr�ficas anteriores, considero que el mejor valor de h para la estimacion de la funci�n de densidad es h=20
#ya que tiene mayor precision sobre todo en x> 40


