#########################################################################################################################################################
#Ana Beatriz Rodriguez Mendoza.
#Inferencia Estadistica.
#Parte 2 de la tarea 3.
#Texto sin acentos.
#########################################################################################################################################################




#########################################################################################################################################################
#Ejercicio1
#b) Simule una muestra {x1, . . . xn} de una v.a. Normal(pi,2^(1/2)) de tamanio n = 10^5.
#Defina ym = suma desde i=1 hasta m de xi/m y grafique esta cantidad.

#Funcion que calcula la suma de las v.a, con distribucion Normal
#con paramteros media, desviacion estandar y tamanio de la muestra.
ym<-function(med=pi,de=2^(1/4), n=10^5){
  x<-rnorm(n,mean = med,sd = de) #Muestra normal con media pi y varianza 2^(1/2.)
  suma<-cumsum(x)/seq_along(x) #Acumula las sumas.
  return(suma)
}

set.seed(100) # fijando semilla
plot(ym(), main = "Convergencia", xlab = "Espacio Muestral", ylab = "Frecuencia", col = "red",type = "l")
abline(pi,0, col="blue")

#Apartir de lo anterior se observa  que la funcion ym converge
#a pi

#c) Repita el procedimiento anterior 100 veces y grafique las ym de cada iteracion
#sobre una misma grafica.Que observa?

#Se hace un histograma para observar que valores son mas frecuentes.
simulacion<-replicate(n = 100,ym(pi,2**0.25,10**0.25))
hist(simulacion, main = "Histograma y_m", xlab = "Tamanio de la  muestra", ylab = "Frecuencia", col = "blue")

#Se observa en el histograma que la mayor�?a de los valores caen enla media, converge a pi.

#d)Repita los dos incisos anteriores para una distribucion Cauchy(pi,2^(1/2)).Que observa?

#Funcion que calcula la suma de las v.a, con distribucion Normal
#con paramteros media, desviacion estandar y tamanio de la muestra.
Cauchy<-function(med=pi,de=2^(1/4), n=10^5){
  x<-rcauchy(n = n,location = med,scale = de)
  suma<-cumsum(x)/seq_along(x)
  return(suma)
}

plot(Cauchy(), type="l", xlab = "Tamanio de la muestra x", ylab = "",
     main = "Simulaci?n x~Cauchy(pi, sqrt(2))")
abline(pi, 0, col="red")

#Notamos que no tiene convergencia, como se esperaba ya que no existe la esperanza en Cauchy.

#Repita el procedimiento anterior 100 veces y grafique las Cauchy de cada iteracion

simula<-replicate(n = 1000,Cauchy(pi,2^(1/4),10^(1/4)))
hist(simula, main = "Histograma de Frecuencias", xlab = "Espacio Muestral", ylab = "Frecuencia", col = "blue")

#Se puede observar que all incrementar el numero de muestras, la media muestral no se aproxima a su media poblacional, no converge.

#######################################################################################################################################
#Ejercicio 3
#Sea alpha = 0.05 y p = 0.4. Mediante simulaciones, realice un estudio para ver que tan
# a menudo el intervalo de confianza contiene a p (la cobertura). Haga esto para n =
#  10, 50, 100, 250, 500, 1000, 2500, 5000, 10000. Grafique la cobertura contra n.


N <- 10^4 #Numero de simulaciones
a <- 0.05 # alpha, la variable del intervalo de confianza
p <- 0.4 # Bernoulli(p)
n <- c(10, 50, 100, 250, 500, 1000, 2500, 5000, 10000) # Tamaios de la muestra

#Funcion que calcula el numero de veces (exitos) que la p estimada cae en el intervalo de confianza, con parametro n
#el vector que contiene a los tamanios de la muestra.
NumIC <- function(n){
  exitos <- 0
  epsilon <- sqrt((1/(2*n))*(log(2/a)))
  p.estimado <- mean(rbinom(n, 1, p))
  if(abs(p.estimado-p) < epsilon  )
  {
    exitos <- exitos + 1
  }
  return(exitos)
}

Simulacion <- matrix(0, 9, 2)

for(i in 1:9){ # Para cada muestra
  Simulacion[i, ]<-table(replicate(N, NumIC(n[i])))
}

colnames(Simulacion) <-  c("Fuera IC", "Dentro IC")
rownames(Simulacion) <-  c("n = 10", "n = 50", "n = 10" ,"n = 250",
                           "n = 500", "n = 1000", "n = 2500", "n = 5000",
                           "n = 10000")

Simulacion

#El tamanio de n, para que la longitud del intervalo sea menor que 0.05.
n=1
while(2*sqrt((1/(2*n))*(log(2/a)))>=0.05){
  n<-n+1
}
n





#######################################################################################################################################
#Ejercicio5
#b) Escriba una funcion en R que determine la grafica Q-Q normal de un conjunto de datos.
#La funcion debe tomar como parametro al conjunto de datos. Usando esta funcion, determine la grafica Q-Q normal.
#Que observa? R: La curva se encuentra muy suavizada

#Funciona que genera los cuatiles con parametro los datos.
Cuantiles<-function(datos){
  cuantiles[] #Cuantiles
  estand<-vector()  #Vector que guarda los datos ordenados estandarizados
  dato<-sort(datos)
  for(i in 1:length(dato)){ #Genera los cuantiles normales
    cuanorm[i]<-qnorm(FEmpirica(dato[i],datos))
  }
  return(results<-list(cuanorm=cuanorm))  #Genera como resultado una lista con el vector de los cuantiles normales
}

#Genera los Q-Q plots accediendo al vector de la lista
plot(Cuantiles(datos)[[1]],y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue")
Cuantiles(datos)[[1]]

#c) Aniada a la funcion anterior la opcion de que grafique la banda de confianza, de cobertura 1,
#basada en el estad??stico de Kolmogorov-Smirnov. La funcion debe tomar como parametros al conjunto de datos
#y el nivel de confianza 1. Aplique esta funcion al conjunto de datos para un nivel de confianza 1  = 0.95, 0.99.
#Que observa?

#Para calcular las Bandas de confianza se tomo en cuenta el estadistico de Kolmogorov con n=30
upper<-vector()
lower<-vector()
BandaC<-function(datos,alpha){
  if (alpha == 0.05) {
    D <- 0.24170 }  #Estadistico de Kolmogorov
  if (alpha == 0.01){
    D <- 0.28987 }  #Estadistico de kolmogorov

  #Calculando los intervalos de confianza
  for(i in 1:length(y)){ lower[i]<-qnorm(FEmpirica(y[i],datos)+D)}
  for(i in 1:length(y)){ upper[i]<-qnorm(FEmpirica(y[i],datos)-D)}

  return(resultados<-list(lower=lower,upper=upper))
}
#Graficando la banda de Confianza
#alpha=0.05
plot(Cuantiles(datos)[[1]],y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue")
lines(BandaC(datos,0.05)[[1]],y, col="red")
lines(BandaC(datos,0.05)[[2]],y, col="red")

#alpha=0.01
plot(Cuantiles(datos)[[1]],y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue")
lines(BandaC(datos,0.01)[[1]],y, col="red")
lines(BandaC(datos,0.01)[[2]],y, col="red")
SE VE QUE ESTA BIEN EL CODIGO PERO NO CORRIO, PROCURA PROBARLO SIEMPRE
ANTES DE ENVIARLO, LIMPIA TU ENVIROMENT GLOBAL CONSTANTEMENTE


#######################################################################################################################################
#Ejercicio 6
#a) Escriba una funcion en R que calcule el estimador de la densidad por el metodo de kerneles. La
#funcion debera recibir al punto x donde se evalua al estimador, al parametro de suavidad h, al kernel
#que se utilizara en la estimacion y al conjunto de datos.


rm(list = ls()) # limpiando memoria

# Cargar el archivo correspondiente "Tratamiento.csv"
Tratamiento.datos <- read.csv(file.choose(), header=TRUE)

# Funcion que estima la densidad por el metodo de Kernel de Gauss, con parametros, h el parametro de suavidad
DensidadKernel <-function(x, h, datos){
    gauss <- sapply(datos, function(a) ((1/sqrt(2*pi))*exp((-((x-a)^2)/(2*h^2))))/(n*h))
    plot(x, rowSums(gauss),
         type = "l", xlab = "x", ylab = "density",
         main=paste("Regresion por kernel h =", h),lwd = 2)
    rug(x, lwd = 2)
    out <- apply(gauss, 2, function(b) lines(x, b))
    lines(density(datos), lty = 3)
  }

#b) Cargue en R al archivo \Tratamiento.csv", el cual contiene la duracion de los periodos
#de tratamiento (en d?as) de los pacientes de control en un estudio de suicidio. Utilice
#la funcion del inciso anterior para estimar la densidad del conjunto de datos para
#$h = 20, 30, 60$ . Graque las densidades estimadas. >Cual es el mejor valor para h? Argumente.

# El archivo contiene la duracion de los periodos de tratamineto
# (en d?as) de los pacientes de control en un estudio de suicidio
tratamiento <- datos.matrix(Tratamiento.datos)
LA LINEA ANTERIOR NO FUNCIONA
tratamiento <- as.matrix(Tratamiento.datos)

# puntos a evaluar, se pude modificar segun el usuario
x <- seq(from = min(tratamiento) - 1, to = max(tratamiento) + 1, by = .1)

# Con h igual a 20
h <- 20 # parametro de suavizamiento
n <- length(tratamiento) # numero de observaciones

DensidadKernel(x, 20, tratamiento)

# Con h igual a 30
h <- 30
DensidadKernel(x, 30, tratamiento) # estimaci?n, karnel gaussiano

# Con h igual a 60
h <- 60
DensidadKernel(x, 60, tratamiento)



#El parametro de suavizamiento de 30, se va a considerar el mejor entre el de 20 y el de 60.
#Si h=20 es muy chico,lo cual deja ver curvas no lo suficientemente suavizadas y con un h de 60,
#se suaviza de mas.



##########################################################################################################################################################3#
#Ejercicio7
#Cargue en R al conjunto de datos "Maiz.csv", el cual contiene el precio mensual de la tonelada
#de maiz y el precio de la tonelada de tortillas en USD. En este ejercicio tendra que estimar
#los coeficientes de una regresion lineal simple.
#a) Calcule de forma explicita la estimacion de los coeficientes via minimos cuadrado y ajuste
#la regresion correspondiente. Concluya.

rm(list = ls()) # limpia

#Carga el archivo a usar
datos <- read.csv(file.choose(), header=TRUE)

head(datos)
names(datos) <- c('P..Tonelada.Maiz', 'P..Tonelada.Tortilla')
plot(datos$P..Tonelada.Maiz, datos$P..Tonelada.Tortilla,
     ylab = "Precio Tonelada de Tortillas (Dolares)",
     xlab = "Precio Tonelada de Maiz (Dolares)",  main="Regresion por MCO", pch=20)
lm(datos$P..Tonelada.Tortilla~datos$P..Tonelada.Maiz)

#se estima los ceoficiente explicitamente por el metodo de minimos cuadrados.

# Media
mediaT<-sum(datos$P..Tonelada.Tortilla)/length(datos$P..Tonelada.Tortilla)

mediaMaiz <-sum(datos$P..Tonelada.Maiz)/length(datos$P..Tonelada.Maz)
LA LINEA ANTERIOR TAMBIEN ESTA MAL
mediaMaiz <-sum(datos$P..Tonelada.Maiz)/length(datos$P..Tonelada.Maiz)

# Varianza
varMaiz <-sum((datos$P..Tonelada.Maiz - mediaMaiz)^2)/(length(datos$P..Tonelada.Maiz)-1)
# covarianza
cov <- sum(((datos$P..Tonelada.Maiz - varMaiz))*((datos$P..Tonelada.Tortilla - mediaT)))/(length(datos$P..Tonelada.Maiz)-1)
#coeficiente de regresi?n
b.estimada <- cov/varMaiz # beta estimada (pendiente de la regresion)
a.estimada <- mediaT-b.estimada*mediaMaiz # (constante de la regresion)

a.estimada #beta 0
b.estimada #beta 1

plot(datos$P..Tonelada.Maiz, datos$P..Tonelada.Tortilla,
     ylab = "Precio Tonelada de Tortillas (Dolares)",
     xlab = "Precio Tonelada de Maiz (Dolares)",
     main="Regresi?n por MCO", pch=20)
lines(100:200, a.estimada+b.estimada*(100:200), type = "l",col="steelblue", pch=3, lwd = 2)

#b) Calcule de forma explicita la estimacion de los coeficientes via regresion no-parametrica tipo kernel

RKernel<- function(x, y, h) {
  x.evaluar <- seq(from = min(x) - 1, to = max(x) + 1, by = .1) # puntos a evaluar
  n <- length(x) # numero de observaciones

  gauss <- sapply(x, function(x) (((1/sqrt(2*pi))*exp((-((x.evaluar-x)^2)/(2*h^2))))/(n*h))) # kernel gaussiano

  Y<-matrix(0L, 462, 200) # generando matriz para guardar resultados de kernel ponderado
  for (i in 1:200){
    Y[ ,i] <- ((((1/sqrt(2*pi))*exp((-((x.evaluar-x[i])^2)/(2*h^2))))*y[i])/(n*h))
  } # end for
  KernelXY <-rowSums(Y)
  kernelX <-rowSums(gauss)

  X <- KernelXY/kernelX

  plot( x,y, main=paste("Regresion por kernel h =", h),
        xlab="Precio Tonelada de Maiz (Dolares)", ylab="Precio Tonelada de Tortillas (Dolares)", pch=20)
  lines(x.evaluar, X, type = "l",col="steelblue", pch=3, lwd = 2) #contra el grill

}


x<- datos$P..Tonelada.Maiz
y <- datos$P..Tonelada.Tortilla

#Se evalua
RKernel(x,y,1)
RKernel(x,y,1.37)
RKernel(x,y,2)
RKernel(x,y,3)
RKernel(x,y,4)


plot(datos$P..Tonelada.Maiz, datos$P..Tonelada.Tortilla,
     ylab = "Precio/Tonelada de Tortillas",
     xlab = "Precio/Tonelada de Maiz ",
     main="Regresion por MC",
     pch=20)
lines(100:200, a.estimada+b.estimada*(100:200), type = "l",col="steelblue", pch=3, lwd = 2)

#c) Compare ambos resultados. Que diferencias observa?
#Al utilizar el metodo de Kernel se obtiene una mejor aproximacion.
