#Tarea3
#Ejercicio 1
rm(list=ls())
#Bibliotecas usadas
library(ggplot2)
library(dplyr)

###Definición de funciones
#Genera una muestra aleatoria de una normal N(mu, sigma2) de tamaño n
muestra_normal <- function(n, mu, sigma2){
  rnorm(n, mean = mu, sd = sqrt(sigma2))
}

#Genera una muestra aleatoria de una Cauchy(mu, sigma2) de tamaño n
muestra_cauchy <- function(n, mu, sigma){
  rcauchy(n, location = mu, scale = sigma)
}

#Calcula las medias parciales (ym) de cada muestra
medias <- function(muestra){
  cumsum(muestra)/seq_along(muestra)
}

#Función auxiliar para agrupar a los datos de acuerdo
#a la muestra a la que pertenecen y graficar cada muestra de distinto color
agrupar_columnas <- function(simulacion, n, repeticiones) {
  lapply(1:repeticiones,
         function(k){
           ck <- data.frame(1:n,simulacion[, k])
           names(ck) <- c("m", "ym")
           ck$group <- paste0("S",k)
           ck
         })
}

#Grafica los resultados del experimento
#Agrupa los datos de acuerdo a la muestra a la que pertenecen
graficar_simulacion <- function(simulacion, n, repeticiones){
  s_grupos <- bind_rows(agrupar_columnas(simulacion, n, repeticiones))
  ggplot(s_grupos, aes(x= m, y = ym, group=group, col=group), log10="y") +
    geom_point(alpha = 0.4, size = .4, shape = 1, show.legend=FALSE ) +
    scale_y_continuous(breaks = pretty(min(simulacion): max(simulacion),
                                       n = 10)) +
    theme_bw() +
    labs(title = paste("Simulación de", repeticiones ,"muestras de tamaño",n)) +
    theme(plot.title = element_text(hjust = 0.5))
}

#Genera muestras de una Normal de tamaño n tantas veces como 'repeticiones',
#además, grafica los resultados
simular_normal <- function(mu, sigma2, n, repeticiones){
  simulacion_normal <- replicate(repeticiones,
                                 medias(muestra_normal(n, mu, sigma2)))
  graficar_simulacion(simulacion_normal, n, repeticiones) +
    labs(subtitle = paste("Distribución: N(",mu,",",sigma2,")"))
}

#Genera muestras de una Cauchy de tamaño n tantas veces como 'repeticiones',
#además, grafica los resultados
simular_cauchy <- function(mu, sigma2, n, repeticiones){
  simulacion_cauchy <- replicate(repeticiones,
                                 medias(muestra_cauchy(n, mu, sigma2)))
  graficar_simulacion(simulacion_cauchy, n, repeticiones) +
    labs(subtitle = paste("Distribución: Cauchy(",mu,",",sigma2,")"))
}

###Uso de las funciones
set.seed(123)

#Simulación de la Normal
n = 500
mu = pi
sigma2 <- sqrt(2)
repeticiones = 100
simular_normal(mu,sigma2,n,repeticiones)

#Simulación de la Cauchy
n = 500
mu = pi
sigma <- sqrt(2)
repeticiones = 100
simular_cauchy(mu,sigma,n,repeticiones)


#----------------------------------------------------------------------------
#Ejercicio 3
rm(list=ls())
#Bibliotecas usadas
library("ggplot2")

#Calcula los extremos de un intervalo de confianza
intervalo_confianza <- function(muestra, alfa){
  n <- length(muestra)
  p_est <- mean(muestra)
  e_n <- sqrt((1/(2*n)) * log(2/alfa))
  l_inf <- p_est - e_n
  l_sup <- p_est + e_n
  c(l_inf, l_sup)
}

#Primero se presenta un ejemplo
p <- .4
alfa <- .05
n <- c(10, 50,100,250,500,1000,2500,10000)

intervalos <- sapply(n,
                     function(k,proba, alfa){
                       intervalo_confianza(rbinom(k,1,proba), alfa)
                     }, proba = p, alfa = alfa)
longitud <- apply(intervalos, 2, diff); longitud
lower <- intervalos[1,]
upper <- intervalos[2,]
df <- data.frame(as.factor(n), lower, upper, rep(p,length(n)))
names(df)[c(1,4)] <- c("n", "probas")
n_longitud <- data.frame(as.factor(n), longitud)
names(n_longitud)[1] <- c("n")

#Se grafican los intervalos de confianza obtenidos
ggplot() +
  geom_errorbar(data=df, mapping=aes(x=n, ymin=upper, ymax=lower), width=0.2, size=1) +
  geom_point(data=df, mapping=aes(x=n, y=probas), size=2, shape=21, fill="white") +
  ylab("Intervalo de confianza")

#Se aprovecha el ejemplo para graficar las longitudes obtenidas
#Estas sólo dependen de n y alfa, por lo que no hay que hacer mas repeticiones
ggplot(data = n_longitudes) +
  geom_bar(aes(x = n, y = longitud), stat = "identity", width = .1)
LA VARIABLE n_longitudes NO ESTA DEFINIDA
ggplot(data = n_longitud) +
    geom_bar(aes(x = n, y = longitud), stat = "identity", width = .1)


#Ahora se realiza 10^4 veces por cada n y se estima la cobertura

#Funcion que genera un intervalo de confianza aleatorio
#y dice si p está en él
experimento_intervalo <- function(n, p, alfa){
  intervalo <- intervalo_confianza(rbinom(n,1,p), alfa)
  esta_en_intervalo <- (intervalo[1] <= p) && (p <= intervalo[2])
  esta_en_intervalo
}

#Estima la proporción de las repeticiones en las que p cae dentro
#del intervalo de confianza
estimar_cobertura <- function(n, p, alfa, repeticiones) {
  simulacion <- replicate(repeticiones, experimento_intervalo(n, p, alfa))
  t_frecuencias <- table(simulacion)
  cobertura <- t_frecuencias["TRUE"]/repeticiones
  names(cobertura) <- c(paste(n))
  cobertura
}

p <- .4
alfa <- .05
n <- c(10, 50,100,250,500,1000,2500,10000)
repeticiones <- 10^4

cobertura <- sapply(n, estimar_cobertura, p = p, alfa = alfa, repeticiones = repeticiones)
d_cobertura <- data.frame(as.factor(n), cobertura)
names(d_cobertura)[1] <- c("n")
#Se grafican los resultados
ggplot(data = d_cobertura, aes(x = n, y = cobertura)) +
  geom_bar(stat = "identity",width = .35) +
  labs(title = "Estimación de cobertura") +
  labs(subtitle = paste("p =",p ,"alfa =",alfa )) +
  theme_bw() +
  theme(plot.title = element_text(hjust = 0.5))

#--------------------------

#Ejercicio 5
rm(list=ls())
#Bibliotecas usadas
library("ggplot2")
library("scales")


#5(a)
###Definición de funciones
#Calcula la cdf empirica de un conjunto de datos númericos
cdf_empirica <- function(x,datos){
  sum(datos <= x)/length(datos)
}

#Grafica la cdf empirica de un conjunto de datos,
#la funcion usa internamente a la funcion cdf_empirica
grafica_cdf_empirica <- function(datos){
  extra <- 2*diff(range(datos))/length(datos) #Ajustes de la grafica
  x <- c(min(datos)-extra,sort(datos))
  Fx <- sapply(x, function(k){cdf_empirica(k,datos)})
  cdf_datos <- data.frame(x,Fx)
  names(cdf_datos) <- c("x", "Fx")
  xend <- c(x[c(2:length(x))], max(datos)+extra) #Ajustes de la grafica
  yend <- cdf_datos$Fx
  p <- ggplot(data = cdf_datos, aes(x=x, y = Fx, xend = xend, yend= yend)) +
    geom_segment(size = .2)+
    geom_point() +
    geom_point(aes(x=xend, y=Fx), shape=1) +
    scale_x_continuous(breaks = pretty(min(datos):max(datos), n = 10))+
    scale_y_continuous(breaks = seq(0,1,.25))+
    labs(title = "Función de probabilidad acumulada") +
    theme_bw() +
    theme(plot.title = element_text(hjust = 0.5))
  p
}

#5(b) Q-Q plot normal
#Grafica un Q-Q plot normal de un conjunto de datos
#datos es una lista
qqplot_normal <- function(datos){
  x <- sort(datos)
  n <- length(x)
  p <- seq_along(x)/(length(x)+1)
  zp <- qnorm(p, mean = 0, sd = 1) #los cuantiles, podrian ser de otra distribucion
  datos_qq <- data.frame(zp,x)
  names(datos_qq) <- c("zp","x")
  q_datos <- c(x[.25*n], x[.75*n]) #cuartiles de los datos
  q_normal <- qnorm(c(p[.25*n], p[.75*n])) #cuartiles de la normal
  m <- diff(q_datos)/diff(q_normal) #parametros para la recta de ajuste
  b <- q_datos[1] - q_normal[1]*m
  qqplot <- ggplot() +
    geom_abline(intercept = b, slope = m, color = "red", size = .8, linetype="dashed") +
    geom_point(data = datos_qq, aes(x = zp, y = x),shape = 0) +
    geom_line() +
    labs(title = "Q-Q Plot Normal") +
    theme_bw() +
    theme(plot.title = element_text(hjust = 0.5)) +
    xlab("Cuantil teórico (zp)") +
    ylab("Observaciones")
  qqplot
}

#5(c) Q-Q plot normal con bandas
#Agrega bandas de confianza a la grafica producida por
#qqplot_normal
qqband_normal <- function(datos, confianza){
  alfa <- 1 - confianza
  datos_ord <-sort(datos)
  n <- length(datos)
  x <- sort(datos)
  p <- seq_along(x)/(length(x)+1)
  zp <- qnorm(p, mean = 0, sd = 1)
  ks_an <- sqrt((1/(2*n+n)) * log(2/alfa)) #Se uso e_n
  sel_upper <- which(p + ks_an < 1)
  datos_upper <- data.frame(x[sel_upper], qnorm(p[sel_upper] + ks_an))
  names(datos_upper) <- c("x", "upper")
  sel_lower <- which(p - ks_an > 0)
  datos_lower <- data.frame(x[sel_lower], qnorm(p[sel_lower] - ks_an))
  names(datos_lower) <- c("x", "lower")
  datos_qq <- data.frame(zp,x)
  names(datos_qq) <- c("zp", "x")
  qq_band <- qqplot_normal(datos) +
    geom_line(data = datos_lower, aes(x=lower, y=x), color = "red") +
    geom_line(data = datos_upper, aes(x=upper, y=x), color = "red") +
    labs(subtitle = paste("Banda con nivel de confianza =",confianza ))
  qq_band
}

#5(c) P-P plot normal
ppplot_normal <- function(datos){
  x <- sort(datos)
  n <- length(x)
  p <- seq_along(x)/(length(x)+1)
  pN <- pnorm(x, mean = mean(x), sd = sd(x)) #percentiles teoricos
  datos_pp <- data.frame(pN,p)
  names(datos_pp) <- c("pN","p")
  p_datos <- c(p[.25*n], p[.75*n]) #percentiles de los datos
  p_normal <- pnorm(c(x[.25*n], x[.75*n]), mean = mean(x), sd = sd(x)) #percentil de la normal
  m <- diff(p_datos)/diff(p_normal) #parametros para la recta de ajuste
  b <- p_datos[1] - p_normal[1]*m
  ppplot <- ggplot() +
    geom_abline(intercept = b, slope = m, color = "red", size = .8, linetype="dashed") +
    geom_point(data = datos_pp, aes(x = pN, y = p),shape = 0) +
    geom_line()+
    labs(title = "P-P Plot Normal") +
    theme_bw() +
    theme(plot.title = element_text(hjust = 0.5)) +
    xlab("Percentil teórico (pN)") +
    ylab("Observaciones")
  ppplot
}

###Uso de las funciones
#Se calcula la cdf empirica para el conjunto de diametros dados
#Las discontinuidades se dan en los xi de la muestra
diametros <- c(23.37,25.05,23.02,21.87,20.40,17.32,24.41,21.05,
               30.74,21.27,28.83,26.73,23.33,22.90,17.22,15.20,
               18.00,22.81,24.21,17.55,20.78,27.52,25.92,23.17,
               15.48,23.64,21.60,27.19,28.96,22.37)

datos <- diametros
#Esto solo es para imprimir la cdf en orden
datos_ord <- sort(datos)
d_empirica <- data.frame(datos_ord,sapply(datos_ord, function(k){cdf_empirica(k,datos_ord)}))
names(d_empirica) <- c("x", "Fx")
print("cdf empirica")
d_empirica

#Se grafica la cdf empirica
grafica_cdf_empirica(datos)
#Se grafica la Q-Q plot normal
qqplot_normal(datos)
#Se grafican las qqplot normal con niveles de confianza .95, .99
qqband_normal(datos, .95)
qqband_normal(datos, .99)
#Se grafica la P-P plot normal
ppplot_normal(datos)

#------------------
#Ejercicio 6
rm(list=ls())
#Bibliotecas usadas
library("ggplot2")

###Definición de las funciones
#6(a)
#Calcula la estimación de densidad por kernel (kde)
#x es el punto en el que se hace la estimación
#datos es el conjunto de datos (vector o lista)
#kernel es el tipo de kernel que se usará y h es el ancho de banda
kde <- function(x, datos, kernel, h){
  n <- length(datos)
  f_x_h  <- 1/n* sum(sapply(datos, function(xi){kernel((x-xi)/h)}))
}

#Grafica la 'kde' de datos, dado un kernel y un ancho de banda
grafica_kde <- function(datos, kernel, h){
  kde_datos <- data.frame(datos, sapply(datos, kde, datos = datos, kernel = kernel, h = h))
  names(kde_datos) <- c("x","kde_x")
  ggplot(data = kde_datos, aes(x = x, y = kde_x)) +
    geom_point(size = .5) +
    geom_line(linetype = "dashed", size = .2)  +
    labs(title = "Estimación de densidad por kernel") +
    labs(subtitle = paste("h =",h )) +
    theme_bw()+
    theme(plot.title = element_text(hjust = 0.5))
}

#6(b)
###Uso de las funciones
#Ocultar en MD
#setwd("/home/rolando/Dropbox/Semestre 19-1/Inferencia Estad�?stica/Tarea3/CodigoR")
#Se importa el archivo "Tratamiento.csv"
tratamiento <- read.table("Tratamiento.csv")
datos <- tratamiento[[1]]
#Se elige el kernel normal
kernel <- dnorm
#Se grafican los valores solicitados
grafica_kde(datos, kernel, 20)
grafica_kde(datos, kernel, 30)
grafica_kde(datos, kernel, 60)

#Se calcula h_ROT (óptima) y se grafica la estimación
h_ROT <- (1.06 *sd(datos))/ (length(datos) ^ (1/5))
h_ROT
grafica_kde(datos, kernel, h_ROT)

#----------------------
#Ejercicio 7
rm(list=ls())
#Bibliotecas usadas
library(ggplot2)
library(dplyr)
library(MASS)

###Definición de funciones

#Estima los coeficientes de una regresión lineal y = b0 + b1x
#Regresa un vector con los coeficientes b0, b1
regresion_mc <- function(x, y){
  m_x <- mean(x)
  m_y <- mean(y)
  b1 <- sum((x - m_x)*(y - m_y))/ sum((x-m_x)*(x-m_x))
  b0 <- m_y - b1*m_x
  c(b0, b1)
}

#Funcion auxiliar de las funciones graficadoras
#https://slowkow.com/notes/ggplot2-color-by-density/
get_density <- function(x, y, n = 100) {
  dens <- MASS::kde2d(x = x, y = y, n = n)
  ix <- findInterval(x, dens$x)
  iy <- findInterval(y, dens$y)
  ii <- cbind(ix, iy)
  return(dens$z[ii])
}

#Obtiene la grafica de regresión estimada por mínimos cuadrados
grafica_regresion_mc <- function(x, y){
  estimacion_reg <- regresion_mc(x,y)
  b0 <- estimacion_reg[1]
  b1 <- estimacion_reg[2]
  y_est <- sapply(x, function(k){b0 + b1*k})
  datos_reg <- as.data.frame(cbind(x,y,y_est))
  datos_reg$density <- get_density(datos_reg$x, datos_reg$y)
  p <- ggplot(data = datos_reg) +
    geom_point(aes(x = x, y = y, fill = density , colour = density))+
    geom_line(aes(x = x, y = y_est), colour = "firebrick1", size = 1.2, alpha = .7) +
    guides(colour=FALSE) +
    guides(fill=FALSE) +
    labs(title = "Regresión por mínimos cuadrados") +
    theme_bw() +
    theme(plot.title = element_text(hjust = 0.5))
  p
}

#Estima la regresión no paramétrica por kernel normal en el punto t
regresion_kernel_normal <- function(t,x,y,h){
  m_h_t <- sum(dnorm((t - x)/h)*y) / sum(dnorm((t - x)/h))
  m_h_t
}

#Grafica de la regresión por kernel y la compara con el conjunto de datos original
grafica_regresion_kernel_normal <- function(x,y){
  h_ROT <- (1.06 *sd(x)) / (length(x) ^ (1/5))
  y_est <-sapply(x, regresion_kernel_normal, x = x, y = y, h = h_ROT)
  datos_reg <- as.data.frame(cbind(x,y,y_est))
  datos_reg$density <- get_density(datos_reg$x, datos_reg$y)
  p <- ggplot(data = datos_reg) +
    geom_point(aes(x = x, y = y, fill = density , colour = density))+
    geom_line(aes(x = x, y = y_est), colour = "firebrick1", size = 1.2, alpha = .7) +
    guides(colour=FALSE) +
    guides(fill=FALSE) +
    labs(title = "Regresión por estimación de kernel normal") +
    labs(subtitle = paste("hROT =",h_ROT )) +
    theme_bw() +
    theme(plot.title = element_text(hjust = 0.5))
  p
}


###Uso de las funciones
# Se leen los datos
#setwd("/home/rolando/Dropbox/Semestre 19-1/Inferencia Estadística/Tarea3/CodigoR")
#Es necesario que el archivo "Maiz.csv" esté en el directorio de trabajo (working directory)
datos_maiz <- read.table("Maiz.csv", header = TRUE, sep = ",")

x <- datos_maiz$P..Tonelada.Ma�z
y <- datos_maiz$P..Tonelada.Tortilla

#Grafica la regresión por mínimos cuadrados
g_regresion_maiz <- grafica_regresion_mc(x,y)
g_regresion_maiz + xlab("Toneladas maíz") + ylab("Toneladas tortillas")

#Estimacion de coeficientes via regresión tipo kernel
h_ROT <- (1.06 *sd(x)) / (length(x) ^ (1/5))
y_est_ker <-sapply(x, regresion_kernel_normal, x = x, y = y, h = h_ROT)
datos_reg_ker <- as.data.frame(cbind(x,y,y_est_ker))
#View(datos_reg_ker)
#Grafica de regresion por kde
g_regresion_maiz_ker <- grafica_regresion_kernel_normal(x,y)
g_regresion_maiz_ker + xlab("Toneladas maíz") + ylab("Toneladas tortillas")

