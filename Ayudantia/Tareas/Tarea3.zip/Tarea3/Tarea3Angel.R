#Problema 1
#Inciso b
n<-100000
## SUELE FIJAR UNA SEMILLA CUANDO SIMULES, ES UNA BUENA PRACTICA
set.seed(123)
muestra<- rnorm(n,pi,sqrt(2))
ym<-cumsum(muestra)/(1:n)
plot(x=1:n,y=ym, type="l",xlab="Indice de muestra", ylab="Ym",main="Convergencia de la media experimental")

#Como la variable es normal, esta tiene media finita. Por tanto Ym converge a pi


#Inciso c
set.seed(0)
muestra<- rnorm(n,pi,sqrt(2))
ym<-cumsum(muestra)/(1:n)
plot(x=1:n,y=ym, type="l",xlab="Indice de muestra", ylab="Ym",main="Convergencia de la media experimental con 100 trayectorias")
# ponle tantito color
for(i in 2:100) {
  muestra<- rnorm(n,pi,sqrt(2))
  ym<-cumsum(muestra)/(1:n)
  color <- runif(3,0,1)
  lines(ym, col=rgb(color[1], color[2], color[3], 0.5))
}

#La convergencia de Ym se puede dar por diversas trayectorias de la media experimental
# Y ES SUMAMENTE SENSIBLE A EL VALOR INICIAL
#Inciso d) parte 1
set.seed(0)
n<-100000
muestra<- rcauchy(n,pi,sqrt(2))
ym<-cumsum(muestra)/(1:n)
plot(x=1:n,y=ym, type="l",xlab="Indice de muestra", ylab="Ym",main="Trayectoria de la media experimental")
#Inciso d) parte 2
muestra<- rcauchy(n,pi,sqrt(2))
ym<-cumsum(muestra)/(1:n)
set.seed(0)
plot(x=1:n,y=ym, type="l",xlab="Indice de muestra", ylab="Ym",main="100 Trayectorias de la media experimental",ylim=c(-100,100))
for(i in 2:100) {
  muestra<- rcauchy(n,pi,sqrt(2))
  ym<-cumsum(muestra)/(1:n)
  #lines(ym)
  color <- runif(3,0,1)
  lines(ym, col=rgb(color[1], color[2], color[3], 0.5))

}

#La ley de los grandes numeros no aplica, pues la esperanza de una variable cauchy no es finita.
#Luego se puede observar como las trayectorias son caoticas, MAS QUE CAOTICAS NO CONVERGEN O TAMBIEN PUEDES DECIR QUE NO SON ESTABLES

#Problema 2
#b)
simula<- function(n,p,alpha,veces) {
  #n,p,alpha como en la redaccion
  #veces es la cantidad de veces que se hara la simulacion para
  #obtener una aproximacion de la probabilidad de que p este en el
  #intervalo Cn
  epsilon<- sqrt( (1/(2*n)) * log(2/alpha) )
  cont<-0
  for(i in 1:veces) {
    muestra<- sample(0:1,n,prob=c(1-p,p),replace=TRUE)
    est.p<-mean(muestra)
    iniC<- est.p-epsilon
    finC<- est.p+epsilon
    if(iniC<=p && p<=finC)
      cont<-cont+1
  }
  return (cont/veces)
}

simula(10,0.4,0.05,1000)
simula(50,0.4,0.05,1000)
simula(100,0.4,0.05,1000)
simula(250,0.4,0.05,1000)
simula(500,0.4,0.05,1000)
simula(1000,0.4,0.05,1000)
simula(2500,0.4,0.05,1000)
simula(5000,0.4,0.05,1000)
simula(10000,0.4,0.05,1000)
#se observa que en todos la proporcion observada es mayor que 1-alpha=0.95
#Que es coincidente con a)

cobertura<- function(n) {
  simula(n,0.4,0.05,10000)
}

n<-c(10,50,100,250,500,1000,2500,5000,10000)
cob<-lapply(X=n,FUN=cobertura)
plot(x=n,y=cob,main="Cobertura experimental vs cantidad de elementos de la muestra",ylim=c(0.90,1.0))
#Se puede observar que la cobertura experimental parece no variar conforme n crece
#Esto es coincidente con lo que sabesmos, pues la cota es siempre 1-alpha
#c)
tam.Intervalo<- function(n) {
  #Dado que los intervalos son de la forma (p-eps,p+eps) , la longitud
  #de los intervalos es 2*eps
  alpha<-0.05
  return (2*sqrt( (1/(2*n)) * log(2/alpha)))
}
tam<- lapply(n,tam.Intervalo)
plot(x=n,y=tam,main="Longitud del intervalo Cn vs cantidad de elementos de la muestra")

#Problema 5
#a)
#Datos del problema
D<-c(23.37, 21.87, 24.41, 21.27, 23.33, 15.20, 24.21, 27.52, 15.48, 27.19,
     25.05, 20.40, 21.05, 28.83, 22.90, 18.00, 17.55, 25.92, 23.64, 28.96,
     23.02, 17.32, 30.74, 26.73, 17.22, 22.81, 20.78, 23.17, 21.60, 22.37)
F.Empirica<- function(x,D) {
  #x es el punto a evaluar
  #D son los datos
  #Se regresa la probabilidad empirica
  #de tener un dato <= x
  sum(D<=x)/length(D)
}
#Graficare sobre el conjunto de datos ordenado
Dord<- sort(D)
#p es el vector de probabilidad acumulada
p<-lapply(X=Dord,FUN=F.Empirica,D)
plot(x=Dord,y=p,type="s",xlab="Diametero del Agave",ylab="Probabilidad acumulada empirica",main="Funcion de distribucion empirica")
#Se tiene un punto de discontinuidad por cada elemento del conjunto de datos
#ya que en ellos es cuando se incrementa "de golpe" el valor de F.empirica

#b)

QQPlot.Normal<- function(D){
  #D es un vector con los datos (observaciones)
  #La funcion graficara el QQplot normal
  #
  Dord<-sort(D)
  n<-length(D)
  #p guarda las probabilidades de las que queremos saber el cuantil
  p<-(1:n)/(n+1)
  q<-qnorm(p,mean=0,sd=1)
  plot(x=q,y=Dord,xlab="Cuantil teorico (zp)",ylab="Observaciones"
      ,main="Normal Q-Q Plot",type="b")
}

QQPlot.Normal(D)
#Los datos parecen acomodarse sobre una linea, entonces podemos comenzar a sospechar normalidad
TE Das cuenta que las lineas 129-132 IMPLICITAMENTE ESTANDARIZAN TUS DATOS ? CON MEDIA CERO Y VARIANZA UNO


#c)



QQPlot.NormalExtendido<- function(D,conf,K){
  # D es un vector con los datos (observaciones)
  # La funcion graficara el QQplot normal
  #  y la banda de confianza 1-p
  # K es la constante obtenida de la tabla de
  # http://www.real-statistics.com/statistics-tables/kolmogorov-smirnov-table/
  # ya que no encontre forma eficiente momentaneamente
  # de relacionar K con p COMO ES UN RESULTADO ASINTOTICO QUE CREO QUE LA PRUEBA USA SERIES DE FOURIER SERIA DIFICIL
    # LO BUENO ES QUE YA ESTA IMPLEMENTADO CHECA LA DOC DE LA FUNCION 'ks.test' y piensa como podrias usarla para mejorar tu implementacion pero te doy el punto
  Dord<-sort(D)
  n<-length(D)
  #p guarda las probabilidades de las que queremos saber el cuantil
  p<-(1:n)/(n+1)
  q<-qnorm(p,mean=0,sd=1)
  mensaje<- paste("Normal Q-Q Plot\nCon
                  una banda de un nivel de confianza de 1-alpha = ",conf)
  plot(x=q,y=Dord,xlab="Cuantil teorico (zp)",ylab="Observaciones"
       ,main=mensaje,type="b")
  alpha<-mean(D)
  beta<-sd(D)
  xord<- sort(q)
  ly<-alpha+beta*xord
  lines(xord,ly,col="red")
  pab<-p-K
  for(i in 1:n) if(pab[i]<0) pab[i]<-0.0001
  parr<-p+K
  for(i in 1:n) if(parr[i]>1) parr[i]<-0.9999
  abajo<-qnorm(pab,mean=0,sd=1)
  arriba<-qnorm(parr,mean=0,sd=1)
  lines(abajo,Dord,col="blue")
  lines(arriba,Dord,col="blue")

}


QQPlot.NormalExtendido(D,0.95,0.2417)
QQPlot.NormalExtendido(D,0.99,0.28988)

# Los datos caen dentro de la banda de confianza en ambos casos
# Ademas como era de esperarse, la banda con un nivel de 0.99 es mas ancha que la de 0.95
#d)

Grafico.Normal<- function(D){
  #D es un vector con los datos (observaciones)
  #La funcion graficara el QQplot normal
  #
  Dord<-sort(D)
  n<-length(D)
  #p guarda las probabilidades de las que queremos saber el cuantil
  p<-(1:n)/(n+1)
  u<-mean(D)
  sigma<-sd(D)
  q<-qnorm(p,mean=u ,sd=sigma)
  plot(x=q,y=Dord,xlab="Cuantil teorico",ylab="Observaciones"
       ,main="Grafico de Probabilidad Normal",type="b")
}

Grafico.Normal(D)

#e)
# Como se observa en el grafico de probabilidad normal, y en el qqplot
# los puntos aparentan caer sobre una linea, por lo que sospecho que los datos
# si provienen de una distribucion normal

#Problema 6
# a)


f.kernel<- function(x,h,K,D) {
  #x es el punto a evaluar
  #h es la suavidad
  #K es el kernel
  #D son las observaciones
  #Puntos guarda los valores en los que se evaluara el kernel
  n<- length(D)
  puntos<- (x-D)/h
  sum(sapply(puntos,K))/(n*h)
}
#b)
grafica.kernel<- function(h,K,D) {
  n<- length(D)
  Dor<- sort(D)
  f<-sapply(Dor,f.kernel,h,K,D)
  mensaje<-paste("Funcion estimada con el kernel y una h= ",h)
  plot(x=Dor,y=f,xlab="Observacion",ylab="Densidad estimada",main=mensaje,type="l")
}

#Linea para cargar los datos
datos<-read.csv(file.choose())
obs<-datos[[1]]
# casteo los datos a un vector obs

#Usare un kernel gaussiano
grafica.kernel(20,dnorm,obs)
grafica.kernel(30,dnorm,obs)
grafica.kernel(60,dnorm,obs)
# Considero que el mejor valor es h=60 pues es mas facil hacer inferencias sobre distribuciones que
# se ajusten a los datos, y tiene menos picos. Sin embargo creo que h=30 refleja tambien
# informacion sobre los datos, como esa ligero pico que se forma despues del 200

# Problema 7

# a)
datos<-read.csv(file.choose())
maiz<-datos[[1]]
tortilla<-datos[[2]]

regresionLineal.MinimosCuadrados<- function(x,y) {
  # Dados x,y
  # calcula estimadores por minimos cuadrados
  # de alpha y beta tales que
  #y=bhetax+alpha
  beta<- sum((x-mean(x))*(y-mean(y)))/sum((x-mean(x))^2)
  alpha<-mean(y)-beta*mean(x)
  #Grafica de la regresion
  xord<- sort(x)
  ly<-alpha+beta*xord
  mensaje<- paste("Regresion lineal simple por minimos cuadrados\n alpha = ",alpha," , beta = ",beta,"\n La regresion queda y = ",alpha," + ",beta,"x")
  plot(x=x,y=y,xlab="Precio Tonelada de Maiz",ylab="Precio Tonelada de Tortilla",main=mensaje)
  lines(xord,ly,col="red")
}

regresionLineal.MinimosCuadrados(maiz,tortilla)
# Se aprecia de la grafica que si el valor de x aumenta, el valor de y tambien lo hace, siguiendo
# aparentemente una cierta proporcion. Sin embargo la franja por la que crecen los numeros
# es ancha.
#Aceptando la regresion lineal, podemos concluir que el precio de la tonelada de tortilla es 685 pesos
# mas aproximadamente la mitad del precio de la tonelada de maiz

# b)

estimador.kernel<- function(x,h,K,X,Y) {
  # x es el punto a evaluar
  # h es el tamanio de la banda
  # K es la funcion kernel
  # X,Y son los datos
  sum((sapply((x-X)/h,K))*Y)/sum((sapply((x-X)/h,K)))
}
regresion.Kernel<- function(datX,datY,K,h) {
  # datX datY son los datos sobre los que queremos hacer regresion
  # K es el kernel a usar
  # h es el ancho de la banda
  #Aproximando mediante un kernel gaussiano
  datXord<- sort(datX)
  ky<- sapply(datXord,estimador.kernel,h,K,datX,datY)
  mensaje<- paste("Regresion con kernel mediante un h = ",h)
  #se grafican los datos asi como la regresion obtenida
  plot(x=datX,y=datY,xlab="Precio Tonelada de Maiz",ylab="Precio Tonelada de Tortilla",main=mensaje)
  lines(datXord,ky,col="red")

}
#Prueba de la regresion con distintos valores de h, usando un kernel gaussiano
regresion.Kernel(maiz,tortilla,dnorm,0.5)
regresion.Kernel(maiz,tortilla,dnorm,1)
regresion.Kernel(maiz,tortilla,dnorm,2)
regresion.Kernel(maiz,tortilla,dnorm,5)
regresion.Kernel(maiz,tortilla,dnorm,10)
regresion.Kernel(maiz,tortilla,dnorm,20)

#c)
# Observo que con valores pequenios de h, la regresion es muy puntiaguda
# en los extremos casi se pasa por todos los puntos
# para h=5 la regresion es parecida a la obtenida en a)
# si h es 10 o mas la regresion tiende a hacerse con la media de los datos en Y

