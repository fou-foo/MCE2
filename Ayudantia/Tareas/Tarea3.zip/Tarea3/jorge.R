#Tarea 3 Inferencia Estad??stica
#Alumno Jorge Sanchez Garcia

#Ejercicio 1:

#b) Simule una muestra {x1, . . . xn} de una v.a. Normal(??, ???2) de tamano n = 10**5.
#Defina ym = sumatoria desde i=1 hasta m de xi/m y grafique esta cantidad.

ym<-function(m=pi,d=2**0.25, n=10**5){ #Funcion con paramteros media, desviacion estandar y tama??o de la muestra
  x<-rnorm(n,mean = m,sd = d) #Muestra normal con media pi y varianza 2^0.5
  y<-cumsum(x)/seq_along(x)
  return(y)
  }

FIJA UNA SEMILLA
set.seed(0)
plot(ym(),type = "l", main = "Histograma de Frecuencias", xlab = "Espacio Muestral",
     ylab = "Frecuencia", col = colors()[sample(1:500, 1)], ylim=c(2.9,3.3))
abline(pi,0, col="red")
#??Que observa? ??Como esta esto relacionado con la LGN?
#Que la funcion ym converge a la media poblacional media

#c) Repita el procedimiento anterior 100 veces y grafique las ym de cada iteracion
#sobre una misma grafica. ??Que observa? #R: observamos la covergenciua hacia la media

simulacion<-replicate(n = 100,ym(pi,2**0.25,10**5))
simulacion

hist(simulacion, main = "Convergencia Normal", xlab = "Espacio Muestral", ylab = "Frecuencia", col = "blue")

#d)Repita los dos incisos anteriores para una distribucion Cauchy(??,???2). ??Que observa?

Ym<-function(m=pi,d=2**0.25, n=10**5){ #Funcion con paramteros media, desviacion estandar y tama??o de la muestra
  x<-rcauchy(n = n,location = m,scale = d) #Muestra normal con media pi y varianza 2^0.5
  y<-cumsum(x)/seq_along(x)
  return(y)
}

plot(Ym(),type = "l", main = "Histograma de Frecuencias", xlab = "Espacio Muestral", ylab = "Frecuencia", col = "blue")
abline(pi,0, col="red")

#??Que observa? ??Como esta esto relacionado con la LGN?
#R: Que observa que no tiene una convergencia a la media, debido a que carece de momentos, es decir tiene varianza infinita
DE HECHO SOLO TE ESTAS FIJANDO EN LA MEDIA NO EN LA VARIANZA
#y por lo tanto no podemos aplicar la LFGN
LA LFGN SE CUMPLE AUN RELAJANDO LA EXISTENCIA DEL SEGUNDO MOMENTO

#Repita el procedimiento anterior 100 veces y grafique las ym de cada iteracion
#sobre una misma grafica. ??Que observa? #R: Que efectivamente no hay convergencia hacia la media poblacional.

sim<-replicate(n = 100,Ym(pi,2**0.25,10**5))
hist(sim, main = "Histograma de Frecuencias", xlab = "Espacio Muestral", ylab = "Frecuencia", col = "blue")

#Ejercicio 3:
# b) Sea ?? = 0.05 y p = 0.4. Mediante simulaciones, realice un estudio para ver que tan a menudo
#el intervalo de confianza contiene a p (la cobertura).

a <- 0.05 # alpha
p <- 0.4 # Probabilidad p
set.seed(123) #semilla
n <- c(10, 50, 100, 250, 500, 1000, 2500, 5000, 10000) #Tamanos de muestra

numExitos <- function(n){   #Funcion que calcula las veces que p se encuentra dentro del intervalo.
  exitos <- 0
  e<- sqrt((1/(2*n))*(log(2/a)))
  mediaest <- mean(rbinom(n, 1, p))
  if(abs(mediaest-p) < e  ){ exitos <- exitos + 1}
  return(exitos)
}

Simulacion <- matrix(0, 9, 2) #Matriz que guarda los exitos y los fracasos para cada tamano de muestra.
N<-10**3 #Numero de simulaciones
for(i in 1:9){Simulacion[i, ]<-table(replicate(N, numExitos(n[i])))}

colnames(Simulacion) <-  c("Fuera Intervalo", "Dentro Intervalo")
rownames(Simulacion) <-  c("n = 10", "n = 50", "n = 10" ,"n = 250", "n = 500", "n = 1000", "n = 2500", "n = 5000","n = 10000")
Simulacion #Resultados de la simulacion

#Cobertura

Cn <- matrix(0, 9,2) #Intervalo de confianza definido en el ejercicio.
e<-0
mediaest<-0

for(i in 1:9){
  e[i] <- sqrt((1/(2*n[i]))*(log(2/a))) #epsilon
  set.seed(123) #semilla
  mediaest[i] <- mean(rbinom(n[i], 1, p))
  Cn[i, ] <- c(mediaest[i] - e[i], mediaest[i] + e[i]);
  #Restringe valores para acotarla entre 0 y 1
  if(Cn[i, 1] < 0){Cn[i, 1] <- 0}
  if(Cn[i, 2] > 1){Cn[i, 2] <- 1}
}

ICS <-Cn[, 1] # intervalo superior
ICI <-Cn[,2] # intervalo inferior

#c) Grafique la longitud del intervalo contra n. Suponga que deseamos que la longitud del intervalo
#sea menor que 0.05. ??Que tan grande debe ser n?
#R: en nuestar simulacion, n= 2952

plot(n, rep(.4, 9), type="l", ylim=c(0.2,.6),xlab = "Tamano de la muestra", main = "Intervalo de confianza", ylab="p = 0.4")

lines(n, ICI,  type="l", col="red")
lines(n, ICS,  type="l", col="red")

#Calculando el valor de n para que la longitud del intervalo sea menor a 0.05

i=1
while( (2* sqrt((1/(2*i))*(log(2/a))))>=0.05){
  i<-i+1
}
i # Valor de n
MUY BIEN, TODOS LOS DEMAS LLEGARON A ESTE RESULTADO ANALITICAMENTE
#Ejercicio 5:
#a)Escriba una funcion en R que calcule la funcion de distribuci??on emp????rica para un conjunto de datos
#La funcion debe tomar como parametros al punto x donde se evalua y al conjunto de datos D.

datos<-vector()
datos<-c(23.37, 21.87, 24.41, 21.27, 23.33, 15.20, 24.21, 27.52, 15.48, 27.19, 25.05, 20.40, 21.05, 28.83, 22.90, 18.00, 17.55, 25.92, 23.64, 28.96, 23.02,17.32, 30.74, 26.73, 17.22, 22.81, 20.78, 23.17, 21.60,22.37)

FEmpirica<-function(x,datos){
  prob<-(sum(datos<x))/(length(datos))
  return(prob)
}
#Definiendo rango entre las variables de la funcion de distribucion empirica
y<-sort(datos)
a<-vector()
for(i in 1:length(datos)-1){
  a[i]<-abs(y[i]-y[i+1])
}
m<-min(a)  #Menor rango entre las variables

#Generando el espacio muestral
w<-seq(from = min(datos),to = max(datos)+m,by = m)
v<-vector()
for(i in 1:length(w)){
  v[i]<-FEmpirica(w[i],datos)    #Vector que guarda la probabilidad empirica para el esapacio muestral
}

#Grafica de la Distribucion de Probabilidad Empirica
plot(w,v,type = "b",main = "Funcion de Distribucion Empirica",xlab  = "Espacio Muestral",ylab  = "Probabilidad", col="blue")

#Ponga atencion a los puntos de discontinuidad. ??Que observa?
#R: que las discontinuidades estan en las x??s correspondientes al conjunto de datos. Para comprobarlo, se puede analizar
#la grafica de la DIstribucion acumulada del conjunto de datos, la cual muestro a continuacion.
d<-vector()
for(i in 1:length(y)){
  d[i]<-FEmpirica(y[i],datos)  #Vector que guarda la probabilidad empirica para los datos
}
plot(stepfun(y,c(d,1), right=F), verticals = F,main = "Funcion de Distribucion Empirica",xlab  = "Espacio Muestral",ylab  = "Probabilidad", col="black")
lines(w,v,type = "b", col="gray")    #Juntando las graficas para compararlas

#5 b) Escriba una funcion en R que determine la grafica Q-Q normal de un conjunto de datos.
#La funcion debe tomar como parametro al conjunto de datos. Usando esta funcion, determine la grafica Q-Q normal.
#??Que observa? R: La curva se encuentra muy suavizada

Cuantiles<-function(datos){ #Funciona que genera los cuatiles
cuanorm<-vector()  #Vector que guarda los cuantiles normales correspondientes a la "probabilidad empirica" de los datos
estand<-vector()  #Vector que guarda los datos ordenados estandarizados
y<-sort(datos)
for(i in 1:length(y)){ #Genera los cuantiles normales
  cuanorm[i]<-qnorm(FEmpirica(y[i],datos))
}
return(results<-list(cuanorm=cuanorm))  #Genera como resultado una lista con el vector de los cuantiles normales
}

#Genera los Q-Q plots accediendo al vector de la lista
plot(Cuantiles(datos)[[1]],y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)
Cuantiles(datos)[[1]]
#c) An??ada a la funci??on anterior la opci??on de que grafique la banda de confianza, de cobertura 1 ?????,
#basada en el estad??stico de Kolmogorov-Smirnov. La funcion debe tomar como parametros al conjunto de datos
#y el nivel de confianza 1 ??? ??. Aplique esta funcion al conjunto de datos para un nivel de confianza 1 ??? ?? = 0.95, 0.99.
#??Que observa?

#Para calcular las Bandas de confianza se tomo en cuenta el estadistico de Kolmogorov con n=30
upper<-vector()
lower<-vector()
BandaC<-function(datos,alpha){
  if (alpha == 0.05) {
    D <- 0.24170 }  #Estadistico de Kolmogorov
  if (alpha == 0.01){
    D <- 0.28987 }  #Estadistico de kolmogorov

  #Calculando los intervalos de confianza
  for(i in 1:length(y)){ lower[i]<-qnorm(FEmpirica(y[i],datos)+D)}
  for(i in 1:length(y)){ upper[i]<-qnorm(FEmpirica(y[i],datos)-D)}

  return(resultados<-list(lower=lower,upper=upper))
}
#Graficando la banda de Confianza
#alpha=0.05
plot(Cuantiles(datos)[[1]],y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)
lines(BandaC(datos,0.05)[[1]],y, col="red")
lines(BandaC(datos,0.05)[[2]],y, col="red")

#alpha=0.01
plot(Cuantiles(datos)[[1]],y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)
lines(BandaC(datos,0.01)[[1]],y, col="red")
lines(BandaC(datos,0.01)[[2]],y, col="red")


#d)Escriba una funcion en R que determine el grafico de probabilidad normal.
#La funcion debe tomar como parametro al conjunto de datos. ??Que observa?

ProN<-vector()
ProEm<-vector()
y<-sort(datos)
PP<-function(datos){   #Funcion para obtener el P-P plot

  #Calculando los intervalos de confianza
  for(i in 1:length(y)){ ProEm[i]<-FEmpirica(y[i],datos)}
  for(i in 1:length(y)){ ProN[i]<-pnorm(y[i], mean = mean(datos), sd = sd(datos))}

  return(resultados<-list(ProN=ProN,ProEm=ProEm))
}

PP(datos)[[1]]
#Graficando la distribucion
plot(PP(datos)[[1]],PP(datos)[[2]], type ="p", xlab = "Probabilidad Normal",ylab = "Probabilidad Empirica", main = "Normal P-P Plot", col= "blue",pch=20)

#Ejercicio 6
#a) Escriba una funci??on en R que calcule el estimador de la densidad por el metodo de kerneles.
#La funcion debera recibir al punto x donde se evalua al estimador, al parametro de suavidad h,
#al kernel que se utilizara en la estimacion y al conjunto de datos.

KernelNorm<-function(x,X,H){ #Funcion Kernel normal
  H<- (1/(sqrt(2*pi)*H))*exp(-(x-X)^2/(2*H^2))
  kernel<-(1/85)*c(sum(H))
  return(kernel)
  }

#b) Cargue en R al archivo ???Tratamiento.csv???, el cual contiene la duracion de los per??odos de tratamiento
#(en d??as) de los pacientes de control en un estudio de suicidio.
#Utilice la funci ??on del inciso anterior para estimar la densidad del conjunto de datos para
#h = 20, 30, 60. Grafique las densidades estimadas. ??Cual es el mejor valor para h? Argumente.
#R: Obervando las graficas del ejercicio, se ve una mejor precision cuando h=20

Datos <- read.csv(file.choose(), header=TRUE)  #Carga el archivo Tratamientos.csv por el usuario

#Estimacion de densidad con h=20
U<-c(KernelNorm(0,Datos,20),KernelNorm(10,Datos,20),KernelNorm(20,Datos,20),
     KernelNorm(30,Datos,20 ), KernelNorm(40,Datos,20), KernelNorm(50,Datos,20 ),
     KernelNorm(60,Datos,20 ), KernelNorm(70,Datos,20 ),KernelNorm(90,Datos,20 ),
     KernelNorm(100,Datos,20),KernelNorm(110,Datos,20 ))

#Estimacion de densidad con h=30
L<-c(KernelNorm(10,Datos,30),KernelNorm(20,Datos,30), KernelNorm(30,Datos,30 ),
     KernelNorm(40,Datos,30), KernelNorm(50,Datos,30 ), KernelNorm(60,Datos,30 ),
     KernelNorm(70,Datos,30 ), KernelNorm(80,Datos,30 ), KernelNorm(90,Datos,30 ))

#Estimacion de densidad con h=60
R<-c(KernelNorm(-10,Datos,60), KernelNorm(0,Datos,60), KernelNorm(20,Datos,60),
     KernelNorm(40,Datos,60), KernelNorm(60,Datos,60 ), KernelNorm(80,Datos,60),
     KernelNorm(100,Datos,60 ), KernelNorm(120,datos,60 ), KernelNorm(140,Datos,60 ))

#Grafica de densidad con h=20
plot(c(0,10,20,30,40,50,60,70,90,100,110),U, type="b", main="Estimacion densidad h=20", xlab = "x", ylab = "Densidad")
#Grafica de densidad con h=30
plot(c(10,20,30,40,50,60,70,80,90), L, type="b",main="Estimacion Densidad h=30", xlab = "x", ylab = "Densidad")
#Gr?fica de densidad con h=80
plot(c(-10,0,20,40,60,80,100,120,140 ), R, type="b",main="Estimacion Densidad h=60", xlab = "x", ylab = "Densidad")
SE VEN EXTRA�AS ESTAS GRAFICAS, DEBERIAS DE REVIZARLAS

#7. Cargue en R al conjunto de datos ???Ma??z.csv???, el cual contiene el precio mensual de la tonelada de
#ma??z y el precio de la tonelada de tortillas en USD. En este ejercicio tendra que estimar los coeficientes
#de una regresion lineal simple.

#a) Calcule de forma expl??cita la estimacion de los coeficientes via m??nimos cuadrados y ajuste
#la regresion correspondiente. Concluya.

datos <- read.csv(file.choose(), header=TRUE)  #Carga el archivo

head(datos)

plot(datos$P..Tonelada.Ma�z , datos$P..Tonelada.Tortilla ,ylab = "Precio Tonelada de Tortillas (Dolares)", xlab = "Precio Tonelada de Maiz (Dolares)",  main="Regresion por MCO", pch=20)
lm(datos$P..Tonelada.Tortilla ~datos$P..Tonelada.Ma�z )
lm
TENIAS QUE ESTIMAR LOS COEFICIENTES SIN LA FUNCION 'lm'
#Estimacion por Minimos Cuadrados

# Media
names(datos) <- c('P..Tonelada.Maiz', 'P..Tonelada.Tortilla' )
mediaToneladas<-sum(datos$P..Tonelada.Tortilla)/length(datos$P..Tonelada.Tortilla)
mediaMaiz <-sum(datos$P..Tonelada.Maiz)/length(datos$P..Tonelada.Maiz)

# Varianza
varianzaMaiz <-sum((datos$P..Tonelada.Maiz - mediaMaiz)^2)/(length(datos$P..Tonelada.Maiz)-1)

# Covarianza
cov <- sum(((datos$P..Tonelada.Maiz - varianzaMaiz))*((datos$P..Tonelada.Tortilla - mediaToneladas)))/(length(datos$P..Tonelada.Maiz)-1)

#Regresion
beta <- cov/varianzaMaiz # beta estimada (pendiente de la regresion)
alfa <- mediaToneladas-beta*mediaMaiz # (constante de la regresion)

alfa #beta 0
beta#beta 1

plot(datos$P..Tonelada.Maiz, datos$P..Tonelada.Tortilla,ylab = "Precio Tonelada de Tortillas",xlab = "Precio Tonelada de Maiz", main="Regresion por MCO", pch=20)
lines(100:200, alfa+beta*(100:200), type = "l",col="steelblue", pch=3, lwd = 2)

#b) Calcule de forma expl??cita la estimacion de los coeficientes via regresion no-parametrica tipo kernel
#Concluya.

Kernel<- function(x, y, h) {
  xk <- seq(from = min(x) - 1, to = max(x) + 1, by = .1)
  n <- length(x) # numero de observaciones

  normal <- sapply(x, function(x) (((1/sqrt(2*pi))*exp((-((xk-x)^2)/(2*h^2))))/(n*h))) #Kernel gaussiano

  G<-matrix(0L, 462, 200) #Guarda los resultados de kernel
  for (i in 1:200){
    G[ ,i] <- ((((1/sqrt(2*pi))*exp((-((xk-x[i])^2)/(2*h^2))))*y[i])/(n*h))
  } # end for
  KernelXY <-rowSums(G)
  kernelX <-rowSums(normal)

  X <- KernelXY/kernelX

  plot( x,y, main=paste("Regresion por kernel h =", h),
        xlab="Precio Tonelada de Maiz", ylab="Precio Tonelada de Tortillas", pch=20)
  lines(xk, X, type = "l",col="steelblue", pch=3, lwd = 2)

}


x<- datos$P..Tonelada.Maiz
y <- datos$P..Tonelada.Tortilla
Kernel(x,y,1)
Kernel(x,y,1.37)
Kernel(x,y,2)
Kernel(x,y,3)
Kernel(x,y,4)
Kernel(x,y,.7)

#Kernel regresion
Kernel(x,y,4)
#MC
plot(datos$P..Tonelada.Maiz, datos$P..Tonelada.Tortilla,ylab = "Precio Tonelada de Tortillas",xlab = "Precio Tonelada de Maiz ", main="Regresion por MC",pch=20)
lines(100:200, alfa+beta*(100:200), type = "l",col="steelblue", pch=3, lwd = 2)

#c) Compare ambos resultados. ??Que diferencias observa?
#El metodo de regresion por Kernel tiene un mejor ajuste.
#Para h=4, las regresiones de kernel y minimos cuadrados ajustan de forma similar



