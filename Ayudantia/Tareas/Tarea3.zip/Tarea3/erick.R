############################################### EJERCICIO 1 #################################################

# OBS: ESTE EJERCICIO CORRERLO INCISO POR INCISO, SI NO SE PUEDE TRABAR .

# Primero con la Normal(mu = pi, sd= sqrt(2)):

########### INCISO B #########

# Obtener muestra
data <- rnorm(10e5, pi, sqrt(2))
# Calucular 'running mean'
mean_accu <- cumsum(data) / (1:10e5)
# Graficar
plot(1:10e5,mean_accu, type="l", xlab="Numero de datos", ylab="Promedio", main="Media aculumulada")

########### OBSERVAMOS QUE ###########
# Estamos observando la ley de los grandes numeros en accion: A medida que el tama�o de la muestra tiende a infinito
# la media muestral es cada vez un mejor estimador de la media poblacional.

############# INCISO C ##########

# Ahora lo hacemos 100 veces sobre una misma grafica:
# (Para muestras de tama�o 10e5 es tardado, para cuestiones de probar que funciona mejor bajarle cambiando el valor N)
N = 10e4
data <- rnorm(N, pi, sqrt(2))
mean_accu <- cumsum(data) / (1:N)
plot(1:N,mean_accu, type="l", xlab="Numero de datos", ylab="Promedio", ylim =c(3,3.5), main = "Media acumulada para 100 corridas - Gaussiana")
for(i in 1:99) {
  data <- rnorm(N, 3.1415927, sqrt(2))
  mean_accu <- cumsum(data) / (1:N)
  lines(1:N, mean_accu, type='l', col=rainbow(99)[i])
}

########### OBSERVAMOS QUE ###########

# Observamos algo similiar que en el ejercicio D,  pero nos damos cuenta de que con varias corridas es mas intuitivo ver
# que aunque podamos acercarnos tanto como queramos al valor real de la media el resultado variar� no solo dependiendo
# del tama�o de la muestra sino que tambi�n de los datos mismos. (Eso es trivial, pero por eso ahora se ve una 'barra'
# , por que aunque la media muestral tienda a la poblacional en la pr�ctica nunca es exactamente igual a ella)


############# INCISO D ##############

# Ahora con la Distribucion de Cauchy (parametro de localizacion = 0, parametro de escala = sqrt(2))
# ACOSTUMBRATE A FIJAR UNA SEMILLA
set.seed(0)
# Obtener muestra
data <- rcauchy(10e5, pi, sqrt(2))
# Calucular 'running mean'
mean_accu <- cumsum(data) / (1:10e5)
# Graficar
plot(1:10e5,mean_accu, type="l", xlab="Numero de datos", ylab="Promedio", main="Media acumulada - Cauchy")

# Ahora lo hacemos 100 veces sobre una misma grafica:
# (Para muestras de tama�o 10e5 es tardado, para cuestiones de probar que funciona mejor bajarle cambiando el valor N)
N = 10e3
data <- rcauchy(N, pi, sqrt(2))
mean_accu <- cumsum(data) / (1:N)
plot(1:N,mean_accu, type="l", xlab="Numero de datos", ylab="Promedio", main = "Media acumulada para 100 corridas - Cauchy", ylim=c(-50,50))
for(i in 1:N) {
  data <- rcauchy(N, 3.1415927, sqrt(2))
  mean_accu <- cumsum(data) / (1:N)
  lines(1:N, mean_accu, type='l', col=rainbow(99)[i])
}
########### OBSERVAMOS QUE ###########

# Observamos que aqui aunque N sea muy grande el valor de la media muestral no converge a la media real. De hecho al
# graficar las 100 corridas simultaneas vemos que en realidad no parece converger a nada. La ley de los grandes numeros
# no aplica con la distribucion de Cauchy por que no tiene momentos finitos. En la simulaci�n esto se traduce a que los
# valores extremos (colas) no son tan raros, y cuando la muestra contenga un valor de esos la media se ver�
# dr�sticamente afectada,  y el promedio no converger� a nada.

###############################################  EJERCICIO 3 ################################################

is_inside_Cn <- function (epsilon_n, p_n, p) {
  # Funcion que checa si el valor del estimador p_n pertenece al intervalo de confianza (1- alpha) para p, de
  # acuerdo a la desigualdad de Hoeffding.
  # Entradas:
  #   * alpha: float correspondiente al nivel de confianza (1- alpha)
  #   * n: Int, Tama�o de muestra
  #   * p: Float , Proporcion real de la poblacion (En principio deconocida)
  #   * p_n: Float, Estimador muestral de la proporcion
  # Salidas:
  #   * Booleano, True si p pertenece al intervalo de confianza, False en otro caso.

  top <- if((p_n + epsilon_n) < 1) (p_n + epsilon_n) else 1
  bottom <- if((p_n - epsilon_n) > 0) (p_n - epsilon_n) else 0

  return (bottom <= p && p <= top)
}


################## INCISO B ####################

  # Tama�os de muestra que se nos piden
  sample_sizes = c(10, 50, 100, 250, 500, 1000, 2500, 5000, 10000)

  for(n in sample_sizes) {
    alpha = 0.05
    p = 0.4
    # Valor del epsilon propuesto en el inciso a.
    epsilon_n <- sqrt((1/(2*n))*log(2/alpha))

    # Obtener 1000 estimadores de la propocion real (calculamos la proporcion de exitos en 1000 muestra de tama�o indicado)
    p_n = replicate(1000, sum( sample(c(0,1), n, prob=c(0.6,0.4), replace = TRUE)) / n)
    # Para cada uno de estos estimadores calculamos su intervalo de confianza y vemos si p est� dentro.
    is_inside = sapply(p_n, is_inside_Cn, epsilon_n=epsilon_n, p=0.4)
    print(paste("Numero de veces que el valor real de la poblacion cay� en el intervalo con n =", n,":"))
    # Contamos numero de exitos (veces que p cae en el intervalo)
    num_succeses = sum(is_inside == 1)
    print(num_succeses)
    # Graficamos la cobertura en funcion de los valores usados de n
    if (n == sample_sizes[1]){
      # Iniciar plot
      plot(n,num_succeses, xlim = c(0,10005), ylim = c(980,1000),xlab = "Tama�o de muestra (n)", ylab="Cobertura", main="Cobertura al repetir 1000 veces")
    } else {
      points(n, num_succeses)
    }
  }

rm(list=ls())
gc()
set.seed(0)
############# INCISO C #############

# Crear una secuencia regularmente espaciada de tama�os de poblacion y calcular la longitud del intervalo para cada una
for(n in seq(10,10000,100)) {
  alpha = 0.05
  # Calcular Epsilon_n
  epsilon_n <- sqrt((1/(2*n))*log(2/alpha))
  # La longitud del itervalo es 2* epsilon
  length = 2*epsilon_n

  # Graficar
  if( n == 10) {
    plot(n,length, xlim = c(0,10000), ylim = c(0,length), ylab="Longitud del Intervalo", xlab="n", main="Longitud de Cn como funci�n de n")
  } else {
    points(n,length)
  }
}

# LA PREGUNTA DE QUE TAN GRANDE DEBE SER N ESTA RESUELTA EN LAS HOJAS ESCRITAS.


###############################################  EJERCICIO 5 ################################################


empirical <- function(data, x) {
  # Funcion para calcular la funcion de distribucion emp�rica del dato x.
  # Entradas:
  #   * data: vector de datos, floats.
  # Salidas:
  #   * Float, valor de la funcion de distribucion empirica en el punto x.

  data = sort(data)
  return(length(which(data <= x)) / length(data))
}

get_normal_qq <- function(data) {
  # Funcion para graficar la qq-plot normal de los datos.
  # Entradas:
  #   * data: vector de datos, floats.
  # Salidas:
  #   * ninguna (Produce la grafica)



  # Ordenar (cuantiles muestrales):
  data = sort(data)
  n = length(data)

  # Aculumulada empirica ( con la convencion mostrada en el pdf que se encuentra en la clase 6)
  p <- 1:n / (n + 1)

  # Obtener cuantiles teoricos de la normal:
  quant_teo = qnorm(p)

  # Graficar:
  plot(quant_teo, data, xlab = "Cuantiles teoricos", ylab = "Cuantiles muestrales(Datos)", main = "QQ Normal Plot")

  # Encontrar linea que pasa por el primer y tercer cuartil y graficarla en azul.
  teo = qnorm(c(0.25,0.75))
  samp = quantile(data, c(0.25, 0.75))
  m = diff(samp) / diff(teo)
  b = samp[1] - m * teo[1]
  abline(b,m, col="blue")
}

get_normal_qq_confidence <- function(data, conf) {
  # Funcion para graficar la qq-plot normal de los datos junto con las bandas de confianza arrojadas por el estad�stico
  # de Kolmogorov - Smirnov correspondientes al nivel de confianza 'conf' (conf = 1 - alpha).
  # Entradas:
  #   * data: vector de datos, floats. (Solo puede tener tama�o N = 30 i.e la de los datos usados)
  #   * conf: real, nivel de confianza. (Solo puede ser 0.95 o 0.99)
  # Salidas:
  #   * ninguna (Produce la grafica)

  ###############   OBSERVACION    #####################
  # Solo se pueden usar esos valores de confianza por que hay que estar buscando en tablas el valor cr�tico correspondiente
  # al estad�sitico de kolmogoro-smirnov para el alpha u el tama�o de poblacion N correspondientes.
  # Si r tuviera incorporado en su kernel base una funci�n que nos arroja el valor critico no tendr�amos que hacer esto.
  # No encontr� una forma funcional para calcular este valor, solo encontr� que siempre hacian referencia a tablas.

  # Establecer el valor critico para N = 30 (longitud de los datos del ejercicio y el nivel de confianza (0.99 p 0.95):
  if(conf == 0.99) {
    d = 0.28987
  } else if (conf == 0.95) {
    d =  0.24170
  } else {
    print("Error, valor no soportado del nivel de confianza. Ver explicacion en los comentarios de la funcion.")
    print("Se finalizara la ejecuci�n de la funci�n , intentarlo nuevamente con un nivel de confianza 0.99 o 0.95")
    return(NULL)
  }



  # Ordenar (cuantiles muestrales):
  data = sort(data)
  n = length(data)

  # Aculumulada empirica
  p <- 1:n / (n + 1)

  # Obtener cuantiles teoricos de la normal:
  quant_teo = qnorm(p)

  # Graficar:
  plot(quant_teo, data, xlab = "Cuantiles teoricos", ylab = "Cuantiles muestrales(Datos)", main = "")

  # Encontrar linea que pasa por el primer y tercer cuartil y graficarla en azul.
  teo = qnorm(c(0.25,0.75))
  samp = quantile(data, c(0.25, 0.75))
  m = diff(samp) / diff(teo)
  b = samp[1] - m * teo[1]
  abline(b,m, col="blue")

  # Obtener localizaciones de los limites de los intervalos de confianza y pintarlos en rojo
  high_boundary <- qnorm(ifelse(p + d < 1, p + d, 1))
  low_boundary <- qnorm(ifelse(p - d > 0, p - d, 0))

  # Pintarlos en rojo:
  points(high_boundary, data,  col="red", t='l')
  points(low_boundary, data,  col="red", t='l')

  if (conf == 0.99) {
    mtext(side = 3, "QQNormal Plot - Confianza de .99", line = 1.6)
  } else if (conf == 0.95) {
    mtext(side = 3, "QQNormal Plot - Confianza de .95", line = 1.6)
  }


}

normal_pp_plot <- function(data) {
  # Funcion que grafica el pp-plot normal de los datos introducidos
  # Entradas:
  #   * data - Vector de datos
  # Salidas:
  #   * ninguna ( se produce la grafica)

  prom = mean(data)
  std_dev = sd(data)

  prob_empirica = empirical_data = sapply(data, empirical, data = data)
  prob_teo = pnorm(data, prom, std_dev)

  plot(prob_teo, prob_empirica, xlab="Acumulada Te�rica", ylab="Acumulada Emp�rica", main="PP Plot Normal")

  # Agregar linea identidad para comparar
  abline(0,1,col="blue")

}

#################   INCISO A    ########################

# Para solo ponerle "" , copiar datos de la tarea y ser flojo. ( o podriamos crear un csv)
data =  as.numeric(strsplit("23.37 21.87 24.41 21.27 23.33 15.20 24.21 27.52 15.48 27.19 25.05 20.40 21.05 28.83 22.90 18.00 17.55 25.92 23.64 28.96 23.02 17.32 30.74 26.73 17.22 22.81 20.78 23.17 21.60 22.37", " ")[[1]])
data = sort(data)

empirical_data = sapply(data, empirical, data = data)
plot(data, empirical_data, xlab="Diametro", ylab="Distribuci�n Emp�rica", main = "Distribuci�n Emp�rica - diametros de agave", t='s')

########### OBSERVAMOS QUE ###########

# Hay intervalos relativamente grandes de diametros sobre los que el valor de la distribuci�n empirica no cambia.
# (I.e en nuestra muestra no hubo valores de esos diametros)

################    INCISO B    #########################

# OJO LOS DATOS SE CARGAN EN EL INCISO A.
get_normal_qq(data)


########### OBSERVAMOS QUE ###########

# No parece que estos datos provengan de una distribuci�n normal, hay un ajuste particularmente malo en las colas de la distribuci�n.
# (Pareciera tener colas cortas respecto a una gaussiana)


################    INCISO C    #########################

# Para confianza de 0.95
get_normal_qq_confidence(data, 0.95)

# Para confianza de 0.99
get_normal_qq_confidence(data, 0.99)


########### OBSERVAMOS QUE ###########

# Aunque al ver la qq plot sin barras estabamos bastante seguros de que no era adecuado considerar que los datos siguen una distribucion
# normal, al poner las barras de confianza correspondientes al estadistico de kolmogorov- smirnov si caen dentro de ellas (ambos casos)
# (Lo demas se comenta en los otros incisos.)


################    INCISO D   #########################

# Solo hacer PP Plot.
normal_pp_plot(data)


########### OBSERVAMOS QUE ###########

# Algo similar a lo pasado: los puntos no caen  muy bien sobre la PP Plot. Aqui es mas facil ver que incluso cerca del centro de la
# distribucion hay diferencias considerables entre los datos y la distribucion normal.



################    INCISO E   #########################

# De todo lo que ya comentamos en los ejercicios pasados , aunque las bandas de Kolmgorov Smirnov contienen a los puntos de la
# QQ Plotno me sentiria muy feliz diciendo  que los datos pueden ser modelados adecuadamente con una distribucion normal.
# De hecho no es muy recomandado usar las bandas de confianza que arroja este estad�stico.
# Para quitarnos de dudas realicemos algunos histogramas ( con diferente numero de bins) y veamos que pasa:

hist(data, 5, main = "Histograma de los datos")
hist(data,10, main = "Histograma de los datos")
hist(data,20, main = "Histograma de los datos")

# Lo observado parece confirmar nuestra sospecha: si solo tuviera que decir si o no, dir�a que los datos no provienen de una distri-
# bucion normal.


###############################################  EJERCICIO 6 ################################################

################## INCISO A #############################

#OBS: No se especifica cuantos kernels programar / probar. Por eso solo puse el gaussiano. (Ver inciso b)

get_kernel_estimate <- function ( x, data, h, kernel ) {
  # Funcion que regresa el valor estimado de la densidad mediante el m�todo de un kernel.
  # Entradas:
  #   * x: Float,  Lugar donde se quiere estimar la densidad.
  #   * data: Vector de Floats, Conjunto de datos usado para realizar las estimaciones con los kernel.
  #   * h: Float, parametro de suavidad.
  #   * kernel: Funcion, es el kernel especifico que queremos utilizar. (i.e el paramtro es una funcion)
  # Salida:
  #   * Float: Valor estimado de la densidad en el punto seleccionado, con el parametro de suavidad y kernel escogidos.

  kernel_estimates = sapply((x - data)/h, kernel)

  return( (1/(length(data)*h)) * sum(kernel_estimates))

}

#################### INCISO B #####################

# OBS: HAY QUE CARGAR PRIMERO LA FUNCION PROGRAMADA EN EL INCISO A!!!!!

gaussian_kernel <- function (x) {
  # Kernel Gaussiano
  # Entradas:
  #   * x: Float donde queremos evaluar
  # Salidas:
  #   * Float, Valor de la funcion en ese punto.

  return (1/(sqrt(2*pi))* exp(-0.5*(x**2)))

}
# Leer como data frame
suicide_data  <- read.csv(file="Tratamiento.csv", header=FALSE, sep=",")

# Solo tenemos una variable, mejor dejar como vector  y ordenar
suicide_data = sort(suicide_data[,1])

# Obtener valores min y max para saber de donde a donde estimar.
min_val = min(suicide_data)
max_val = max(suicide_data)

# Evaluar al estimacion de densidad por el metodo de kernel en una grid sobre x para graficar:
h_vals = c(20,30,60)
for(h in h_vals) {
    x_vals = seq(min_val, max_val, 0.1)
    y_vals = sapply(x_vals, get_kernel_estimate, data=suicide_data, h=h, kernel=gaussian_kernel)
    plot(x_vals, y_vals, type='l', xlab="", ylab = "", main = "")
    # El mtext es para poder tener mayor control en el espacio que dejamos entre los ejes y sus nombres.
    # (Por defecto quedaban muy separados)
    mtext(side = 3, paste("Estimacion de Densidad - Kernel Gaussiano (h = ",h,")"), line = 1.6)
    mtext(side = 2, expression(hat(f)[h](x)), line = 2.4)
    mtext(side = 1, "Numero de Dias", line = 2.4)
}

########### OBSERVAMOS QUE ###########

# Yo me quedar�a con el valor h = 30. Para h = 20 pareciera que la estimaci�n est� siguiendo demasiado cerca a nuestra
# muestra particular (i.e al 'ruido'). Para h = 60 el pico que aparece cerca de x = 250 desaparece.
# Yo creo que h = 30 permite ver las cosas importantes, como esos 3 picos que podr�an arrojarnos bastante informaci�n.

###############################################  EJERCICIO 7 #######################################################

################################ INCISO A --- REGRESION POR MINIMOS CUADRADOS ######################################


linear_min_square_regression <- function(X, Y) {
  # Funcion que ajusta un modelo lineal optimizado de acuerdo al criterio de minimos cuadradados.
  # La salida es una lista cuyo primer elemento es a y el segundo elemento es b, donde Y = a + bX es el modelo ajustado
  # Entradas:
  #   * X: Vector de numeros (Variable Independiente)
  #   * Y: Vector de numeros (Variable Dependiente)
  # Salidas:
  #   * Lista de longitud 2 con los coeficientes (a,b) arrojados por la regresi�n.

  mu_X = mean(X)
  mu_Y = mean(Y)

  # Formulazo para sacar minimos cuadrados (una variable)
  b = sum((X-mu_X)*(Y-mu_Y))/sum((X-mu_X)**2)
  a = mu_Y -(b*mu_X)

  return(list(a,b))

}


data_maiz <- read.csv(file="Maiz.csv", header=TRUE, sep=",")

# X: PRECIO DE TONELADA DE MAIZ
# Y: PRECIO DE TONELADA DE TORTILLA

X <- data_maiz[,1]
Y <- data_maiz[,2]

# Obtener coeficientes de la regresion por minimos cuadrados:
res = linear_min_square_regression(X,Y)
a = res[[1]]
b = res[[2]]

# Plotear datos y linea de minimos cuadrados en rojo:
plot(X,Y, pch=16, main="Regresion por m�nimos cuadrados", xlab="Precio tonelada de Ma�z (USD)", ylab = "Precio tonelada de Tortilla (USD)", cex = .8)
abline(a,b, col="red", lwd=2)

############### QUE OBSERVAMOS ####################

# La relacion entre las variables parecer ser razonablemente bien descrita por un modelo lineal.
# La tendencia es muy clara. Intuitivamente es claro que si el ma�z aumenta su precio, por lo tanto tambi�n aumentar�
# el precio de la tortilla. Lo que vemos aqu� es que un modelo lineal es una aproximaci�n razonable para modelar la
# relaci�n entre estas variables.


################################# INCISO B --- REGRESION NO PARAM�TRICA TIPO KERNEL ##################################


# Copiamos las funciones del ejercicio 6 por si no las han cargado al environment

gaussian_kernel <- function (x) {
  # Kernel Gaussiano
  # Entradas:
  #   * x: Float donde queremos evaluar
  # Salidas:
  #   * Float, Valor de la funcion en ese punto.

  return (1/(sqrt(2*pi))* exp(-0.5*(x**2)))

}

get_kernel_regression <- function(X, Y, kernel, h) {
  # Funcion que regresa la funcion de regresion kernel.
  # Entradas:
  #   * X: Vector de la variable independiente.
  #   * Y: Vector de la variable dependiente.
  #   * kernel: Funcion kernel a utilizar. (i.e el parametro es una funcion)
  #   * h: Float, parametro de suavidad.
  # Salidas:
  #   * Funcion de regresion del kernel (i.e se regresa una funcion de un parametro)

  return( function(x) {sum(kernel((x-X)/h)*Y)/ sum(kernel((x-X)/h))} )
}


data_maiz <- read.csv(file="Maiz.csv", header=TRUE, sep=",")

# X: PRECIO DE TONELADA DE MAIZ
# Y: PRECIO DE TONELADA DE TORTILLA

X <- data_maiz[,1]
Y <- data_maiz[,2]

# Es chistoso lo que pasa al variar h, para que se vea graficamos con varios parametros de suavidad distintos.
# Podemos observar que a medida que h crece la dependencia capturada por la regresi�n es cada vez menor.
# Al final, pareciera que cuando h tiende a infinito la linea tiende a el promedio de Y. (i.e no nos da ninguna
# informacion saber el valor de X, al final a todos los mandar� a mu_y)
# Como bien dijo Victor, lo mas importante es ' que valor de h usaste'

param_suavidad <- c(1,2,3,4,5,10,20,50,100, 500)
for(h in param_suavidad) {
  kernel_regression = get_kernel_regression(X,Y,gaussian_kernel,h)
  #Graficar datos y tambien la regresion del kernel en rojo:
  plot(X,Y, pch=16, main=paste("Regresion por kernel gaussiano (h =", h ,")"), xlab="Precio tonelada de Ma�z (USD)", ylab = "Precio tonelada de Tortilla (USD)", cex = .8)
  lines(seq(min(X), max(X), 0.5), Vectorize(kernel_regression)(seq(min(X), max(X), 0.5)), col="red", lwd=1.5)
  Sys.sleep(2)
}

############### QUE OBSERVAMOS (INCISO B Y C !!) ####################

# Es chistoso lo que pasa al variar h, para que se vea graficamos con varios parametros de suavidad distintos.
# Podemos observar que a medida que h crece la dependencia capturada por la regresi�n es cada vez menor.
# Al final, pareciera que cuando h tiende a infinito la linea tiende a el promedio de Y. (i.e no nos da ninguna
# informacion saber el valor de X, al final a todos los mandar� a mu_y)
#
# Tambien pudimos observar que para valores peque�os de h la regresi�n tipo kernel es similar a lo que arrojar�a
# la linea de minimos cuadrados.  (Y donde difieren mas es en aquellas regiones del plano donde hay pocos puntos, por
# ejemplo ver que pasa con h = 1)
#
# Tambien recordaremos lo que bien dijo Victor: lo mas importante es ' que valor de h usaste'. En el contexto de
# regresi�n tal vez eso vendr�a significar algo asi como 'eligiendo el valor de h que quieras puedes hacer que la regresi�n
# te diga que las variables son tan independientes como desees'

