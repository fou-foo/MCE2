############################ #
########### Tarea 3 ######## #
############################ #

library("ggplot2")


#----------------------- -
#------ Ejercicio 1 ------
#----------------------- -

#b)

#Calcular la media acumulada para datos normales
ym <- cumsum(rnorm(10E5, pi, sqrt(2)))/(1:10E5)

#grafica de la simulacion
plot(x=1:10E5,y=ym, type="l", col="#5172e3", xlab = "N", ylab="Media Acumulada")

# �C�mo est� relacionado esto con la LGN?
# -- Entre mas grande sea una n, la probabilidad de que tienda a su media
# -- sera de 1, es decir la media muestral se acercara mas a la media teorica

#c)

#Repita el experimento anterior 100 veces

colores  <- rainbow(50) #QUE cUTE
#ACOSTUMBRATE A FIJAR UNA SEMILLA
set.seed(0)
#Grafique las ym de cada iteracion en una misma grafica
plot(x=1:10E5, y=ym, xlim=c(1,10E5), ylim = c(3,3.3),
     type = "l", col="#5172e3",xlab = "N", ylab="Media Acumulada" )
#Agregar las replicas sobre el plot
r <- replicate(10,lines(cumsum(rnorm(10E5, pi, sqrt(2)))/(1:10E5) ,
                     col=colores[sample(1:30,1)]) )

# �Qu� observa?
# -- Para todas las iteraciones, el valor de la media muestral se acerca m�s al
# -- valor teorico de la media poblacional

# d)
#Repita el experimento para una Cauchy

ymc <-cumsum(rcauchy(10E5, pi, sqrt(2)))/(1:10E5)
plot(x=1:10E5, y=ymc, xlim=c(1,10E5), ylim = c(1,5),
     type = "l", col="#5172e3",xlab = "N", ylab="Media Acumulada" )
ca <- replicate (10,lines(cumsum(rcauchy(10E5, pi, sqrt(2)))/(1:10E5) ,
                          col=colores[sample(20:50,1)]) )


# Dado que para esta distribuci�n no se cumple con lo requerido para la LGN
# debido a sus momentos, el realizar la media para un n grande, no garantiza
# que se aproxime al valor teorico

#----------------------- -
#------ Ejercicio 3 ------
#----------------------- -

# Realizaci�n de simulaciones
rm(list=ls())
gc()
set.seed(0)
N <- c(10, 50, 100, 250, 500, 1000, 2500, 5000, 10000)
p <- 0.4
alfa <- .05
#muestreo para cada N
muestreo <- sapply(1:length(N), function(x) rbinom(N[x],1,p))

#Media de cada muestreo
mean_p <- sapply(1:length(N), function (x) mean(muestreo[[ x ]]))
db1 <- data.frame(N_tam=as.factor(N), Media=mean_p)

#Calculo de epsilon
epsilon <- sqrt(  (1/(2*N)) * log(2/alfa) )
db1 <- cbind(db1, IC_min=p-epsilon, IC_max=p+epsilon)

#Restringir entre 0 y 1
db1$IC_min[db1$IC_min<0] <- 0
db1$IC_max[db1$IC_max>1] <- 1


# Grafica de las medias observadas para cada tama�o de muestra
p <- ggplot(db1) + geom_point(aes(x=N_tam, y=Media), color='coral', size=3) +
  scale_y_continuous(limits = c(0,1)) +
  geom_hline(yintercept = 0.4,linetype="dotted")

# # En teoria deberia arrojar el intervalo de confianza, sombreado en gris
 p + geom_ribbon(data=db1, aes(x=N_tam, ymax=IC_max, ymin=IC_min, fill = "band"), alpha = .5, color="blue")
# BUENA GRAFICA


#----------------------- -
#------ Ejercicio 5 ------
#----------------------- -

# a)
datos_agave <-c(23.37, 21.87, 24.41, 21.27, 23.33, 15.20,
         24.21, 27.52, 15.48, 27.19, 25.05, 20.40,
         21.05, 28.83, 22.90, 18.00, 17.55, 25.92,
         23.64, 28.96, 23.02,17.32, 30.74, 26.73,
         17.22, 22.81, 20.78, 23.17, 21.60,22.37)

# - Funcion que calcula la probabilidad acumulada a un punto a evaluar
# - Esta tambien imprimira la grafica de la funcion acumulada

F_empirica <- function(x, data){
  data_order <- sort(data)
  F_acum <- data.frame(x=data_order, F_acum=(1:length(data))/length(data))
  prob_acum <- F_acum$F_acum[match(x, F_acum$x)]
  return(prob_acum)
  plot(stepfun(F_acum$x, c(0,F_acum$F_acum) ), verticals = F, pch=20,
       main = "Funcion Emp�rica Acumulada", ylab="F(x)", ylim = c(0,1))
  abline(h=0, lty=2, col="gray")
  abline(h=1, lty=2, col="gray")

}
x <- seq(rango[1]-.5, rango[2]+.5, by=.01)
data <- datos_agave
rango <- range(datos_agave)
set.seed(0)
y <- mapply( function(x) F_empirica(x, data=datos_agave), x)
plot(x, y)
# La grafica es discontinua cuando no existe valores en x


# b)

# Escriba una funcion en R que realice la grafica Q-Q Normal
qq_plot <- function(data){
  # Introducir los datos a analizar

  data_order <- sort(data)
  # En notas se reviso que se hacia la division sobre N+1
  F_acum <- data.frame(x=data_order, F_acum=(1:length(data))/(length(data)+1))

  #Calculo de la probabilida acumulada para una normal
  normal_x <- qnorm(F_acum$F_acum)

  plot(x=normal_x, y=F_acum$x, xlab = "Valor Te�rico", ylab="Valor Emp�rico",
       main="Q-Q plot", pch=20, col="#a259a2")
}
qq_plot(datos_agave)
# c)
# Grafique la banda de confianza mediante estadistico de Kolmogorov-Smirnov
# para un nivel de confianza de .95 y .99



#----------------------- -
#------ Ejercicio 6 ------
#----------------------- -

# a) escriba una funcion que estime la densidad via kernel

# x: valor a estimar la funcion
# data: datos
# h: intervalo del kernel
# kernel: tipo del kernel

kernel_density <- function ( x, data, h, kernel ) {
  # En teoria deberia haber una lista de opciones del kernel (gaussiano, triangular, cuadrado, etc)
  # Pero para este ejercicio solo realizaremos el gaussiano, para futuras ocasiones, se agregara
  # catalogo con opciones a elegir

  dat_kernel = (data-x)/h
  kernel_gaussiano = ( 1/(sqrt(2*pi) ) * exp(-(dat_kernel^2)/2) )

  return( (1/(length(data)*h)) * sum(kernel_gaussiano))
}

db_trat  <- read.csv("Tratamiento.csv")
trat_order <- sort(db_trat$X1)


par(mfrow=c(1,1))
plot(trat_order, type="l", col="#a06685", main = "Datos Ordenados")

#Graficar para algunos h
par(mfrow=c(2,2))
x_val = seq(min(trat_order), max(trat_order), 1)
h_val = c(10, 20 ,30, 50)
for ( h in h_val){
  y_val = sapply(1:length(x_val), function(y) kernel_density(x_val[y], trat_order, h=h, kernel) )
  plot(x_val, y_val, type='l', xlab="x", ylab = "f(x)", main = paste("Estimaci�n h =", h) )
}

# Conclusion
# Para un h entre 20 y 30 se podria tener informaci�n suficiente para estimar un buen modelo, sin que
# se aleje mucho de los valores empiricos de la densidad

par(mfrow=c(1,1))

#----------------------- -
#------ Ejercicio 7 ------
#----------------------- -

# a) Calcule regresion por minimos cuadrados

minimos_cuadrados <- function(x, y){
  n <- length(x)
  mean_x  <- mean(x)
  mean_y  <- mean(y)
  sxy     <- sum(x*y) - n*mean_x*mean_y
  sxx     <- sum(x*x) - n*mean_x*mean_x

  #Calculo de betas
  beta1 <- sxy/sxx
  beta0 <- mean_y - beta1*mean_x

  y_est <- beta0 + beta1*x
  return(y_est)


}

maiz <- read.csv("maiz.csv")
y_gorro <- minimos_cuadrados(maiz$P..Tonelada.Ma�z, maiz$P..Tonelada.Tortilla)
errores <- maiz$P..Tonelada.Tortilla - y_gorro
qq_plot(errores)

# Estime la funcion via no parametrica

estimacion_kernel <- function(x, y, h) {
  x_val = seq(min(x), max(x), .1)
  n <- length(x)

  dat_kernel = sapply(1:n, function(z) (x[z]-x_val)/h )
  kernel_gaussiano = ( 1/(sqrt(2*pi) ) * exp(-(dat_kernel^2)/2) )


  y_aux<-matrix(0L, length(x_val), n)
  for (i in 1:n){
    y_aux[ ,i] <- (((1/sqrt(2*pi))*exp((-((x_val-x[i])^2)/(2*h^2))))*y[i])/(n*h)
  }
  #k_xy <-rowSums(Y) la varible Y no existe
  k_xy <-rowSums(y_aux)
  k_xx <-rowSums(kernel_gaussiano)

  y_gorro <- k_xy/k_xy


}
 Y COMO USO LA ULTIMA FUNCION ?
 COMO NO DOCUMENTAS QUE RECIBE NO TENGO IDEA DE COMO UTILIZARLA