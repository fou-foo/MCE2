#Tarea 3 Inferencia estadistica
#Alan Misael Castanon Lopez
################################# Ejercio 1 ####################################
#b)
##media=meida de la funcion, desest=desviacion estandar, graf=1 si graficar 0 si no
muesNor<-function(media,desest,graf){
  x<-rnorm(10^5,media,desest)
  xs<-cumsum(x)
  y<-rep(0,10^5)
  for(i in 1:10^5){
    y[i]<-xs[i]/i
  }
  if(graf==1){
    plot(y,xlab='x',ylab='y',main='Muestra Normal Media pi')
    par(new=TRUE)
    abline(h=media,col='blue')
  }
  else{
    return(y)
  }
}
muesNor(pi, sqrt(2), 1)
#c)
ACOSTUMBRA A FIJAR UNA SEMILLA
set.seed(0)
muesmatNor<-function(media,desest){
 y<-matrix(0,nrow=10^5,100)
 for(i in 1:100){
   y[,i]<-muesNor(media,desest,0)
 }
 matplot(y,type='l',xlab='x',
         ylab='y',main='100 iteraciones de la funcion muesNom',
         ylim=c(3, 3.2), col = col2rgb(colors()[1:100], alpha=0.01))
}
muesmatNor(media=pi, desest =  sqrt(2))

#d
##media=meida de la funcion, desest=desviacion estandar, graf=1 si graficar 0 si no
muesCau<-function(media,desest,graf){
  x<-rcauchy(10^5,media,desest)
  xs<-cumsum(x)
  y<-rep(0,10^5)
  for(i in 1:10^5){
    y[i]<-xs[i]/i
  }
  if(graf==1){
    plot(y,xlab='x',ylab='y',main='Muestra Cauchy',col='blue')
  }
  else{
    return(y)
  }
}
muesCau(pi, sqrt(2), 1)
#d)
set.seed(0)
muesmatCau<-function(media,desest){
  y<-matrix(0,nrow=10^5,100)
  for(i in 1:100){
    y[,i]<-muesCau(media,desest,0)
  }
  matplot(y,type='l',xlab='x',ylab='y',main='100 iteraciones de la funcion muesCau')
}
muesmatCau(pi, sqrt(2))
##################################Ejercicio 3#####################################
#b)
simic<-function(){
  n<-c(10,25,50,100,250,500,1000,2500,5000)
  is<-rep(1,9)
  ii<-rep(1,9)
  a<-0.05
  p<-0.4
  set.seed(2)
  for(i in 1:9){
    sb<-rbinom(1,n[i],p)
    pn<-sb/n[i]
    eps<-sqrt((1/(2*n[i]))*log(2/a))
    is[i]<-pn+eps
    ii[i]<-pn-eps
  }
  plot(n,is,type='b',ylim=c(0,1),xlab='',ylab='(pn^-eps,pn^+eps)',main='Simulaci�n de IDC')
  par(new=TRUE)
  plot(n,ii,type='b',ylim=c(0,1),xlab='n',ylab='')
  par(new=TRUE)
  abline(h=p,col='red',xlab='',ylab='')
}
set.seed(0)
simic()
#c)
lonint<-function(){
  n<-c(10,25,50,100,250,500,1000,2500,5000)
  li<-rep(1,9)
  p<-0.4
  a<-0.05
  aux<-0
  set.seed(2)
  for(i in 1:9){
    sb<-rbinom(1,n[i],p)
    pn<-sb/n[i]
    eps<-sqrt((1/(2*n[i]))*log(2/a))
  li[i]=2*eps
  if(li[i]<0.05&&aux==0){
    aux<-i
  }
  }
  plot(n,li,type='b',xlab='n',ylab='longitud del intervalo',main='longitud del intervalo vs n')
  print('La longitud del intervalo es menor que 0.05 apartir de n=')
  print(n[aux])

}
set.seed(0)
lonint()
##################################Ejercicio 5############################
#a)
Datos<-c(23.37,21.87,24.41,21.27,23.33,15.20,24.21,27.52,15.48,27.19,25.05,20.40,21.05,28.83,22.90,18.00,17.55,25.92,23.64,28.96,23.02,17.32,30.74,26.73,17.22,22.81,20.78,23.17,21.60,22.37)
funemp<-function(Datos,x){
  pd<-(1/30)
  s<-seq(1/30,1,1/30)
  Datos<-sort(Datos)
  i<-1
  while(Datos[i]<=x){
    i=i+1
  }
  y<-(pd*i)
  plot(Datos,s,type='s',xlab='x',ylab='F(x)',main='FDE')##como quitar las lineas verticales
  return(y)
}
#b)
qqNo<-function(Datos){
  Datos<-sort(Datos)
  pd<-(1/31)
  r<-rep(1,2)
  m<-1
  b<-1
  vdp<-rep(1,30)
  z<-rep(1,30)
  for(i in 1:30){
    vdp[i]<-pd*i
    z[i]<-qnorm(vdp[i])
  }
  r[1]<-z[30]-z[1]
  r[2]<-Datos[30]-Datos[1]
  m<-r[2]/r[1]
  b<-Datos[1]-m*z[1]
  plot(x=z,y=Datos,col='blue',xlim=c(-2,2),xlab='zi',main='Q-Q Normal')
  abline(b,m,col='blue')
  ##con qq line
  #plot(x=z,y=Datos,col='blue',xlim=c(-2,2),xlab='zi',main='Q-Q Normal (qqline)')
  #qqline(Datos,col='red')
  #d) pp-plot
  r[1]<-Datos[30]-Datos[1]
  r[2]<-vdp[30]-vdp[1]
  m<-r[2]/r[1]
  b<-vdp[1]-m*Datos[1]
  plot(x=Datos,y=vdp,ylim=c(0,1),col='blue',ylab='pi',main='P-P Plot')
  abline(b,m,col='red')
}
qqNo(Datos)
funemp(Datos, 4)

############################Ejercicio 7###################################
maiz<-read.csv(file="Maiz.csv")## Error no lee el archivo
b<-maiz[201,5]/maiz[201,3]
a<-maiz[201,2]-b*maiz[201,1]
plot(x=maiz[,1],y=maiz[,2])
abline(m=a,b,col='red')
