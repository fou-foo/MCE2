# Inferencia Estadistica
# Tarea 3
# Felipe Neri Chairez Cuellar.

#EJERCICIO 1

# A)

# La ley fuerte de los grandes numeros establece que en una sucesion infinita
# de vairables aleatorias independientes, el promedio de las variables converge
# en probabilidad al valor esperado mu.
Y LUEGO ? ESO TAMBIEN LO DICE LA LEY DEBIL

# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# B)

#Funcion ym

         # (media, desviacion estandar, muestra)
ym<-function(m=pi,d=2**0.25,n=10**5){
  x<-rnorm(n,mean = m,sd = d)
  y<-cumsum(x)/seq_along(x)
  return(y)
}

plot(ym(), type='l', main = "Ym", col = "blue")

# Es facil observar que ym converge a pi



# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# C)

c<-plot(ym(pi,2**0.25,10**5),type='l', col = "blue", ylim=c(3.1, 3.5))
replicate(n = 100, c)
CREO QUE ERA ASI
set.seed(0)
replicate(n=100, lines(ym(pi,2**0.25,10**5),type='l',
                       col = colors()[sample(1:100, 1)]))

# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
# D
      #CAUCHY
Ym<-function(m=pi,d=2**0.25, n=10**5){
  x<-rcauchy(n = n,location = m,scale = d)
  y<-cumsum(x)/seq_along(x)
  return(y)
}

plot(Ym(), main = " Cauchy ",type='l', col = "blue")
abline(pi,0)


C<-plot(Ym(pi,2**0.25,10**5),type='l', col = "blue")
replicate(n = 100, lines(Ym(), main = " Cauchy ",
                        type='l', col = colors()[sample(1:100,1)]))

##################################################################################################################
##################################################################################################################

# EJERCICIO 3

# PARAMETROS
N <- 10000
a <- 0.05
p <- 0.4
n <- c(10, 50, 100, 250, 500, 1000, 2500, 5000, 10000)

set.seed(100)
# Calcula el numero de veces que cae en el intervalo

num <- function(n){
  exitos <- 0
  epsilon <- sqrt((1/(2*n))*(log(2/a)))
  p.estimado <- mean(rbinom(n, 1, p))
  if(abs(p.estimado-p) < epsilon  )
  {
    exitos <-exitos+1     # Contador de exitos
  }
  return(exitos)
}
# Matriz de ceros de 9x2
simulacion <- matrix(0, 9, 2)

for(i in 1:9){
  simulacion[i, ]<-table(replicate(N, num(n[i])))
}

colnames(simulacion) <-  c("Fuera", "Dentro")
rownames(simulacion) <-  c("n = 10", "n = 50", "n = 10" ,"n = 250","n = 500", "n = 1000", "n = 2500", "n = 5000","n = 10000")

Cn <- matrix(0,9,2)
epsilon<-0
p.estimado<-0

for(i in 1:9)
{
  epsilon[i] <- sqrt((1/(2*n[i]))*(log(2/a)))
  set.seed(100)
  p.estimado[i] <- mean(rbinom(n[i], 1, p))
  Cn[i, ] <- c(p.estimado[i] - epsilon[i], p.estimado[i] + epsilon[i]);

  if(Cn[i, 1] < 0)
  {
    Cn[i, 1] <- 0
  }

  if(Cn[i, 2] > 1)
  {
    Cn[i, 2] <- 1
  }
}
sup <-Cn[, 1]   # Intervalo superior
inf <-Cn[,2]    # Intervalo inferior

plot(n, rep(.4, 9), type="l", ylim=c(0.1,0.8),main = "Intervalo de confianza", ylab="p = 0.4")
lines(n, sup,  type="l", col="blue")
lines(n, inf,  type="l", col="blue")

#############################################################################################################
#############################################################################################################

# EJERCICIO 5

#A)

datos<-vector()
#Los datos se cargan en el vector "datos"
datos<-c(23.37, 21.87, 24.41, 21.27, 23.33, 15.20, 24.21, 27.52, 15.48, 27.19, 25.05, 20.40, 21.05, 28.83, 22.90, 18.00, 17.55, 25.92, 23.64, 28.96, 23.02,17.32, 30.74, 26.73, 17.22, 22.81, 20.78, 23.17, 21.60,22.37)

empirica<-function(x,datos){
  prob<-(sum(datos<x))/(length(datos))
  return(prob)
}
# Rango entre las variables de la funcion de distribucion empirica
y<-sort(datos)
a<-vector()
for(i in 1:length(datos)-1){
  a[i]<-abs(y[i]-y[i+1])
}
m<-min(a)  #Menor rango entre las variables

# Espacio muestral
w<-seq(from = min(datos),to = max(datos)+m,by = m)
v<-vector()
for(i in 1:length(w)){
  v[i]<-empirica(w[i],datos)    #Vector que guarda la probabilidad empirica para el esapacio muestral
}

#Grafica de la Distribucion de Probabilidad Empirica
plot(w,v,type = "b",main = "Funcion de Distribucion Empirica",ylab  = "Probabilidad", col="black")


d<-vector()
for(i in 1:length(y)){
  d[i]<-empirica(y[i],datos)  #Vector que guarda la probabilidad empirica para los datos
}
plot(stepfun(y,c(d,1), right=FALSE), verticals = FALSE,main = "Funcion de Distribucion Empirica",ylab  = "Probabilidad", col="black")
lines(w,v,type = "b", col="blue")

# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

# B)

Cuantiles<-function(datos){
  cuanorm<-vector()      #Vector de los cuantiles normales
  estand<-vector()       #Vector de los datos ordenados estandarizados
  y<-sort(datos)
  for(i in 1:length(y)){
    cuanorm[i]<-qnorm(empirica(y[i],datos))
  }
  return(results<-list(cuanorm=cuanorm))
}
EN ESTA SECCION DEBIAS CALCULAR LOS CUANTILES EXPLICITAMENTE
#Genera los Q-Q plots accediendo al vector de la lista
plot(Cuantiles(datos)[[1]],y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="blue")
Cuantiles(datos)[[1]]

# . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .


#############################################################################################
#############################################################################################


# EJERCICIO 6
# A) Y B)

setwd("C:/Users/10/Desktop")
# Carga el archivo
datos<-as.vector(read.csv(file="Tratamiento.csv"))

#Entrada: valor x donde se evaluar� el estimador, X conjunto de datos , par�metro de suavidad h
#Salida: estimacion de la funci�n de densidad en el punto x
funcionkernel<-function(x,X,h){
  m<-(1/(sqrt(2*pi)*h))*exp(-(x-X)^2/(2*h^2))
  kernel<-(1/85)*c(sum(m))
  return(kernel)
}

#  h=20
a<-c(funcionkernel(0,datos,20),funcionkernel(10,datos,20),funcionkernel(20,datos,20),funcionkernel(30,datos,20 ),funcionkernel(40,datos,20),funcionkernel(50,datos,20 ),funcionkernel(60,datos,20 ),funcionkernel(70,datos,20 ),funcionkernel(90,datos,20 ),funcionkernel(100,datos,20),funcionkernel(110,datos,20 ))
plot(c(0,10,20,30,40,50,60,70,90,100,110),a,main=" h=20", xlab = "x", ylab = "densidad", type="b",col='blue')
#  h=30
b<-c(funcionkernel(10,datos,30),funcionkernel(20,datos,30),funcionkernel(30,datos,30 ),funcionkernel(40,datos,30),funcionkernel(50,datos,30 ),funcionkernel(60,datos,30 ),funcionkernel(70,datos,30 ),funcionkernel(80,datos,30 ),funcionkernel(90,datos,30 ))
plot(c(10,20,30,40,50,60,70,80,90), b,main=" h=30", xlab = "x", ylab = "densidad", type="b",col='blue')
#  h=80
c<-c(funcionkernel(-10,datos,80),funcionkernel(0,datos,80),funcionkernel(20,datos,80),funcionkernel(40,datos,80),funcionkernel(60,datos,80 ),funcionkernel(80,datos,80),funcionkernel(100,datos,80 ),funcionkernel(120,datos,80 ),funcionkernel(140,datos,80 ))
plot(c(-10,0,20,40,60,80,100,120,140 ), c,main=" h=80", xlab = "x", ylab = "densidad",type="b",col='blue')
# Para h=80, la curva se encuentra muy suavizada y ha perdido informacion
# En ese sentido la curva con h=20 posee mayor certeza en el comportamiento
# de los datos.

##############################################################################################################
##############################################################################################################
