##############################
#--------- TAREA 4 --------- -
#------ Ester Aguayo ------- -
##############################
rm(list=ls())
library("ggplot2")

############################ #
######### Ejercicio 2  #######
############################ #


# a) realizar una funci�n que nos de el estadistico Zn bajo una distribuci�n exponencial

# Variable zn cuando datos siguen distribuci�n exponencial
zn_exp <- function(n,m,lambda){
  # Input
  # m: numero de repeticiones que se hara el experimento
  # n: tama�o de la muestra aleatoria
  # lambda: parametro de la exponencial


 zn <- replicate(m, sqrt(n) * ( mean(rexp(n, 1/lambda)) - 1/lambda ) * lambda )

 return(zn)
 #output: zn

}

# b) Histogramas para diferentes tama�os de muestra

ns <- c(5, 10, 100, 500, 1000, 10000)
zn_total <- data.frame()
for( i in 1:6){
  zn_aux <- zn_exp(ns[i],1000,1)
  zn_total <- rbind(zn_total, cbind.data.frame(ZN=zn_aux, n=paste0("n=", ns[i]) ) )
}

summary(zn_total)

w <- ggplot(zn_total, aes(x = ZN, fill = n)) + geom_histogram(binwidth = .2) + facet_wrap( ~n ) + guides(fill=FALSE)
w
# BONITA GRAFICA, TE SUGIERO A�ADIR TITULOS INFORMATIVOS Y TAL VEZ PROBAR CON DIFERENTES FONDOS
COMO theme_bw() o theme_minimal()
# c) Realizar qqplot y ppplot

#Utilizaremos la funci�n de la tarea anterior
qq_plot <- function(data,n){
  # Introducir los datos a analizar

  data_order <- sort(data)
  # En notas se reviso que se hacia la division sobre N+1
  F_acum <- data.frame(x=data_order, F_acum=(1:length(data))/(length(data)+1))

  #Calculo de la probabilida acumulada para una normal
  normal_x <- qnorm(F_acum$F_acum)

  plot(x=normal_x, y=F_acum$x, xlab = "Valor Te�rico", ylab="Valor Emp�rico",
       main=paste0("Q-Q plot n=", n), pch=20, col="#a259a2")
}

#Utilizaremos la funci�n de la tarea anterior
pp_plot <- function(data,n){
  # Introducir los datos a analizar

  data_order <- sort(data)
  # En notas se reviso que se hacia la division sobre N+1
  F_acum <- data.frame(x=data_order, F_acum=(1:length(data))/(length(data)+1))

  #Calculo de la probabilida acumulada para una normal
  normal_x <- pnorm(data_order, mean = mean(data_order), sd= sd(data_order))

  plot(x=normal_x, y=F_acum$F_acum, xlab = "Valor Te�rico", ylab="Valor Emp�rico",
       main=paste0("P-P plot n=", n), pch=20, col="#a259a2")
}

par(mfrow=c(2,3))

# Grafica de qq plot
for ( i in 1:6){
  qq_plot(zn_total$ZN[as.numeric(zn_total$n)==i], ns[i])
}

for ( i in 1:6){
  pp_plot(zn_total$ZN[as.numeric(zn_total$n)==i], ns[i])
}



par(mfrow=c(1,1))
# Y QUE CONCLUYES ?
############################ #
######### Ejercicio 3  #######
############################ #

# a) realizar una funci�n que nos de el estadistico Zn bajo una distribuci�n binomial

zn_bin <- function(n,m,N,p){

  zn <- replicate(m, (sqrt(n) * ( mean(rbinom(n, size = N, prob = p  )) - N*p )) / (N*p) )

  return(zn)

}


#b) Repetir los pasos para el problema anterior

zn_total5 <- data.frame()
for( i in 1:6){
  zn_aux <- zn_bin(ns[i],1000,15,.5)
  zn_total5  <- rbind(zn_total5, cbind.data.frame(ZN=zn_aux, n=paste0("n=", ns[i], " p=1/2 N=15") ) )
}
b <- ggplot(zn_total5, aes(x = ZN, fill = n)) + geom_histogram(binwidth = .1) + facet_wrap( ~n ) + guides(fill=FALSE)
b

# Graficas qq-plot pp-plot
par(mfrow=c(2,3))
for ( i in 1:6){
  qq_plot(zn_total5$ZN[as.numeric(zn_total$n)==i], ns[i])
}

for ( i in 1:6){
  pp_plot(zn_total5$ZN[as.numeric(zn_total$n)==i], ns[i])
}
par(mfrow=c(1,1))


#c) Para p=.1 y N=15 y n=5,10,20,100, m=1000 graficar histogramas

ns_aux<- c(5,10,20,100)
zn_total1 <- data.frame()
for( i in 1:4){
  zn_aux <- zn_bin(ns_aux[i],1000,15,.1)
  zn_total1  <- rbind(zn_total1, cbind.data.frame(ZN=zn_aux, n=paste0("n=", ns_aux[i], " p=0.1 N=15") ) )
}

b2 <- ggplot(zn_total1, aes(x = ZN, fill = n)) + geom_histogram(binwidth = .3) + facet_wrap( ~n ) + guides(fill=FALSE)
b2

# Para valores peque�os de n se centraliza mucho en la media, pero cae con rapidez, mientras que para n grande caen suavemente


#d) Para p=.99 y N=15 y n=5,10,20,100, m=1000 graficar histogramas
zn_total99 <- data.frame()
for( i in 1:4){
  zn_aux <- zn_bin(ns_aux[i],1000,15,.99)
  zn_total99  <- rbind(zn_total99, cbind.data.frame(ZN=zn_aux, n=paste0("n=", ns_aux[i], " p=0.99 N=15") ) )
}

b3 <- ggplot(zn_total99, aes(x = ZN, fill = n)) + geom_histogram(binwidth = .1) + facet_wrap( ~n ) + guides(fill=FALSE)
b3

par(mfrow=c(1,1))

# todo queda centralizado en un solo valor por que la probabilidad que est� ah� es muy alta

############################ #
######### Ejercicio 4  #######
############################ #

# Simulaci�n distribuci�n asint�tica

sn_function <- function(n,p){
  #Input
  #n: tama�o de muestra
  #p: probabilidad de exito

  #sumaremos 1 pues la simulaci�n inicia en 0
  xi_completo <- rbinom(n+1,1,p)
#realizamos la multiplicacion para xi y xi-1
 s_aux <- xi_completo[-length(xi_completo)]*xi_completo[-1]
 # BUEN USO DE INDICES
 sn_acum <- sum(s_aux)
 return(sn_acum)
 #outpup: suma acumulada de la multiplicacion de los contiguos
}



F_empirica <- 1:100/100
sn_acum <- sort( replicate(100, sn_function(1000,.4)) )
# observar que tiene una forma parecida a la normal
hist(sn_acum)

# Grafica de la distribuci�n emp�rica
plot(stepfun(sn_acum, c(0,F_empirica) ), verticals = F, pch=20,
     main = "Funci�n Emp�rica Acumulada", ylab="F(Sn)", xlab="Sn", ylim = c(0,1))
abline(h=0, lty=2, col="gray")
abline(h=1, lty=2, col="gray")

# TE FALTO EL RESULTADO ANALITICO
