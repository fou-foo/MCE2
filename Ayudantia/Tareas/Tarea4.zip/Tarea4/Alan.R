
##funciones auxiliares (Tarea 3)
#Ejercicio 2 (TCLC)
#a)
tclcexp<-function(l,n,m,qp){
  set.seed(2)
  zn<-rep(0,m)
  qe<-rep(0,m)
  for(i in 1:m){
    ve<-rexp(n,l)
    md<-mean(ve)
    rn<-sqrt(n)
    zn[i]<-(rn*(md-1/l))/(1/l)
  }
  sort(zn);
  for(i in 1:m){
    qe[i]<-qnorm(zn[i])
  }
  pe<-pnorm(zn)
  if(qp==0){
    hist(zn,col='blue')
  }
  else{
    plot(x=qe,y=zn,ylim=c(0,1),xlim=c(-2,2),main='Q-Q plot normal')
    plot(x=zn,y=pe,main='P-P plot normal')
  }

}
#b)
tclcexp(1,5,1000,0)
tclcexp(1,10,1000,0)
tclcexp(1,100,1000,0)
tclcexp(1,500,1000,0)
tclcexp(1,1000,1000,0)
tclcexp(1,10000,1000,0)
#c)
tclcexp(1,10000,1000,1)
tclcexp(1,10,1000,1)
tclcexp(1,100,1000,1)
tclcexp(1,500,1000,1)
tclcexp(1,1000,1000,1)
tclcexp(1,10000,1000,1)
#Ejercicio 3 (TCLC)
#a)
tclcbin<-function(p,N,n,m){
  set.seed(2)
  zn<-rep(0,m)
  for(i in 1:m){
    vb<-rbinom(n,N,p)
    md<-mean(vb)
    rn<-sqrt(n)
    zn[i]<-(rn*(md-N*p))/(sqrt(N*p*(1-p)))
  }
  hist(zn,col='green')
}
#graficas
#b)
tclcbin(0.5,15,5,1000)
tclcbin(0.5,15,10,1000)
tclcbin(0.5,15,100,1000)
tclcbin(0.5,15,500,1000)
tclcbin(0.5,15,1000,1000)
tclcbin(0.5,15,10000,1000)
#c)
tclcbin(0.1,15,5,1000)
tclcbin(0.1,15,10,1000)
tclcbin(0.1,15,20,1000)
tclcbin(0.1,15,100,1000)
#d)
tclcbin(0.99,15,5,1000)
tclcbin(0.99,15,10,1000)
tclcbin(0.99,15,20,1000)
tclcbin(0.99,15,100,1000)
