
## EJERCICIO 2
Z_n<-function(n,m,l){
  z<-rep(0,m)
  for(i in 1:m){
    sim<-rexp(n,l)
    z[i]<-l*sqrt(n)*(mean(sim)-(1/l))
  }
  return(z)
}

ppplot<-function(m)
{
  n<-length(m)
  m<-sort(m)
  Fi<-c(1:n)/n
  zi<-(m-mean(m))/sd(m)
  plot(Fi,pnorm(zi),
       xlab="Probabilidad de la muestra",
       ylab="Probabilidades normales")

}


m=1000
l=1
n=c(5,10,100,500,1000,10000)
par(mfrow=c(3,1))
for(i in 1:length(n)){
  aux<-Z_n(n[i],m,l)
  hist(aux, main="",xlab = "Z_n")
  qqnorm(aux)
  ppplot(aux)
}


## EJERCICIO 3
Z_n2<-function(n,m,p,N){
  z<-rep(0,m)
  for(i in 1:m){
    sim<-rbinom(n,N,p)
    q<-1-p
    z[i]<-sqrt(n)*(mean(sim)-(N*p))/(sqrt(N*p*q))
  }
  return(z)
}


m=1000
N=15
p=.5
n=c(5,10,100,500,1000,10000)
par(mfrow=c(3,1))
for(i in 1:length(n)){
  aux<-Z_n2(n[i],m,p,N)
  hist(aux, main="",xlab = "Z_n")
  qqnorm(aux)
  ppplot(aux)
}

m=1000
N=15
p=.1
n=c(5,10,20,100)
for(i in 1:length(n)){
  aux<-Z_n2(n[i],m,p,N)
  hist(aux, main="",xlab = "Z_n")
}

p=.99
for(i in 1:length(n)){
  aux<-Z_n2(n[i],m,p,N)
  hist(aux, main="",xlab = "Z_n")
}


## Ejercicio 4
n=1000
p=.4
s_n<-rep(0,100)
for(i in 1:100){
  sim<-rbinom(n+1,1,p)
  z<-rep(8,n)
  for(j in 1:n){
    z[j]<-sim[j+1]*sim[j] #aqui si simulaste bien te doy medio punto
  }
  s_n[i]=sum(z==1)
}
plot(ecdf(s_n),main="")
n160<-function(x){return(pnorm(x,160,sqrt(160*.84)))}
curve(n160,120,200,add = T,col="red")
