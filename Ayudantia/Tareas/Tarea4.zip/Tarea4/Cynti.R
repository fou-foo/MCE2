#Alumna: Ram�rez Islas Cynthia Mariangel
#Tarea 4. Inferencia estad�stica

#Ejercicio 2) En este ejercicio corroborara mediante simulaciones el Teorema Cl�sico de L�mite Central
#(TCLC)

#a)Escriba la siguiente funci�n en R. Simule una muestra de tama�o n de una variable
#aleatoria Exponencial(??) y calcule el estad�stico Zn . Repita lo anterior
#m veces. La funci�n deber� tomar como pa�metros n, m y ?? y regresar un vector de
#tama�o n conteniendo la muestra de Zn.

simulacion1<-function(n,m,lambda){

  #Simulamos m muestras de tama�o n con par�metro lamda
  muestra<-replicate(m,rexp(n,lambda), simplify = "array")

  Zn=((sqrt(n))*(apply(muestra, 2, mean)-(1/lambda)))*(lambda)

  return (Zn)
}

#b) Para n = 5, 10, 100, 500, 1000, 10000, m = 1000 y ?? = 1, utilice la funci�n del inciso
#anterior para obtener muestras de Zn. Grafique las muestras anteriores en un histograma
#(un histograma para cada n).

#c) Para cada una de las muestras generadas en el inciso anterior, encuentre el Q-Q plot y
#el P-P plot normales. Comente sus resultados

#Simulacion con n=5
n1=simulacion1(5,1000,1)
TE SUGIERO FIJAR UNA SEMILLA CUANDO SIMULES
set.seed(0)
hist(n1,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 5")
#QQ plot n=5
qqnorm(n1)

#Simulacion con n=10
n2=simulacion1(10,1000,1)
hist(n2,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 10")
#QQ plot n=10
qqnorm(n2)

#Simulacion con n=100
n3=simulacion1(100,1000,1)
hist(n3,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 100")
#QQ plot n=100
qqnorm(n3)

#Simulacion con n=500
n4=simulacion1(500,1000,1)
hist(n4,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 500")
#QQ plot n=500
qqnorm(n4)

#Simulacion con n=1000
n5=simulacion1(1000,1000,1)
hist(n5,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 1000")
#QQ plot n=1000
qqnorm(n5)

#Simulacion con n=10000
n6=simulacion1(10000,1000,1)
hist(n6,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 10,000")
#QQ plot n=10000
qqnorm(n6)

#�Qu� observa? Podemos notar que al calcular el estad�stico Zn  y  aumentar el tama�o de la muestra (con una n lo suficientemente grande)
#su distribuci�on se asemeja a la de una normal
#�Qu� tiene que ver su resultado con el TCLC? Hemos corroborado mediante simulaciones (con diferentes tama�os de muestra) el Teorema del L�mite Central
y el ppplot ?
#####################################################################################################################
#Ejercicio 3. En este ejercicio volver� a trabajar con el TLC.

#a) Escriba una funci�n an�loga a la pedida en el inciso 2a) para una distribuci�n Binomial(p, N).
#La funci�n deber� tomar los mismos par�metros a los pedidos en el inciso 2a), con excepci�n
#al par�metro ?? que tendr� que ser sustituido p y N.

simulacion2<-function(n,m,p, N){

  #Simulamos m muestras de tama�o n con par�metro lamda
  muestra2<-replicate(m,rbinom(n,N, p), simplify = "array")

  Zn=(sqrt(n)*(apply(muestra2, 2, mean)-(N*p)))/sqrt(N*p*(1-p))

  return (Zn)
}

#b) Para p = 1/2 y N = 15, repita los incisos 2b) y 2c) para el caso Binomial de este
#ejercicio.

#Simulacion con n=5
m1=simulacion2(5,1000, 1/2,15)
hist(m1,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 5")
#QQ plot n=5
qqnorm(m1)

#Simulacion con n=10
m2=simulacion2(10,1000, 1/2,15)
hist(m2,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 10")
#QQ plot n=10
qqnorm(m2)

#Simulacion con n=100
m3=simulacion2(100,1000, 1/2,15)
hist(m3,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 100")
#QQ plot n=100
qqnorm(m3)

#Simulacion con n=500
m4=simulacion2(500,1000, 1/2,15)
hist(m4,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n=500")
#QQ plot n=500
qqnorm(m4)

#Simulacion con n=1000
m5=simulacion2(1000,1000, 1/2,15)
hist(m5,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 1000")
#QQ plot n=1000
qqnorm(m5)

#Simulacion con n=10000
m6=simulacion2(10000,1000, 1/2,15)
hist(m6,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 10000")
#QQ plot n=10000
qqnorm(m6)


#c) Para p = 0.1, N = 15, n = 5, 10, 20, 100 y m = 1000, genere muestras de Zn y grafique
#estas muestras en un histograma (un histograma para cada n).

#Simulacion con n=5
l1=simulacion2(5,1000, 0.1,15)
hist(l1,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 5")

#Simulacion con n=10
l2=simulacion2(10,1000, 0.1,15)
hist(l2,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 10")

#Simulacion con n=20
l3=simulacion2(20,1000, 0.1,15)
hist(l3,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 20")

#Simulacion con n=100
l4=simulacion2(100,1000, 0.1,15)
hist(l4,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n=100")

#Simulacion con n=1000
l5=simulacion2(1000,1000, 0.1,15)
hist(l5,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 1000")

#�Qu� observa? Explique.
#obervamos quea diferencia del caso anterior, con n peque�as el histograma no es sim�trico ni se asemeja al de una normal.
#una vez que vamos aumentando el tama�o de muestra "n", el histograma se va "moldeando" por la derecha"
#hasta llegar a una distribucion muy similar a la de una normal
Y QUE OPINAS SOBRE LA VELOCIDAD A LA QUE LO HACE ??
#d) Repita el inciso anterior para p = 0.99. Compare su resultado con lo obtenido en el inciso
#anterior.

#Simulacion con n=5
k1=simulacion2(5,1000, 0.99,15)
hist(k1,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 5")

#Simulacion con n=10
k2=simulacion2(10,1000, 0.99,15)
hist(k2,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 10")

#Simulacion con n=20
k3=simulacion2(20,1000, 0.99,15)
hist(k3,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 20")

#Simulacion con n=100
k4=simulacion2(100,1000, 0.99,15)
hist(k4,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n=100")

#Simulacion con n=1000
k5=simulacion2(1000,1000, 0.99,15)
hist(k5,freq = FALSE,xlab = "Estad�stico Zn", main="Histograma n= 1000")

SOLO TE FALTARON LOS PPLOTS, BUSCALOS YA ESTAN IMPLEMENTADOS EN R
#########################################################################################################
#Ejercicio 4) Supongamos que X0,X1,... es una sucesi�n de experimentos Bernoulli independientes con probabilidad de exito p.
#Supongamos tambien que Xi es la indicadora del exito de su equipo en el i-esimo juego de un rally de futbol.
#Su equipo anota un punto cada vez que tiene un exito seguido de otro.
#Denotemos por Sn al numero de puntos que su equipo anota al tiempo n.

#b) Simule una sucesion de n = 1000 v.a. como arriba y calcule S1000 para p = 0.4.
#Repita este proceso 100 veces y grafique la distribucion empirica de S1000 que se obtiene de la simulacion
#y empalmela con la distribucion asintotica teorica que obtuvo. Comente sus resultados.

Simulacion <- function(){

#  muestra <- sample( x = c(1,0), size = 1000, replace = T, probabilidad = c(0.4,0.6))
#SUPONGO QUE TE REFIAS A :
   muestra <- sample( x = c(1,0), size = 1000, replace = T, p = c(0.4,0.6))

  vector = 0

  for(i in 2:1000) {

    if( muestra[i-1] * muestra[i] == 1){

      vector = vector+1

    }
  }
  return(vector)
}


juegos_ganados <- replicate(100,Simulacion())

#Creamos nuestra funci�n emp�rica
Funcion_Empirica <- function(x,y){

  prob_Fun <- (sum(y<x))/(length(y))

  return(prob_Fun)
}

#Vamos a ir generando nuestro espacio muestral
NO EXISTE LA VARIABLE jganados
SUPONGO QUE ES juegos_ganados
probabilidad <- seq(from = min(jganados),to = max(jganados),by = 0.5)
probabilidad <- seq(from = min(juegos_ganados),to = max(juegos_ganados),by = 0.5)
Espacio_Muestral <- vector()

for(i in 1:length(probabilidad)){

  #En este vector nos guarda la probabilidad emp�rica y se lo asignamos a nuestro Espacio Muestral
  Espacio_Muestral[i] <- Funcion_Empirica(probabilidad[i],juegos_ganados)

}

#Graficamos la Funci�n de Distribuci�n emp�rica (nuestro espacio muestral vs probabilidad)
plot(probabilidad, Espacio_Muestral,type = "p",main = "Funci�n de Distribuci�n Emp�rica",
     xlab  = "Espacio Muestral",ylab  = "Probabilidad", col="purple", lwd=2)
ok y el resultado analitico ??


