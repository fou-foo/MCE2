######################################################### EJERCICIO 2 ##############################################################

get_avg_exp_standarized <- function(n, m, lambda) {
  # Funcion que genera m  muestras de tama�o n de una poblacion que sigue una distribucion exponencial con par�metro 1/lambda, calcula el
  # valor estandarizado del promedio�y regresa un vector de tama�o m con los resultados.
  # OBS: Si siguieramos la notacion usual Exp(lambda) tendr�a esperanza lambda y varianza lambda**2. Comparando con lo que se nos pide
  # calcular podemos observar que en realidad se refieren a una Exp(1/lambda), asumiremos que en efecto si cambiaron la notaci�n.
  # (Supongo la razon de esto es que R usa una parametrizacion distinta a la que vimos en clase)
    # ES VERDAD
  results <-replicate(m, sqrt(n)*(mean(rexp(n, lambda)) - 1/lambda)/(1/lambda))
  return(results)

}



empirical <- function(data, x) {
  # Funcion para calcular la funcion de distribucion emp�rica del dato x.
  # Entradas:
  #   * data: vector de datos, floats.
  # Salidas:
  #   * Float, valor de la funcion de distribucion empirica en el punto x.

  data = sort(data)
  return(length(which(data <= x)) / length(data))
}



normal_pp_plot <- function(data) {
  # Funcion que grafica el pp-plot normal de los datos introducidos
  # Entradas:
  #   * data - Vector de datos
  # Salidas:
  #   * ninguna ( se produce la grafica)

  prom = mean(data)
  std_dev = sd(data)

  prob_empirica = empirical_data = sapply(data, empirical, data = data)
  prob_teo = pnorm(data, prom, std_dev)

  plot(prob_teo, prob_empirica, xlab="Acumulada Te�rica", ylab="Acumulada Emp�rica", main="")

  # Agregar linea identidad para comparar
  abline(0,1,col="blue")

}


get_normal_qq <- function(data) {
  # Funcion para graficar la qq-plot normal de los datos.
  # Entradas:
  #   * data: vector de datos, floats.
  # Salidas:
  #   * ninguna (Produce la grafica)



  # Ordenar (cuantiles muestrales):
  data = sort(data)
  n = length(data)

  # Aculumulada empirica ( con la convencion mostrada en el pdf que se encuentra en la clase 6)
  p <- 1:n / (n + 1)

  # Obtener cuantiles teoricos de la normal:
  quant_teo = qnorm(p)

  # Graficar:
  plot(quant_teo, data, xlab = "Cuantiles teoricos", ylab = "Cuantiles muestrales(Datos)", main = "")

  # Encontrar linea que pasa por el primer y tercer cuartil y graficarla en azul.
  teo = qnorm(c(0.25,0.75))
  samp = quantile(data, c(0.25, 0.75))
  m = diff(samp) / diff(teo)
  b = samp[1] - m * teo[1]
  abline(b,m, col="blue")
}



######################## INCISO B Y C ###############################
lambda = 1
m = 1000
set.seed(0)
for(n in c(5,10,100,500,1000,10000)) {
  # Freq=FALSE es para que las frecuencias mostradas sean relativas.
  data <- get_avg_exp_standarized(n,m,lambda)
  hist(data, xlab=bquote(Z[n]), ylab="Frecuencia relativa", freq=FALSE, main =bquote("Distribuci�n simulada de "~ Z[.(n)] ~" con " ~ lambda == .(lambda)))

  # QQPlot:
  get_normal_qq(data)
  mtext(side = 3, bquote("Q-Q Plot normal para n =" ~ .(n) ), line = 1.6)
  Sys.sleep(2.2)
  # PPPlot:
  normal_pp_plot(data)
  mtext(side = 3, bquote("P-P Plot normal para n =" ~ .(n) ), line = 1.6)
  Sys.sleep(2.5)

}

####### OBSERVAMOS QUE ###############
# A medida que n crece los puntos en la Q-QPlot cada vez est�n mas cercanos a la identidad, lo que indica que conforme n crece la
# distribuci�n de Zn cada vez se va asemejando mas y mas a una normal. (Esto ya nos lo esperabamos , pues es justo lo que dice el
# teorema del limite central, que las Zn con una estandarizacion adecuada convergen a la normal estandar cuando n es muy grande).
# Ademas podemos observar que las Q-QPlot son un poco mas informativas que las P-PPlot puesto que si  solo vieramos las P-PPlots
# paraceria que no hay mucha diferencia entre las distribuciones mostradas para n >= 100, pero esta  diferencia si puede ser
# observada en las Q-QPlots. (Como el rango de las PP-Plot es (0,1) en ambos ejes, no es facil ver cambios "peque�os". Como en
# las Q-Qplot el rango es aproximadamente (-3,3) es mas facil ver "desajustes" entre los puntos que en la correspondiente PP-Plot)
# ESO ES NORMAL EN LAS COLAS, TE SUGIERO QUE TE ACOSTUMBRES A FIAJR UNA SEMILLA


######################################################### EJERCICIO 3 ##############################################################



## OBSERVACION: HAY QUE CARGAR PRIMERO LAS FUNCIONES DEL EJERCICIO 2 PARA CARGAR LAS FUNCIONES PP PLOT Y LAS QQ PLOT Y ESO.

get_avg_binom_standarized <- function(n, m, N, p) {
  # Funcion que genera m  muestras de tama�o n de una poblacion que sigue una distribucion Binomial(N,p), calcula el
  # valor estandarizado del promedio�y regresa un vector de tama�o m con los resultados.

  results <-replicate(m, sqrt(n)*(mean(rbinom(n, N, p)) - N*p)/(sqrt(N*p*(1-p))))
  return(results)

}

##################### INCISO B ########################

p = 0.5
N = 15
m = 1000
set.seed(0)
for(n in c(5,10,100,500,1000,10000)) {
  # Freq=FALSE es para que las frecuencias mostradas sean relativas.
  data <- get_avg_binom_standarized(n, m, N, p)
  hist(data, xlab=bquote(Z[.(n)]), ylab="Frecuencia relativa", freq=FALSE, main =bquote("Distribuci�n simulada de "~ Z[.(n)] ~ "con p =" ~  .(p) ~ ", N = " ~  .(N) ))
  Sys.sleep(1.5)
  # QQPlot:
  get_normal_qq(data)
  mtext(side = 3, bquote("Q-Q Plot normal para n =" ~ .(n) ~ "con p =" ~  .(p) ~ ", N = " ~  .(N)), line = 1.6)
  Sys.sleep(1.5)
  # PPPlot:
  normal_pp_plot(data)
  mtext(side = 3, bquote("P-P Plot normal para n =" ~ .(n) ~ "con p =" ~  .(p) ~ ", N = " ~  .(N) ), line = 1.6)
  Sys.sleep(1.5)
}

########### OBSERVAMOS QUE ##############

# No vale la pena comentar mucho, los comentarios serian exactamente los mismos que hicimos en el ejercicio 1.
# Lo unico interesante que creo valdr�a la pena mencionar es que aqui estamos observando que al TLC no le importa la distribucion
# que sigan las Xi (mientras sea la misma y sean independientes, con esperanza y varianza finitas), y tampoco que sean continuas o
# discretas. (En el ej 1 era una exponencial (continua), en este ej es una binomial (discreta)).
#  Y QUE OPINAS DE LA VELOCIDAD DE CONVERGENCIA ??
##################### INCISO C ########################

p = 0.1
N = 15
m = 1000
set.seed(0)
for(n in c(5,10,20,100)) {
  # Freq=FALSE es para que las frecuencias mostradas sean relativas.
  data <- get_avg_binom_standarized(n, m, N, p)
  hist(data, xlab=bquote(Z[.(n)]), ylab="Frecuencia relativa", freq=FALSE, main =bquote("Distribuci�n simulada de "~ Z[.(n)] ~ "con p =" ~  .(p) ~ ", N = " ~  .(N) ))
    Sys.sleep(1)
}

########### OBSERVAMOS QUE ##############

# Como a medida que p es cada vez mas lejana a  0.5 (i.e p cerca de 0 o 1) la distribucion binomial correspondiente es cada vez mas
# asim�trica, necesitamos tomar una muestra mas grande para que esta asimetr�a no est� presente en la distribucion de los promedios,
# y �stos puedan modelarse adecuadamente como una normal. En lo personal, creo que solo para N = 100 ser�a razonable asumir que
# lo que se ve es una distribuci�n normal. (OBS: obviamente si quisieramos hacer esto bien hay que hacer cosas como qq-plots y eso
# para de alguna manera intentar cuantificar estos hechos y no solo quedarnos con un "pues parece".)
# LA GRAFICA FINAL ES SIMETRICA Y PARECE TENER COLAS NO PESADAS



##################### INCISO D ########################

p = 0.99
N = 15
m = 1000

for(n in c(5,10,20,100)) {
  # Freq=FALSE es para que las frecuencias mostradas sean relativas.
  data <- get_avg_binom_standarized(n, m, N, p)
  hist(data, xlab=bquote(Z[.(n)]), ylab="Frecuencia relativa", freq=FALSE, main =bquote("Distribuci�n simulada de "~ Z[.(n)] ~ "con p =" ~  .(p) ~ ", N = " ~  .(N) ))
  Sys.sleep(1)
}

########### OBSERVAMOS QUE ##############

# Aqu� observamos algo similar al ejercicio pasado, con la diferencia de que como ahora p es 0.99 (i.e la distribuci�n es mucho mas
# asim�trica que en el caso anterior) ahora no basta ni siquiera tomar n = 100 para que la distribuci�n mostrada se asemeje a una normal)
# En conclusi�n, lo que nos dicen estos ejercicios es que si sabemos que la distribuci�n que siguen las Xi es muy asim�trica entonces
# tendremos que tomar una muestra muy grande para que la asimetr�a muera al tomar el promedio y la distribucion de los promedios se
# pueda modelar adecuadamente como una normal, mientras que si la distribuci�n es aproximadamente sim�trica el tama�o de muestra puede
# reducirse y tendremos resultados "buenos". (OJO: todo esto que se dice es al aire. Obviamente si quisieramos hacer esto bien
# tendr�amos que hacer pruebas de normalidad , ver boxplots, etc...)
# NO TE CREAS, EN OCACIONES UNA EVIDENCIA VISUAL PUEDE AHORARTE TIEMPO FRENTE A UNA PRUEBA DE HIPOTESIS

######################################################### EJERCICIO 4 ##############################################################

get_sn <- function(n,p) {
  # Regresar el valor de una simulacion de Sn, con p = prob de exito de las Xi's.

  data = sample(c(1,0), size=n+1, replace = TRUE, prob = c(p,1-p))
  data_shift = numeric(n+1)
  data_shift = tail(data,-1)
  data = head(data,-1)
  prods = data*data_shift


  return(sum(prods))


}

# Realizar simulacion de lo que se pide.(En lugar de 100 simulaciones hicimos 10,000 para que se notara mejor la convergencia)
n = 1000
p = 0.4
results = replicate(10000, get_sn(n,p) )

# Graficar empirica con puntos en azul:
plot(ecdf(results), main="Distribucion Emp�rica vs Distribuci�n Te�rica", xlab=bquote(S[1000]), col=rgb(0,0,1,.5), cex = 0.8)

# Graficar te�rica ( Normal con promedio np**2 y  varianza n*(-3p^4 + 2p^3 + p^2)) con lineas en rojo:
prom = n*(p**2)
varianza = n*(-3*(p**4) + 2*(p**3) + p**2)
results_ord = sort(results)
lines(results_ord, pnorm(results_ord, mean = prom, sd = sqrt(varianza)), col="red", lwd=2)

#Iprmiir cosas que comparan promedios y varianzas:
print(paste("Promedio simulado:", mean(results)))
print(paste("Promedio te�rico:", prom))
print(paste("Varianza simulada:", var(results)))
print(paste("Varianza te�rico:", varianza))

################# OBSERVAMOS QUE ###################

# Parece ser que si logramos obtener la asintotica, los valores teoricos y esperados son muy cercanos y se ve que el ajuste de la
# empirica a la te�rica es muy bueno.
ok

