#########################################################################################################################################################
#Ana Beatriz Rodriguez Mendoza.
#Inferencia Estadistica.
#Parte 2 de la tarea 4.
#Texto sin acentos.
#########################################################################################################################################################



##########################################################################################################################################################
#2. En este ejercicio corroborara mediante simulaciones el Teorema Clasico de Limite Central(TCLC).
#a) Escriba la siguiente funcion en R. Simule una muestra de tama~no n de una variable
#aleatoria Exponencial(lambda) y calcule el estadistico Zn. Repita lo anterior
#m veces. La funcion debera tomar como parametros n, m y lambda y regresar un vector de
#tamanio n conteniendo la muestra de Zn.


Zn <- function(n, lambda, m) {
set.seed(0)
Z <- rep(0, m)
Z <- replicate(m, (sqrt(n)*(mean(rexp(n, lambda))-(lambda)^(-1)))/(lambda)^(-1))
return(Z)
}

# b) Para n = 5, 10, 100, 500, 1000, 10000, m = 1000 y lambda = 1, utilice la funcion del inciso
# anterior para obtener muestras de Zn. Grafique las muestras anteriores en un histograma
# (un histograma para cada n). Que observa? Que tiene que ver su resultado con el TCLC?

n <- c(5, 10, 100, 500, 1000, 10000)
i <- 1:6
Muestra <<- matrix(0L, 1000, 6)
auxiliar <- sapply(i, function(i) hist(Muestra[, i] <<- Zn(n[i], 1, 1000), main = paste("St normal distribution n =", n[i]),
     xlab = "Zn",  col ="darkviolet", border = "black") )

View(Muestra)
hist(Zn(5, 1, 1000),main = paste("St normal distribution m =", 1000),
     xlab = "Zn",  col ="darkviolet", border = "black")
hist(Zn(10, 1, 1000),main = paste("St normal distribution m =", 1000),
xlab = "Zn",  col ="darkviolet", border = "black")
hist(Zn(100, 1, 1000), main = paste("St normal distribution m =", 1000),
xlab = "Zn",  col ="darkviolet", border = "black")
hist(Zn(500, 1, 1000), main = paste("St normal distribution m =", 1000),
xlab = "Zn",  col ="darkviolet", border = "black")
hist(Zn(1000, 1, 1000), main = paste("St normal distribution m =", 1000),
xlab = "Zn",  col ="darkviolet", border = "black")
hist(Zn(10000, 1, 1000), main = paste("St normal distribution m =", 1000),
xlab = "Zn",  col ="darkviolet", border = "black")


#Se observa que la variable aleatoria Zn tiende a la normal estandar, cuando n es muy grande.
#En este resultado queda ejemplificado el TCLC, ya que es una secuecia de v.a.i.i, con momentos
#finitos  al normalizar la media de la secuencia  de variables aleatorias y aumentar n, la variable aleatoria estandar tiende a una
#distribucion limite, una normal estandar.

#c) Para cada una de las muestras generadas en el inciso anterior, encuentre el Q-Q plot y
#el P-P plot normales. Comente sus resultados.


# Funcion para encontrar los qqplot.
qqplotFunction<-function(data, sizeSample){
  sort(data)
  n <- length(data)
  x <- 1:length(data)
  p <- x/(n+1)

  teorico <-qnorm(c(0.25, 0.75))
  estimado <- quantile(data, c(0.25, 0.75))
  slope <- diff(estimado) / diff(teorico)
  int <- estimado[1] - slope * teorico[1]
  plot(qnorm(p), sort(data),  type = "p",
       ylab = "Observaciones", xlab ="Zi",
       main = paste("Normal QQ- plot   n =", sizeSample), pch=20)
  abline(int, slope)

}

qqplotFunction(Muestra[ ,6], n[6])
i <- 1:6
auxiliar2 <- sapply(i, function(i) qqplotFunction(Muestra[ ,i], n[i]) )


#Sesgo a la derecha
par(mfrow=c(1,2))
qqplotFunction(Muestra[ ,1], n[1])
hist(Muestra[ ,1])
#Se aproxima a una normal
par(mfrow=c(1,2))
qqplotFunction(Muestra[ ,6], n[6])
hist(Muestra[ ,6])


pp_plotFunction<-function(data, sizeSample){
  n <- length(data)
  x <- 1:length(data)
  pest <- x/(n+1)
  teorico <-pnorm(c(0.25, 0.75))
  estimado <- c(0.25, 0.75)

  slope <- diff(estimado) / diff(teorico)
  int <- estimado[1] - slope * teorico[1]

  Fest <- pest
  Fn <- pnorm(sort(data), mean(data), sd(data))

  plot(Fest, Fn,  type = "p",
       ylab = "Observaciones", xlab ="zi",
       main = paste("Normal PP- plot n = ", sizeSample), pch=20)
}

pp_plotFunction(Muestra[ , 1], n[1])
i <- 1:6
auxiliar3 <- sapply(i, function(i) pp_plotFunction(Muestra[ ,i], n[i]) )

# No se aproxima correctamente a una normal uando la muestra es de n = 5, se observa un sesgo a la derecha
# este sesgo se corrige cuando la distribucion muestral converge en distribucion a una normal.
con n 'grande'

##########################################################################################################################################################
#3. En este ejercicio volvera a trabajar con el TCLC.
#a) Escriba una funcion analoga a la pedida en el inciso 2a) para una distribucion Binomial(p, N). La funcion deberia tomar los mismos parametros
# a los pedidos en el inciso 2a), con excepcion al parametro  que tendra que ser sustituido p y N.


Zn2 <- function(n, p, N, m) {
  set.seed(0)
  Z <- rep(0, m)
  Z <- replicate(m, (sqrt(n)*(mean(rbinom(n, size = N, prob = p))-(N*p))/(sqrt(N*p*(1-p)))))
  return(Z)
}

#b) Para p = 1/2 y N = 15, repita los incisos 2b) y 2c) para el caso Binomial de este ejercicio.
n <- c(5, 10, 100, 500, 1000, 10000)
i <- 1:6
Muestra <<- matrix(0L, 1000, 6)
auxiliar <- sapply(i, function(i) hist(Muestra[, i] <<- Zn2(n[i], .5, 15,1000), main = paste("St normal distribution n =", n[i]),
                                       xlab = "Zn",  col ="darkviolet", border = "black") )
View(Muestra)


qqplotFunction(Muestra[ ,6], n[6])
i <- 1:6
auxiliar2 <- sapply(i, function(i) qqplotFunction(Muestra[ ,i], n[i]) )


pp_plotFunction(Muestra[ , 1], n[1])
i <- 1:6
  auxiliar3 <- sapply(i, function(i) pp_plotFunction(Muestra[ ,i], n[i]) )

#Cuando n es pequenio la distribucion estimada se aproxima al centro de la teorica.
#conforme va aumnetando converge a una distribucion a una normal estandar.
# y con el PP- plot se ve lo mismo.

#c) Para p = 0.1, N = 15, n = 5, 10, 20, 100 y m = 1000, genere muestras de Zn y grafique
#estas muestras en un histograma (un histograma para cada n). >Que observa? Explique.


n <- c(5, 10, 20, 100)
i <- 1:4
Muestra <- matrix(0L, 1000, 4)
auxiliar <- sapply(i, function(i) hist(Muestra[, i] <<- Zn2(n[i], 0.1, 15,1000), main = paste("St normal distribution n =", n[i]),
                                       xlab = "Zn",  col ="darkviolet", border = "black") )
View(Muestra)
hist(Muestra[, 4])


#Se observa que con n  observaciones pequenias (5 y 10), la funcion de densidad se aproxima un poco a la de una distribucion normal estandar,
# no en el centro,la convergencia mejora cuando n crece.

#d) Repita el inciso anterior para p = 0:99. Compare su resultado con lo obtenido en el inciso anterior.

n <- c(5, 10, 20, 100)
i <- 1:4
Muestra <- matrix(0L, 1000, 4)
auxiliar <- sapply(i, function(i) hist(Muestra[, i] <<- Zn2(n[i], 0.99, 15,1000), main = paste("St normal distribution n =", n[i]),
                                       xlab = "Zn",  col ="darkviolet", border = "black") )
View(Muestra)
hist(Muestra[, 4])

#Con una probabilidad de 0.99, de una distribucion binomial los datos se cargan hacia la izquierda,
#igual que en los casos anteriores converge cuando ala normal estandar cuando n es muy grande.
y que opinas sobre la velocidad de convergencia ??

##########################################################################################################################################################
#4b) Simule una sucesion de n = 1000 v.a. como arriba y calcule S1000 para p = 0:4. Repita
#este proceso 100 veces y grafique la distribucion empirica de S1000 que se obtiene de la
#simulacion y empalmela con la distribucion asintotica teorica que obtuvo. Comente sus resultados.

library("Rlab")

SnSimulation <-function() {
Sn <- rep(0, 1000)
i<- 1: 1000
sapply(i, function (i) {x<-rbern(1, 0.4); x2<-rbern(1, 0.4);
       if (x ==1 && x2 ==1){ este for esta mal porque en cada iteracion tienens dos nuevas observaciones, no depende de la anterior
         Sn[i] <<- 1 } else { Sn[i] <<- 0}})
return(apply(as.matrix(Sn), 2, sum))
}


n<- 1000
p<- .4
mean2 <- n*(p^2)
sd2<-sqrt(n*((p*(1-p))*(p*(1-p))))
FnEmpirica<- replicate(100, SnSimulation())

hist(FnEmpirica, main = "Distribucion empirica S = 100",
     xlab = "Sn",  col ="darkviolet", border = "black")

FnTeorica <- replicate(100,rnorm(1, mean2 , sd2))
hist(FnTeorica,  main = "Distribucion te?rica S = 100",
     xlab = "Sn",  col ="darkviolet", border = "black")

library("ggplot2", " ")

# Pasando a formato data frame
geom1 <- data.frame(x = FnEmpirica, group="Empirica")
geom2 <- data.frame(x = FnTeorica, group="Teorica")


graf <- rbind(geom1, geom2)

# Histogramas de las tres simulaciones
ggplot(graf, aes(x, fill=group, colour=group)) +
  geom_histogram(aes(y=..count..), breaks=seq(130,200,5), alpha=.5,
                 position="identity", lwd=0.2) +
ggtitle("Distribuci?n asint?tica Sn")


#En la funcion empirica caen los datos mas distribuidos en todo el soporte
#al contrario de la terica caen mucho en el centro.
