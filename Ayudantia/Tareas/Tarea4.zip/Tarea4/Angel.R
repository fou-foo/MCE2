#Funciones de problemas previos
Grafico.Normal<- function(D){
  #D es un vector con los datos (observaciones)
  #La funcion graficara el QQplot normal
  #
  Dord<-sort(D)
  n<-length(D)
  #p guarda las probabilidades de las que queremos saber el cuantil
  p<-(1:n)/(n+1)
  u<-mean(D)
  sigma<-sd(D)
  q<-qnorm(p,mean=u ,sd=sigma)
  plot(x=q,y=Dord,xlab="Cuantil teorico",ylab="Observaciones"
       ,main="Grafico de Probabilidad Normal",type="b")
}

QQPlot.Normal<- function(D){
  #D es un vector con los datos (observaciones)
  #La funcion graficara el QQplot normal
  #
  Dord<-sort(D)
  n<-length(D)
  #p guarda las probabilidades de las que queremos saber el cuantil
  p<-(1:n)/(n+1)
  q<-qnorm(p,mean=0,sd=1)
  plot(x=q,y=Dord,xlab="Cuantil teorico (zp)",ylab="Observaciones"
       ,main="Normal Q-Q Plot",type="b")
}


QQPlot.NormalExtendido<- function(D,conf,K){
  # D es un vector con los datos (observaciones)
  # La funcion graficara el QQplot normal
  #  y la banda de confianza 1-p
  # K es la constante obtenida de la tabla de
  # http://www.real-statistics.com/statistics-tables/kolmogorov-smirnov-table/
  # ya que no encontre forma eficiente momentaneamente
    # PUEDES UTILIZAR EL RESULTADO ASINTOTICO QUE USARON TUS COMPA�EROS ;) PREGUNTALES
  # de relacionar K con p
  Dord<-sort(D)
  n<-length(D)
  #p guarda las probabilidades de las que queremos saber el cuantil
  p<-(1:n)/(n+1)
  q<-qnorm(p,mean=0,sd=1)
  mensaje<- paste("Normal Q-Q Plot\nCon
                  una banda de un nivel de confianza de 1-alpha = ",conf)
  plot(x=q,y=Dord,xlab="Cuantil teorico (zp)",ylab="Observaciones"
       ,main=mensaje,type="b")
  alpha<-mean(D)
  beta<-sd(D)
  xord<- sort(q)
  ly<-alpha+beta*xord
  lines(xord,ly,col="red")
  pab<-p-K
  for(i in 1:n) if(pab[i]<0) pab[i]<-0.0001
  parr<-p+K
  for(i in 1:n) if(parr[i]>1) parr[i]<-0.9999
  abajo<-qnorm(pab,mean=0,sd=1)
  arriba<-qnorm(parr,mean=0,sd=1)
  lines(abajo,Dord,col="blue")
  lines(arriba,Dord,col="blue")

}


#Problema 2
#a)
simulaZ.exp<- function(n,lambda) {
  #n tamanio de la muestra
  #lambda parametro de la exponencial
  X.barra<- mean(rexp(n,rate = lambda))
  #ans tiene la estandarizacion pedida
  ans<- sqrt(n)*(X.barra-1/lambda)*lambda
  ans
}

muestraZ.exp<- function(n,m,lambda) {
  # n tamanio de la muestra para cada estandarizacion
  # m cantidad de estandarizaciones
  # lambda parametro de la exponencial
  muestra<-replicate(m,simulaZ.exp(n,lambda))
  muestra
}
#b)
# ACOSTUMBRATE A FIJAR UNA SEMILLA ;)
set.seed(0)
hist(muestraZ.exp(5,1000,1))
hist(muestraZ.exp(10,1000,1))
hist(muestraZ.exp(100,1000,1))
hist(muestraZ.exp(500,1000,1))
hist(muestraZ.exp(1000,1000,1))
hist(muestraZ.exp(10000,1000,1))
#Se puede observar como la "forma" del histograma va cambiando de ser la de la exponencial
#a ser la de una normal estandar, esto por el TLC
# TE SUGIERO PONERLES TITULOS INFORMATIVOS A TUS GRAFICOS Y DE PASO COLOR
#c)
QQPlot.Normal(muestraZ.exp(5,1000,1))
QQPlot.Normal(muestraZ.exp(10,1000,1))
QQPlot.Normal(muestraZ.exp(100,1000,1))
QQPlot.Normal(muestraZ.exp(500,1000,1))
QQPlot.Normal(muestraZ.exp(1000,1000,1))
QQPlot.Normal(muestraZ.exp(10000,1000,1))
Grafico.Normal(muestraZ.exp(5,1000,1))
Grafico.Normal(muestraZ.exp(10,1000,1))
Grafico.Normal(muestraZ.exp(100,1000,1))
Grafico.Normal(muestraZ.exp(500,1000,1))
Grafico.Normal(muestraZ.exp(1000,1000,1))
Grafico.Normal(muestraZ.exp(10000,1000,1))
#Se puede apreciar como conforme el valor de n crece, los graficos tienden a reflejar una linea
#recta, con desajuste solo apreciable en las colas


#Problema 3
#a)
simulaZ.bin<- function(n,p,N) {
  # n tiene el manio de la muestra
  # p y N son los parametros de la binomial
  X.barra<- mean(rbinom(n,size=N,prob=p))
  # ans tiene la estandarizacion pedida
  ans<- sqrt(n)*(X.barra-N*p)/(sqrt(N*p*(1-p)))
  ans
}

muestraZ.bin<- function(n,m,p,N) {
  # n es el tamanio de la muestra para cada estandarizacion
  # m es la cantidad de estandarizaciones
  # p y N son los parametros de la binomial
  muestra<-replicate(m,simulaZ.bin(n,p,N))
  muestra
}

#b)

#b) parte 1

hist(muestraZ.bin(5,1000,0.5,15))
hist(muestraZ.bin(10,1000,0.5,15))
hist(muestraZ.bin(100,1000,0.5,15))
hist(muestraZ.bin(500,1000,0.5,15))
hist(muestraZ.bin(1000,1000,0.5,15))
hist(muestraZ.bin(10000,1000,0.5,15))
#En contraste al caso anterior, debido a la simetria inicial de la distribucion, la forma
# de la grafica "converge" mas rapido
#b) parte 2
QQPlot.Normal(muestraZ.bin(5,1000,0.5,15))
QQPlot.Normal(muestraZ.bin(10,1000,0.5,15))
QQPlot.Normal(muestraZ.bin(100,1000,0.5,15))
QQPlot.Normal(muestraZ.bin(500,1000,0.5,15))
QQPlot.Normal(muestraZ.bin(1000,1000,0.5,15))
QQPlot.Normal(muestraZ.bin(10000,1000,0.5,15))
Grafico.Normal(muestraZ.bin(5,1000,0.5,15))
Grafico.Normal(muestraZ.bin(10,1000,0.5,15))
Grafico.Normal(muestraZ.bin(100,1000,0.5,15))
Grafico.Normal(muestraZ.bin(500,1000,0.5,15))
Grafico.Normal(muestraZ.bin(1000,1000,0.5,15))
Grafico.Normal(muestraZ.bin(10000,1000,0.5,15))

#La convergencia se da mas rapido EN QUE CASOS ??
# TE SUGIERO TRABAJAR M�S EN TUS GRAFICOS, TITULOS Y COLOR PERO DE MOMENTO ESTAN BIEN

#3 c)
hist(muestraZ.bin(5,1000,0.1,15))
hist(muestraZ.bin(10,1000,0.1,15))
hist(muestraZ.bin(20,1000,0.1,15))
hist(muestraZ.bin(100,1000,0.1,15))

#Ahora la distribucion inicialmente es menos simetrica, entonces la convergencia se da mas lento
#que en el caso anterior, inicalmente cargada hacia la izquierda la forma de la grafica

#3 d)


hist(muestraZ.bin(5,1000,0.99,15))
hist(muestraZ.bin(10,1000,0.99,15))
hist(muestraZ.bin(20,1000,0.99,15))
hist(muestraZ.bin(100,1000,0.99,15))
hist(muestraZ.bin(1000,1000,0.99,15))
#Debido a la asimetria la convergencia se da mas lento, originalmente cargada hacia la derecha
ok
#Problema 4
#b)

realizacion<- function(n,p){
  #n es el dice se Sn a calcular
  #p es la probabilidad de exito
  #prev es el resultado previo
  prev<-sample(0:1,1,prob=c(1-p,p))
  ans<- 0
  for(i in 1:n) { # OJO CON LA INICIALIZACION DE TUS VARIABLES AUXIALIRES, CON TU IMPLEMENTACION ACTUAL PARA 'N' PEQUE�OS NO ES EXACTA
    #nuevo experimento
    nueva<-sample(0:1,1,prob=c(1-p,p))
    #se actualiza ans
    ans<- ans+prev*nueva
    #se actualiza prev
    prev<-nueva
  }
  ans
}

simula<- function(n,p,m){
  # n es el indice de Sn
  # p es la probabilidad de un exito
  # m es la cantidad de realizaciones de Sn que generaremos
  S<- replicate(m,realizacion(n,p))
  # Se grafica mediante una tabla de frecuencias
  frecuencia<-table(S)/m
  plot(frecuencia)
  # x Soporte sobre el que graficaremos la dsitribucion asintotica
  x<-min(S):max(S)
  media<- n*p*p
  sd<- sqrt(n*(p*p+2*p*p*p-3*p*p*p*p))
  lines(x,dnorm(x,mean=media,sd))
}


simula(1000,0.4,100)
#como m es pequenia no se aprecia una buena forma empirica de la Sn
# 1000 REALIZACIONES TE PARECE POCO ??
simula(1000,0.4,1000)
#Se puede apreciar que se tiene un buen ajuste a la normal dada por el TLC
#Entre mas grande es m mejor se puede visualizar la distribucion empirica TAMBIEN DEPENDE DEL PARAMETRO 'P' FUERTEMENTE
simula(1000,0.4,10000)


#Problema 10
#Parte 2

#se generan 1000 numero aleatorios uniformes
cantidad<-1000
U<- runif(cantidad,min=0,max=1)
Z<- 1:cantidad
ind<- (1:(cantidad/2))*2-1
#se usa la formula de Box Muller
for(i in ind) {
  Z[i]=sqrt(-2*(log(U[i])))*cos(2*pi*U[i+1])
  Z[i+1]=sqrt(-2*(log(U[i])))*sin(2*pi*U[i+1])
}
#qqplor de la
QQPlot.NormalExtendido(Z,0.95,0.2417)
#La mayoria de los datos cae sobre la recta, como cabria esperar
