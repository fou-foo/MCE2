 ##EJERCICIO 2

#a)Simule una muestra de tamao n de una variable aleatoria Exponencial(??) y calcule el estad??stico Zn.
#Repita lo anterior m veces. La funcion debera tomar como parametros n, m y ?? y regresar un vector de tamano n
#conteniendo la muestra de Zn.

#n: tamano d ela muestra
#m:numero de repeticiones
#a: parametro del modelo exponencial

Zn<-function(n,a){
  vec<-rexp(n,a)
  zn<-(n^0.5)*(mean(vec)-(1/a))/(1/a)
  return(zn)
}

simTCLC<-function(n,m,a){
  v<-replicate(m,Zn(n,a))
  return(v)
}

#b) Para n = 5,10,100,500,1000,10000, m = 1000 y ?? = 1, utilice la funcion del inciso anterior para obtener muestras de Zn.
#Graf??que las muestras anteriores en un histograma (un histograma para cada n). ??Que observa?
#??Que tiene que ver su resultado con el TCLC? R:conforme se aumenta el tamano de muestra, la grafica de cada simulacion
#parece seguir una distribucion normal, para ello se corrobora o descarta en el sigueinte inciso. Para asi llegar a la
#conclusion acerca del TCLC, el cual nos dice que para muestras grandes la distribucion de las medias sigue aproximadamente una distribuci??n normal.

#n=5 m=1000  a=1
A<-simTCLC(5,1000,1)
hist(A)

#n=10 m=1000  a=1
B<-simTCLC(10,1000,1)
hist(B)

#n=100 m=1000  a=1
C<-simTCLC(100,1000,1)
hist(C)

#n=500 m=1000  a=1
D<-simTCLC(500,1000,1)
hist(D)

#n=1000 m=1000  a=1
E<-simTCLC(1000,1000,1)
hist(E)

#n=10000 m=1000  a=1
G<-simTCLC(10000,1000,1)
hist(G)

#c) Para cada una de las muestras generadas en el inciso anterior, encuentre el Q-Q plot y el P-P plot normales.
#Comente sus resultados.

#################################  NORMAL Q-Q PLOT  ###########################################
FEmpirica<-function(x,datos){
  prob<-(sum(datos<x))/(length(datos))
  return(prob)
}
y<-sort(A)
Cuantiles<-function(A){ #Funciona que genera los cuatiles
  cuanorm<-vector()  #Vector que guarda los cuantiles normales correspondientes a la "probabilidad empirica" de los datos
  for(i in 1:length(y)){ #Genera los cuantiles normales
    cuanorm[i]<-qnorm(FEmpirica(y[i],A))
  }
  return(cuanorm)  #Genera como resultado una lista con el vector de los cuantiles normales
}

#n=5
y<-sort(A)
plot(Cuantiles(A),y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)

#n=10
y<-sort(B)
plot(Cuantiles(B),y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)

#n=100
y<-sort(C)
plot(Cuantiles(C),y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)

#n=500
y<-sort(D)
plot(Cuantiles(D),y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)

#n=1000
y<-sort(E)
plot(Cuantiles(E),y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)

#n=10, 000
y<-sort(G)
plot(Cuantiles(G),y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)

############################### NORMAL P-P PLOT ##########################################
ProN<-vector()
ProEm<-vector()
PP<-function(A){   #Funcion para obtener el P-P plot

  #Calculando los intervalos de confianza
  for(i in 1:length(y)){ ProEm[i]<-FEmpirica(y[i],A)}
  for(i in 1:length(y)){ ProN[i]<-pnorm(y[i], mean = mean(A), sd = sd(A))}

  return(resultados<-list(ProN=ProN,ProEm=ProEm))
}

#n=5
y<-sort(A)
plot(PP(A)[[1]],PP(A)[[2]], type ="p", xlab = "Probabilidad Normal",ylab = "Probabilidad Empirica", main = "Normal P-P Plot", col= "blue",pch=20)
#n=10
y<-sort(B)
plot(PP(B)[[1]],PP(B)[[2]], type ="p", xlab = "Probabilidad Normal",ylab = "Probabilidad Empirica", main = "Normal P-P Plot", col= "blue",pch=20)
#n=100
y<-sort(C)
plot(PP(C)[[1]],PP(C)[[2]], type ="p", xlab = "Probabilidad Normal",ylab = "Probabilidad Empirica", main = "Normal P-P Plot", col= "blue",pch=20)
#n=500
y<-sort(D)
plot(PP(D)[[1]],PP(D)[[2]], type ="p", xlab = "Probabilidad Normal",ylab = "Probabilidad Empirica", main = "Normal P-P Plot", col= "blue",pch=20)
#n=1000
y<-sort(E)
plot(PP(E)[[1]],PP(E)[[2]], type ="p", xlab = "Probabilidad Normal",ylab = "Probabilidad Empirica", main = "Normal P-P Plot", col= "blue",pch=20)
#n=10, 000
y<-sort(G)
plot(PP(G)[[1]],PP(G)[[2]], type ="p", xlab = "Probabilidad Normal",ylab = "Probabilidad Empirica", main = "Normal P-P Plot", col= "blue",pch=20)
BIEN JORGE, SOLO TE SUGIERO AGREGAR TITULOS MAS INFORMATIVOS A TUS GRAFICOS
#R: Al analizar los Q-Q PLOT Y P-P PLOT, obervamos una tendencia de las medias de la muestra a datos normales,
#con muestras mas grandes corroboramos el TCLC, la distribucion de las medias sigue aproximadamente una distribuci??n normal.

#EJERCICIO 3
#a) Escriba una funcion analoga a la pedida en el inciso 2a) para una distribucion Binomial(p,N).
#La funcion debera tomar los mismos parametros a los pedidos en el inciso 2a), con excepcion al parametro ??
#que tendra que ser sustituido p y N.

Zm<-function(n,N,p){
  vector<-rbinom(n,prob = p,size = N)
  zm<-(n^0.5)*(mean(vector)-(1/(N*p)))/(1/(N*p))
  return(zm)
}

simTCLC2<-function(n,N,p,m){
  v2<-replicate(m,Zm(n,N,p))
  return(v2)
}

#b) Para p = 1/2 y N = 15, repita los incisos 2b) y 2c) para el caso Binomial de este ejercicio.

#n=5 m=1000
A2<-simTCLC2(5,N=15,p=0.5,m=1000)
hist(A2)

#n=10 m=1000
B2<-simTCLC2(10,N=15,p=0.5,m=1000)
hist(B2)

#n=100 m=1000
C2<-simTCLC2(100,N=15,p=0.5,m=1000)
hist(C2)

#n=500 m=1000
D2<-simTCLC2(500,N=15,p=0.5,m=1000)
hist(D2)

#n=1000 m=1000
E2<-simTCLC2(1000,N=15,p=0.5,m=1000)
hist(E2)

#n=10000 m=1000
G2<-simTCLC2(10000,N=15,p=0.5,m=1000)
hist(G2)

#################################  NORMAL Q-Q PLOT  ###########################################
FEmpirica<-function(x,datos){
  prob<-(sum(datos<x))/(length(datos))
  return(prob)
}
y<-sort(A2)
Cuantiles<-function(A2){ #Funciona que genera los cuatiles
  cuanorm<-vector()  #Vector que guarda los cuantiles normales correspondientes a la "probabilidad empirica" de los datos
  for(i in 1:length(y)){ #Genera los cuantiles normales
    cuanorm[i]<-qnorm(FEmpirica(y[i],A2))
  }
  return(cuanorm)  #Genera como resultado una lista con el vector de los cuantiles normales
}

#n=5
y<-sort(A2)
plot(Cuantiles(A2),y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)

#n=10
y<-sort(B2)
plot(Cuantiles(B2),y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)

#n=100
y<-sort(C2)
plot(Cuantiles(C2),y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)

#n=500
y<-sort(D2)
plot(Cuantiles(D2),y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)

#n=1000
y<-sort(E2)
plot(Cuantiles(E2),y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)

#n=10, 000
y<-sort(G2)
plot(Cuantiles(G2),y,main = "Normal Q-Q Plot",type = "p", xlab = "Cuantiles Teoricos",ylab = "Obervaciones", col="darkblue",pch=20)

############################### NORMAL P-P PLOT ##########################################
ProN<-vector()
ProEm<-vector()
PP<-function(A2){   #Funcion para obtener el P-P plot

  #Calculando los intervalos de confianza
  for(i in 1:length(y)){ ProEm[i]<-FEmpirica(y[i],A2)}
  for(i in 1:length(y)){ ProN[i]<-pnorm(y[i], mean = mean(A2), sd = sd(A2))}

  return(resultados<-list(ProN=ProN,ProEm=ProEm))
}

#n=5
y<-sort(A2)
plot(PP(A2)[[1]],PP(A2)[[2]], type ="p", xlab = "Probabilidad Normal",ylab = "Probabilidad Empirica", main = "Normal P-P Plot", col= "blue",pch=20)
#n=10
y<-sort(B2)
plot(PP(B2)[[1]],PP(B2)[[2]], type ="p", xlab = "Probabilidad Normal",ylab = "Probabilidad Empirica", main = "Normal P-P Plot", col= "blue",pch=20)
#n=100
y<-sort(C2)
plot(PP(C2)[[1]],PP(C2)[[2]], type ="p", xlab = "Probabilidad Normal",ylab = "Probabilidad Empirica", main = "Normal P-P Plot", col= "blue",pch=20)
#n=500
y<-sort(D2)
plot(PP(D2)[[1]],PP(D2)[[2]], type ="p", xlab = "Probabilidad Normal",ylab = "Probabilidad Empirica", main = "Normal P-P Plot", col= "blue",pch=20)
#n=1000
y<-sort(E2)
plot(PP(E2)[[1]],PP(E2)[[2]], type ="p", xlab = "Probabilidad Normal",ylab = "Probabilidad Empirica", main = "Normal P-P Plot", col= "blue",pch=20)
#n=10, 000
y<-sort(G2)
plot(PP(G2)[[1]],PP(G2)[[2]], type ="p", xlab = "Probabilidad Normal",ylab = "Probabilidad Empirica", main = "Normal P-P Plot", col= "blue",pch=20)

#c) Para p = 0.1, N = 15, n = 5,10,20,100 y m = 1000, genere muestras de Zn y graf??que estas muestras en un histograma (un histograma para cada n). ??
#Que observa?

#n=5 m=1000
A3<-simTCLC2(5,N=15,p=0.1,m=1000)
hist(A3)

#n=10 m=1000
B3<-simTCLC2(10,N=15,p=0.1,m=1000)
hist(B3)

#n=20 m=1000
C3<-simTCLC2(20,N=15,p=0.1,m=1000)
hist(C3)

#n=100 m=1000
D3<-simTCLC2(100,N=15,p=0.1,m=1000)
hist(D3)

#d) Repita el inciso anterior para p = 0.99. Compare su resultado con lo obtenido en el inciso anterior.
#R: Los histogramas no representan, como en el inciso anterior, su tendencia a la normal.
de hecho s� aunque de manera mas lenta
#n=5 m=1000
A4<-simTCLC2(5,N=15,p=0.99,m=1000)
hist(A4)

#n=10 m=1000
B4<-simTCLC2(10,N=15,p=0.99,m=1000)
hist(B4)

#n=20 m=1000
C4<-simTCLC2(20,N=15,p=0.99,m=1000)
hist(C4)

#n=100 m=1000
D4<-simTCLC2(100,N=15,p=0.99,m=1000)
hist(D4)
y que concluyes ??
#  EJERCICIO 4
#Supongamos que X0,X1,... es una sucesi ??on de experimentos Bernoulli independientes con probabilidad de ??exito p.
#Supongamos tambien que Xi es la indicadora del exito de su equipo en el i-esimo juego de un rally de futbol.
#Su equipo anota un punto cada vez que tiene un exito seguido de otro.
#Denotemos por Sn al numero de puntos que su equipo anota al tiempo n.

#a) Encuentre la distribucion asintotica de Sn.

#b) b) Simule una sucesion de n = 1000 v.a. como arriba y calcule S1000 para p = 0.4.
#Repita este proceso 100 veces y graf??que la distribucion empirica de S1000 que se obtiene de la simulacion
#y empalmela con la distribucion asintotica teorica que obtuvo.

Sn<-function(){
  u<-sample(x=c(1,0), size = 1000, replace = T, prob = c(0.4,0.6))
  v=0
  for(i in 2:1000) {
    if(u[i-1]*u[i]==1){v=v+1}
  }
return(v)
}

jganados<-replicate(100,Sn())

FEmpirica<-function(x,datos){
  prob<-(sum(datos<x))/(length(datos))
  return(prob)
}
#Generando el espacio muestral
w<-seq(from = min(jganados),to = max(jganados),by = 0.5)
z<-vector()
for(i in 1:length(w)){
  z[i]<-FEmpirica(w[i],jganados)    #Vector que guarda la probabilidad empirica para el esapacio muestral
}

#Grafica de la Distribucion de Probabilidad Empirica
t<-seq(100,210,by= 0.01)
plot(w,z,type = "b",main = "Funcion de Distribucion Empirica",xlab  = "Espacio Muestral",ylab  = "Probabilidad", col="blue",pch=20)

#distribucion asintotitca teorica
lines(t,pnorm(x,160,13.44),col="red") # como obtuviste esta media y varianza??

#Las distribuciones se ajustan
