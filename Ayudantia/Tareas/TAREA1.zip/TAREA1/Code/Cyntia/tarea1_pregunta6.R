#Alumna: Ramirez Islas Cynthia Mariangel
#Tarea 1 
#Ejercicio 6

###############################################################################
#Inciso a) Usando funci�n sample, Simulacion de moneda equilibrada 10^6 veces  
#Entrada: n=# de simulaciones (10,000)
#Salida: Resultado primeros 3 lanz, gr�fica de frecuencias y de probabilidad
#Consideremos "�guila=1"

#Inicializaci�n de variables
aguilas<-0
# de simulaciones
n=10000000
#Simulaci�n de 10 lanzamientos de moneda repitiendo proceso 10^6 veces 
for(i in 1:n){
  moneda<- sample(c(0,1), 10, replace = TRUE)
  aguilas[i]<-c(sum(moneda==1)) 

#Impresi�n de los primeros 3 resultados 
  if(i<=3) {
    print(paste("# de �guilas en el lanzamiento",i)  )
    print(aguilas[i])
  }
}
# es muy tardado te recomiendo declarar el vector 'aguilas' fuera del for y rellenarlo

#C�lculo de frecuencias
frecuencia<- data.frame(table(aguilas))
#C�lculo de probabilidades
probabilidad<- prop.table(table(aguilas))

#Gr�fica de frecuencias 
plot(frecuencia, main="Gr�fica de frecuencias", xlab="# de �guilas")
#Gr�fica de probabilades, incluyendo gr�fica de distribuci�n te�rica
plot(probabilidad, main="Funci�n de Probabilidad ", xlab="# de �guilas", ylab="Proporciones")

###################################################################################### 
#Inciso b) Usando la funci�n dbinom grafique la funci�n de masa de una distribuci�n B(10; 0:5)
#sobre la gr�fica de las proporciones
#Salida: Gr�fica de probabilidad te�rica vs simulaci�n 

#Gr�fica de probabilades, incluyendo gr�fica de distribuci�n te�rica
plot(probabilidad, main="Funci�n de Probabilidad ", xlab="# de �guilas")
lines(dbinom(1:10,10,0.5), col="blue")
legend("topleft",c("Simulaci�n","Dist. te�rica"),col=c("black","blue"), lwd=1:2)

#�Que observa?
#Podemos notar que para  una muestra de tama�o n , n lo suficientemente grande, 
#la simulaci�n de la distribuci�n se asemeja mucho a la distribuci�n binomial 
#B(10; 0:5) te�rica 

######################################################################################
#Inciso c) Repetir incisos anteriores para moneda desequilibrada con p = 0:3
#Entrada: n=# de simulaciones (10,000,000) 
#Salida: Resultado primeros 3 lanz, gr�fica de frecuencias y de probabilidad
#Consideremos "�guila=1"

##Inicializaci�n de variables
aguilas2<-0
# de simulaciones
m=100000
#Simulaci�n de 10 lanzamientos de moneda desequilibrada,  10^6 veces 
for(i in 1:m){
  moneda2<-sample(c(0:1),10, TRUE, c(.7,.3))
  aguilas2[i]<-c(sum(moneda2==1)) 
  
  #Impresi�n de los primeros 3 resultados 
  if(i<=3) {
    print(paste("# de �guilas en el lanzamiento",i)  )
    print(aguilas2[i])
  }
}

#C�lculo de frecuencias
frecuencia2<- data.frame(table(aguilas2))
#C�lculo de probabilidades
probabilidad2<- prop.table(table(aguilas2))

#Gr�fica de frecuencias 
plot(frecuencia2, main="Gr�fica de frecuencias")
#Gr�fica de proporciones 
plot(probabilidad2, main="Funci�n de Probabilidad ", xlab="# de �guilas", ylab="Proporciones")

#Gr�fica de probabilades, incluyendo gr�fica de distribuci�n te�rica
plot(probabilidad2, main="Funci�n de Probabilidad ", xlab="# de �guilas", ylab="Probabilidad", ylim=c(0,.3))
lines(dbinom(1:10,10,0.3), col="blue")
legend("topright",c("Simulaci�n","Dist. te�rica"),col=c("black","blue"), lwd=1:2)

#�Que observa?
#Podemos notar que para  una muestra de tama�o n , n lo suficientemente grande, 
#la simulaci�n de la distribuci�n se asemeja mucho a la distribuci�n binomial b(10,.03) te�rica 

# bien 



