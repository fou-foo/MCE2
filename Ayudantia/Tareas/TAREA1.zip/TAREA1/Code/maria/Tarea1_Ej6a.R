# Tarea 1, Ejercicio 6
# Mar�a Guadalupe Garrido Espinosa

#rm(list=ls())

#res_moneda=c(1:2) #Generamos vector con las posibles salidas del lanzamiento de la moneda

#lanzamientos=sample(res_moneda,10,replace = TRUE) #Simulamos 10 veces este lanzamiento

#res_exp=data.frame(table(lanzamientos))#Hacemos el conteo

#res_exp[2,2]#Imprimimos el n�mero de veces que se obtuvo �guila (n�mero 2)

#Los renglones 8,10 y 12 los podemos resumir en uno:
#data.frame(table(sample(res_moneda,10,replace = TRUE) ) )[2,2]


#############################################################
#�Qu� tan cargada est� la moneda? 
# El valor ser� 0.5 si es el inciso a y 0.3 si es el inciso c
#############################################################

p=0.3; 
n=1000000;#�Cu�ntas repeticiones quieres?

simular<-function(n){
  res_moneda=c(1:2)
  simulacion=rep(0,n)
  for (i in c(1:n)) 
    {
    simulacion[i]=data.frame(table(sample(res_moneda,10,replace = TRUE,prob =c(1-p,p)) ) )[2,2];
  
  }
  returnValue(simulacion);
}
simulacion=simular(n)#Repetimos el experimento 10^6

simulacion[1:3]#Mostramos los tres primeros resultados

resultados=data.frame(table(simulacion)) #contamos para obtener las frecuencias

#Graficamos las frecuencias de las �guilas
plot(as.numeric(resultados$simulacion),resultados$Freq)# se veia raro con las rayas, era cosa de convertir a numerico el factor
plot(resultados$simulacion,resultados$Freq)#tu tenias esta linea
#Graficamos la probabilidad de que salga cierto n�mero de �guilas
plot(resultados$simulacion,resultados$Freq/n) # lo mismo que en el anterior

#Ahora vamos a graficar la funci�n de masa de una B(10,0.5)

bin_res=matrix(0,11,2);
for(i in 0:10)
{
  bin_res[i,1]=i;
  bin_res[i,2]=dbinom(x=i,10,p);
}

rm(i)#Borramos el contador

res_binom=as.data.frame(bin_res)

colnames(res_binom)=c("Num_aguilas","Prop_bin")

colnames(resultados)=c("Num_aguilas","Prop_exp")

#creamos un arrglo que tenga los tres resultados con proporciones
comp=merge(res_binom,resultados, by="Num_aguilas", all=TRUE)

#Graficamos la funci�n de masa de una B(10,p) encima del gr�fico de proporciones
plot(comp$Num_aguilas,comp$Prop_exp/n,type="h",col="cornflowerblue",lwd = 10,xlab="# �guilas",ylab="Proporci�n")
par(bty = 'n')
points(comp$Num_aguilas,comp$Prop_bin,type="p",col="red",lwd = 10)

####
#Notas:
# 
#Inciso b) �Qu� observa?
#
#       -Lo que se observa es que a medida que se incrementa el n�mero de repeticiones
#       del experimento, el gr�fico de proporciones tiende a ser m�s similar a la funci�n
#       de masa de la distribuci�n de una B(10,0.5). Adicionalmente, en la simulaci�n
#       no se da el caso donde el n�mero de �guilas sea 0 o 10, esto se puede explicar 
#       por lo poco probable que son estos eventos, quiz� si se incrementara el 
#       n�mero de repeticiones se podr�a tener al menos una ocurrencia.

#       Adem�s que se observa que el n�mero de �guilas que m�s se repite es el 5(=np)
#       
#
#Inciso c) �Qu� observa?
#
#       -Al igual que en el inciso b, se observa es que a medida que se incrementa el 
#       n�mero de repeticiones el experimento, el gr�fico de proporciones tiende a ser
#       m�s similar a la funci�n de masa de la distribuci�n de una B(10,0.3).
#       -En la simulaci�n no se da el caso que se tengan 0 o 10 �guilas, al 
#       igual que en el inciso anterior, es posible que a medida que se incrementa el 
#       n�mero de simulaciones se obtenga al menos una ocurrencia.
#   
#       Adem�s que se observa que el n�mero de �guilas que m�s se repite es el 3 (=np)
####

ok, pero te falto indicar explicitamente que se tiene que cambiar el parametro p
pero esta bien